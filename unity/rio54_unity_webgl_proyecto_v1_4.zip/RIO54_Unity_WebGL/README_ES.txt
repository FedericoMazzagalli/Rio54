RIO54 — PROYECTO UNITY WEB
========================
Versión del proyecto: 1.3.1
Editor fijado: Unity 6.3 LTS (6000.3.0f1)
Destino: Web / WebAssembly / WebGL 2

QUÉ ES ESTA ENTREGA
-------------------
Proyecto fuente para crear la versión nativa de Unity Web de RIO54. Incluye:
- Campaña de cuatro expedientes y 16 pistas.
- Diálogos de análisis, tablero de relaciones y conclusiones.
- Ocho idiomas: español, inglés, portugués brasileño, francés, alemán, italiano,
  japonés y chino simplificado.
- Guardado local de partida mediante PlayerPrefs.
- Escena ambiental 3D procedural: skyline nocturno, luna, estrellas y objeto volador.
- Plantilla web propia con presentación y barra de carga RIO54.
- Selección explícita de Noto Sans CJK JP / SC según el idioma, con fuentes incrustadas.
- Instalador automático de fuentes oficiales Noto CJK, con validación de OTF y conservación de licencias.
- Configuración de importadores automática también en compilaciones sin interfaz (CI / batchmode).
- Licencias Noto incluidas en la carpeta ThirdPartyNotices del build publicado.
- Validación previa ampliada y compilación local o remota con GitHub Actions.
- Compilación desde el menú Unity o desde línea de comandos.

IMPORTANTE: ESTA ENTREGA ES EL PROYECTO FUENTE, NO EL BUILD .WASM
----------------------------------------------------------------
No se incluye una compilación .wasm porque este entorno de trabajo no dispone de Unity Editor
ni del módulo Web Build Support. La carpeta Build/WebGL se genera en tu equipo al compilar.
No se presenta el proyecto fuente como si ya fuese una versión publicada.

1. REQUISITOS
-------------
- Unity 6.3 LTS, versión 6000.3.0f1 o una actualización compatible de la misma línea.
- Módulo Web Build Support instalado desde Unity Hub.
- Python 3 para ejecutar los chequeos del proyecto, validar la salida y servir una vista local.
- Conexión a Internet la primera vez que se preparan las fuentes CJK, para descargarlas desde
  los paquetes oficiales de Noto. El proyecto fuente no redistribuye archivos binarios de fuentes.

2. PREPARAR LAS FUENTES PARA LOS OCHO IDIOMAS
--------------------------------------------
La primera vez, ejecutá desde la carpeta del proyecto:
  python3 Tools/setup_cjk_fonts.py

En Windows:
  py -3 Tools\setup_cjk_fonts.py

El instalador descarga los paquetes oficiales Noto Sans CJK JP y SC (release Sans2.004),
extrae únicamente los pesos Regular, comprueba la firma de los OTF y conserva el archivo
LICENSE de cada paquete. Los ZIP de origen son grandes (aprox. 90 MiB cada uno); una vez
instaladas, las fuentes quedan en Assets/Resources/Fonts y las compilaciones siguientes
no necesitan volver a descargarlas.

Archivos esperados:
- NotoSansCJKjp-Regular.otf
- NotoSansCJKsc-Regular.otf
- LICENSE_NotoSansCJKjp.txt
- LICENSE_NotoSansCJKsc.txt

Para revisar sin descargar:
  python3 Tools/setup_cjk_fonts.py --check

Después de abrir el proyecto en Unity, ejecutá RIO54 > 2 - Configurar fuentes internacionales.
La compilación por línea de comandos y GameCI también configura automáticamente los importadores
como fuentes dinámicas con los datos incrustados. Si necesitás instalarlas manualmente, los
paquetes se encuentran en las releases oficiales citadas en Assets/Resources/Fonts/README.txt.

3. ABRIR EL PROYECTO
--------------------
1. Descomprimí el ZIP.
2. Abrí Unity Hub.
3. Seleccioná Add / Open project y elegí la carpeta RIO54_Unity_WebGL.
4. Abrí el proyecto con Unity 6.3 LTS (6000.3.0f1).
5. Esperá a que Unity resuelva los paquetes e importe los recursos.

4. VALIDAR Y PROBAR EN EL EDITOR
-------------------------------
Antes de abrir Unity, podés ejecutar:
  python3 Tools/validate_project.py

En Unity:
1. RIO54 > 1 - Preparar escena principal.
2. Abrí Assets/Scenes/RIO54Main.unity.
3. Pulsá Play para probar el flujo de juego en el Editor.
4. RIO54 > 3 - Validar proyecto muestra el estado de los recursos.

5. COMPILAR PARA LA WEB
-----------------------
Método desde Unity:
1. Abrí File > Build Profiles.
2. Seleccioná Web (la API de scripting sigue identificando la plataforma como WebGL).
3. Pulsá Switch Platform si todavía no está activa.
4. Ejecutá RIO54 > 4 - Compilar para WebGL. El menú configura las fuentes y copia los avisos LICENSE.
5. La salida queda en Build/WebGL.

Método automático por línea de comandos:
- Linux: ejecutá Tools/build_webgl_linux.sh
  Podés indicar la ruta de Unity con la variable UNITY_EDITOR.
- Windows: ejecutá Tools/build_webgl_windows.bat
  Podés indicar la ruta de Unity con UNITY_EDITOR.

Los scripts llaman a RIO54BuildTools.BatchBuildWebGL, guardan el registro en Logs y verifican
que la salida tenga index.html, WebAssembly, loader, framework y archivo de datos.

6. COMPILACIÓN REMOTA CON GITHUB ACTIONS
----------------------------------------
El proyecto incluye .github/workflows/rio54-webgl.yml. Para usarlo:
1. Subí la carpeta RIO54_Unity_WebGL como repositorio GitHub.
2. El workflow descarga los OTF de Noto CJK desde las releases oficiales y conserva sus avisos LICENSE.
3. Para Unity Personal, abrí Unity Hub > Preferences > Licenses > Add > Get a free personal license.
   Iniciá sesión y completá la activación para que Unity Hub genere el archivo .ulf.
4. En GitHub > Settings > Secrets and variables > Actions, creá estos tres secretos:
   - UNITY_LICENSE: contenido completo de Unity_lic.ulf.
   - UNITY_EMAIL: correo de la cuenta usada en Unity Hub.
   - UNITY_PASSWORD: contraseña de esa cuenta.
   En Linux, el archivo suele estar en ~/.local/share/unity3d/Unity/Unity_lic.ulf.
5. Ejecutá Actions > RIO54 Unity WebGL > Run workflow y activá la opción build_unity.
6. Descargá el artefacto RIO54-Unity-WebGL cuando finalice el trabajo. Incluye ThirdPartyNotices/NotoCJK.

No compartas el archivo .ulf, las credenciales ni el contenido de los secretos en chats o issues.
El flujo automatiza la compilación con GameCI y Unity 6.3; este paquete no incluye credenciales
ni una licencia de Unity. La licencia Personal se activa localmente en Unity Hub y su archivo se
almacena solo como secreto privado del repositorio.

7. PROBAR Y PUBLICAR
--------------------
No abras el index.html de una build de Unity directamente como file://. Serví la carpeta
Build/WebGL mediante HTTP/HTTPS o subí su contenido completo a un hosting compatible con Unity Web.
Los servidores deben devolver el tipo MIME correcto para WebAssembly y, si se habilita compresión,
respetar los encabezados requeridos por Unity. Para una prueba local, ejecutá:
  python3 Tools/serve_webgl_preview.py --build Build/WebGL
Después abrí http://127.0.0.1:8000 en Firefox o Chromium. También podés usar Unity Build and Run.

8. GUARDADO E IDIOMAS
---------------------
El progreso se guarda en PlayerPrefs. En navegador, queda asociado al perfil del navegador y
al dispositivo; no se sincroniza entre dispositivos. La preferencia de idioma también se guarda.

9. DERECHOS Y ALCANCE
---------------------
Adaptación independiente inspirada en publicaciones del Café Ufológico RIO54. No implica respaldo
ni participación oficial de los autores del blog. Los personajes y escenas interactivas son
ficcionales. Los nombres originales de publicaciones y referencias se conservan para rastrear
las fuentes. Antes de explotar comercialmente el nombre/marca, fotografías, textos íntegros o
testimonios de terceros, deben obtenerse las autorizaciones correspondientes.

ESTRUCTURA PRINCIPAL
-------------------
Assets/Scripts/RIO54Game.cs             Lógica, pantallas y localización.
Assets/Scripts/RIO54World.cs            Escena 3D procedural.
Assets/Scripts/SimpleJson.cs             Lector JSON sin paquetes externos.
Assets/Editor/RIO54BuildTools.cs         Menús, fuentes, validación y compilación.
Assets/Resources/RIO54Data.json          Expedientes y traducciones.
Assets/Resources/Fonts/                  Fuentes Noto CJK descargadas durante la preparación del build.
Assets/WebGLTemplates/RIO54/index.html   Página de lanzamiento personalizada.
Tools/build_webgl_linux.sh               Compilación automatizada Linux.
Tools/build_webgl_windows.bat            Compilación automatizada Windows.
Tools/setup_cjk_fonts.py                Descarga, extrae y valida fuentes Noto CJK y licencias.
Tools/validate_project.py               Chequeos previos a Unity.
Tools/validate_webgl_output.py            Verificación de artefactos compilados.
Tools/serve_webgl_preview.py              Servidor HTTP local para probar el build.
.github/workflows/rio54-webgl.yml         Compilación remota de Unity WebGL con GameCI.

DOCUMENTACIÓN OFICIAL
---------------------
Unity Web build: https://docs.unity.cn/Manual/webgl-building.html
Unity Web templates: https://docs.unity.cn/Manual/webgl-templates.html
Unity Web graphics/fonts: https://docs.unity.com/en-us/engine/6000.0/manual/platform-specific/webgl/develop/graphics
Unity Web Player settings: https://docs.unity.cn/Manual/class-PlayerSettingsWebGL.html
Noto CJK license: https://github.com/notofonts/noto-cjk/blob/main/Sans/LICENSE
