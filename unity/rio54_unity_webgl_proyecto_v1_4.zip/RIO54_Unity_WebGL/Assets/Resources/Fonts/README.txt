FUENTES PARA LA COMPILACIÓN WEB MULTILINGÜE
==========================================

Preparación automática (recomendado)
------------------------------------
Desde la carpeta raíz del proyecto:
  python3 Tools/setup_cjk_fonts.py

En Windows:
  py -3 Tools\setup_cjk_fonts.py

El instalador descarga los paquetes oficiales de Noto Sans CJK JP y SC (Sans2.004),
extrae los archivos Regular, valida sus firmas OTF y copia la licencia de cada paquete.
Los ZIP remotos pesan aproximadamente 90 MiB cada uno. Los binarios no se incluyen
con el ZIP fuente de RIO54: se descargan directamente del proyecto oficial al preparar
la compilación y no se redistribuyen por este proyecto sin sus avisos de licencia.

Archivos resultantes esperados:
- NotoSansCJKjp-Regular.otf
- NotoSansCJKsc-Regular.otf
- LICENSE_NotoSansCJKjp.txt
- LICENSE_NotoSansCJKsc.txt

Para comprobar si ya están instalados, sin descargar:
  python3 Tools/setup_cjk_fonts.py --check

Configuración de Unity
----------------------
Después de abrir el proyecto, ejecutá RIO54 > 2 - Configurar fuentes internacionales.
La compilación batchmode y GameCI ejecutan esa configuración automáticamente.
Cada OTF se importa como Dynamic y con includeFontData habilitado, para que el build Web
no dependa de fuentes instaladas en el sistema operativo del jugador.

Fuentes oficiales y licencia
----------------------------
- Japonés: https://github.com/googlefonts/noto-cjk/releases/download/Sans2.004/06_NotoSansCJKjp.zip
- Chino simplificado: https://github.com/googlefonts/noto-cjk/releases/download/Sans2.004/08_NotoSansCJKsc.zip
- Guía: https://github.com/notofonts/noto-cjk/blob/main/Sans/README.md
- Licencia de los paquetes: SIL Open Font License 1.1. Conservá los avisos LICENSE originales.
