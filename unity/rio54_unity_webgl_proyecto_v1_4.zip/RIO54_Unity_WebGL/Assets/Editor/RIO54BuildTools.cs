#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class RIO54BuildTools
{
    private const string ScenePath = "Assets/Scenes/RIO54Main.unity";
    private const string OutputPath = "Build/WebGL";
    private const string CIOutputPath = "build/WebGL";
    private const string TemplatePath = "Assets/WebGLTemplates/RIO54/index.html";
    private const string JapaneseFontPath = "Assets/Resources/Fonts/NotoSansCJKjp-Regular.otf";
    private const string ChineseFontPath = "Assets/Resources/Fonts/NotoSansCJKsc-Regular.otf";
    private const string JapaneseLicensePath = "Assets/Resources/Fonts/LICENSE_NotoSansCJKjp.txt";
    private const string ChineseLicensePath = "Assets/Resources/Fonts/LICENSE_NotoSansCJKsc.txt";

    [MenuItem("RIO54/1 - Preparar escena principal")]
    public static void PrepareMainScene()
    {
        GenerateMainScene();
        EditorUtility.DisplayDialog("RIO54", "Escena principal generada y agregada a Build Profiles.\n\nAbrí Assets/Scenes/RIO54Main.unity y pulsá Play para probar el port Unity.", "OK");
    }

    private static void GenerateMainScene()
    {
        Directory.CreateDirectory("Assets/Scenes");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject game = new GameObject("RIO54 Game Controller");
        game.AddComponent<RIO54Game>();
        RIO54World.Create();
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        ApplyPlayerSettings();
        Debug.Log("RIO54 scene generated: " + ScenePath);
    }

    private static void ApplyPlayerSettings()
    {
        PlayerSettings.companyName = "RIO54 Independent Project";
        PlayerSettings.productName = "RIO54 - Archivo de lo inexplicado";
        PlayerSettings.bundleVersion = "1.3.0";
        PlayerSettings.defaultScreenWidth = 1280;
        PlayerSettings.defaultScreenHeight = 720;
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.runInBackground = true;
        PlayerSettings.WebGL.template = "PROJECT:RIO54";
        PlayerSettings.WebGL.dataCaching = true;
        PlayerSettings.WebGL.decompressionFallback = true;
    }

    [MenuItem("RIO54/2 - Configurar fuentes internacionales")]
    public static void ConfigureInternationalFonts()
    {
        string[] paths = { JapaneseFontPath, ChineseFontPath };
        var missing = paths.Where(p => !File.Exists(p)).ToArray();
        if (missing.Length > 0)
        {
            EditorUtility.DisplayDialog("RIO54 · Fuentes", "Faltan estas fuentes:\n\n" + string.Join("\n", missing) +
                "\n\nConsultá Assets/Resources/Fonts/README.txt para descargarlas legalmente desde Noto.", "OK");
            return;
        }

        try
        {
            ConfigureFontAssets();
            EditorUtility.DisplayDialog("RIO54 · Fuentes", "Fuentes configuradas e incrustadas por separado. Noto Sans CJK JP se utiliza en japonés y como fuente latina general; Noto Sans CJK SC se selecciona para chino simplificado.\n\nEl juego cambia de recurso tipográfico cuando cambia el idioma, sin depender de fuentes instaladas en el sistema operativo del jugador.", "OK");
        }
        catch (Exception ex)
        {
            Debug.LogException(ex);
            EditorUtility.DisplayDialog("RIO54 · Fuentes", ex.Message, "OK");
        }
    }

    // Shared by the interactive Editor menu and headless GameCI builds.
    // This keeps the CI path from relying on a user having clicked a menu item.
    private static void ConfigureFontAssets()
    {
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        ConfigureFontAsset(JapaneseFontPath, "Noto Sans CJK JP");
        ConfigureFontAsset(ChineseFontPath, "Noto Sans CJK SC");
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
    }

    private static void ConfigureFontAsset(string path, string displayName)
    {
        if (!File.Exists(path)) throw new FileNotFoundException("Falta la fuente " + displayName + ". Ejecutá Tools/setup_cjk_fonts.py.", path);
        AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
        TrueTypeFontImporter importer = AssetImporter.GetAtPath(path) as TrueTypeFontImporter;
        Font font = AssetDatabase.LoadAssetAtPath<Font>(path);
        if (importer == null || font == null)
            throw new Exception("Unity no pudo importar " + displayName + ". Revisá que sea un archivo OTF válido.");

        bool changed = false;
        if (!importer.includeFontData) { importer.includeFontData = true; changed = true; }
        if (importer.fontTextureCase != FontTextureCase.Dynamic) { importer.fontTextureCase = FontTextureCase.Dynamic; changed = true; }
        if (importer.fontSize != 24) { importer.fontSize = 24; changed = true; }
        if (importer.fontNames == null || importer.fontNames.Length != 0) { importer.fontNames = Array.Empty<string>(); changed = true; }
        if (importer.fontReferences == null || importer.fontReferences.Length != 0) { importer.fontReferences = Array.Empty<Font>(); changed = true; }
        if (changed) importer.SaveAndReimport();

        // Assert that the settings persisted after reimport.
        importer = AssetImporter.GetAtPath(path) as TrueTypeFontImporter;
        if (importer == null || !importer.includeFontData || importer.fontTextureCase != FontTextureCase.Dynamic)
            throw new Exception("No se pudo incrustar la fuente dinámica " + displayName + ".");
    }

    [MenuItem("RIO54/3 - Validar proyecto")]
    public static void ValidateProjectMenu()
    {
        string report = ValidateProject(out bool ok);
        if (ok) Debug.Log("RIO54 validation passed:\n" + report);
        else Debug.LogError("RIO54 validation failed:\n" + report);
        EditorUtility.DisplayDialog("RIO54 · Validación", report, "OK");
    }

    private static string ValidateProject(out bool ok)
    {
        var errors = new List<string>();
        var notes = new List<string>();
        TextAsset data = Resources.Load<TextAsset>("RIO54Data");
        if (data == null) errors.Add("No se encuentra Resources/RIO54Data.json.");
        else
        {
            try
            {
                var root = SimpleJson.Parse(data.text) as Dictionary<string, object>;
                if (root == null) errors.Add("La raíz del JSON no es un objeto.");
                else
                {
                    var rawCases = root.ContainsKey("cases") ? root["cases"] as List<object> : null;
                    var ui = root.ContainsKey("ui") ? root["ui"] as Dictionary<string, object> : null;
                    var narrative = root.ContainsKey("narrative") ? root["narrative"] as Dictionary<string, object> : null;
                    if (rawCases == null || rawCases.Count != 4) errors.Add("La campaña debe contener exactamente 4 expedientes.");
                    if (ui == null || ui.Count != 8) errors.Add("La interfaz debe contener 8 idiomas.");
                    if (narrative == null || narrative.Count != 7) errors.Add("El contenido narrativo debe contener 7 traducciones además del español base.");
                    if (rawCases != null)
                    {
                        foreach (object item in rawCases)
                        {
                            var c = item as Dictionary<string, object>;
                            if (c == null) { errors.Add("Se encontró un expediente inválido."); continue; }
                            string id = Convert.ToString(c.ContainsKey("id") ? c["id"] : "?");
                            if (!(c.ContainsKey("clues") && c["clues"] is List<object> clues && clues.Count == 4)) errors.Add(id + ": debe tener cuatro pistas.");
                            if (!(c.ContainsKey("board") && c["board"] is List<object> board && board.Count == 3)) errors.Add(id + ": debe tener tres opciones del tablero.");
                            if (!(c.ContainsKey("verdict") && c["verdict"] is List<object> verdict && verdict.Count == 3)) errors.Add(id + ": debe tener tres conclusiones.");
                        }
                    }
                }
            }
            catch (Exception ex) { errors.Add("Error leyendo JSON: " + ex.Message); }
        }

        if (!File.Exists(TemplatePath)) errors.Add("Falta la plantilla web personalizada Assets/WebGLTemplates/RIO54/index.html.");
        if (!File.Exists(ScenePath)) notes.Add("La escena aún no fue generada. Usá RIO54 > 1 - Preparar escena principal.");
        if (Resources.Load<Font>("Fonts/NotoSansCJKjp-Regular") == null ||
            Resources.Load<Font>("Fonts/NotoSansCJKsc-Regular") == null ||
            !File.Exists(JapaneseLicensePath) || !File.Exists(ChineseLicensePath))
            notes.Add("Faltan fuentes Noto CJK o sus avisos LICENSE. Ejecutá Tools/setup_cjk_fonts.py antes de compilar.");

        ok = errors.Count == 0;
        var lines = new List<string>();
        lines.Add(ok ? "ESTRUCTURA CORRECTA" : "HAY ERRORES");
        lines.AddRange(errors.Select(x => "ERROR: " + x));
        lines.AddRange(notes.Select(x => "PENDIENTE: " + x));
        return string.Join("\n", lines);
    }

    [MenuItem("RIO54/4 - Compilar para WebGL")]
    public static void BuildWebGL()
    {
        if (!File.Exists(ScenePath)) GenerateMainScene();
        ApplyPlayerSettings();
        try { ConfigureFontAssets(); }
        catch (Exception ex)
        {
            Debug.LogException(ex);
            EditorUtility.DisplayDialog("RIO54 · Fuentes", ex.Message, "OK");
            return;
        }
        string fontMessage;
        if (!FontsReady(out fontMessage))
        {
            EditorUtility.DisplayDialog("RIO54 · Fuentes necesarias", fontMessage, "OK");
            return;
        }
        if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.WebGL)
        {
            bool switched = EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.WebGL, BuildTarget.WebGL);
            if (!switched)
            {
                EditorUtility.DisplayDialog("RIO54", "Unity no pudo cambiar a Web. Instalá Web Build Support desde Unity Hub y volvé a intentarlo.", "OK");
                return;
            }
            EditorUtility.DisplayDialog("RIO54", "Unity está cambiando la plataforma a Web. Esperá a que termine la reimportación y volvé a ejecutar RIO54 > 4 - Compilar para WebGL.", "OK");
            return;
        }
        BuildReport report = RunBuild();
        if (report.summary.result == BuildResult.Succeeded)
        {
            CopyThirdPartyNotices(OutputPath);
            ValidateBuildOutput();
            EditorUtility.DisplayDialog("RIO54", "Compilación completada.\n\nSalida:\n" + Path.GetFullPath(OutputPath) + "\n\nIncluye avisos de licencia en ThirdPartyNotices/NotoCJK. Probala mediante un servidor HTTP o publicala en un hosting compatible con Unity Web.", "OK");
        }
        else
            EditorUtility.DisplayDialog("RIO54", "La compilación falló. Revisá la consola de Unity. Errores: " + report.summary.totalErrors, "OK");
    }

    // GameCI entry point. Configure unity-builder with buildMethod: RIO54BuildTools.GameCIBuildWebGL.
    // The CI artifact is written to build/WebGL so GitHub Actions can upload it directly.
    public static void GameCIBuildWebGL()
    {
        try
        {
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.WebGL)
                throw new Exception("La plataforma activa no es WebGL. Verificá targetPlatform: WebGL y Web Build Support.");
            if (!File.Exists(ScenePath)) GenerateMainScene();
            ApplyPlayerSettings();
            ConfigureFontAssets();
            if (!FontsReady(out string fontMessage)) throw new Exception(fontMessage);
            Directory.CreateDirectory(CIOutputPath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            var options = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = CIOutputPath,
                target = BuildTarget.WebGL,
                options = BuildOptions.None
            };
            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != BuildResult.Succeeded)
                throw new Exception("Build WebGL falló: " + report.summary.result + " · errores: " + report.summary.totalErrors);
            CopyThirdPartyNotices(CIOutputPath);
            ValidateBuildOutputAt(CIOutputPath);
            Debug.Log("RIO54 GAMECI WEB BUILD OK: " + Path.GetFullPath(CIOutputPath));
            EditorApplication.Exit(0);
        }
        catch (Exception ex)
        {
            Debug.LogException(ex);
            EditorApplication.Exit(1);
        }
    }

    // Entry point for: Unity -batchmode -quit -projectPath <project> -buildTarget webgl -executeMethod RIO54BuildTools.BatchBuildWebGL
    public static void BatchBuildWebGL()
    {
        try
        {
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.WebGL)
                throw new Exception("La plataforma activa no es WebGL. Ejecutá Unity con -buildTarget WebGL y asegurate de tener Web Build Support instalado.");
            if (!File.Exists(ScenePath)) GenerateMainScene();
            ApplyPlayerSettings();
            ConfigureFontAssets();
            if (!FontsReady(out string message)) throw new Exception(message);
            BuildReport report = RunBuild();
            if (report.summary.result != BuildResult.Succeeded)
                throw new Exception("BuildPlayer terminó con " + report.summary.result + " y " + report.summary.totalErrors + " errores.");
            CopyThirdPartyNotices(OutputPath);
            ValidateBuildOutput();
            Debug.Log("RIO54 WEB BUILD OK: " + Path.GetFullPath(OutputPath));
            EditorApplication.Exit(0);
        }
        catch (Exception ex)
        {
            Debug.LogException(ex);
            EditorApplication.Exit(1);
        }
    }

    private static BuildReport RunBuild()
    {
        Directory.CreateDirectory(OutputPath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        var options = new BuildPlayerOptions
        {
            scenes = new[] { ScenePath },
            locationPathName = OutputPath,
            target = BuildTarget.WebGL,
            options = BuildOptions.None
        };
        return BuildPipeline.BuildPlayer(options);
    }

    private static bool FontsReady(out string message)
    {
        var missing = new List<string>();
        string[] paths = { JapaneseFontPath, ChineseFontPath };
        string[] names = { "NotoSansCJKjp-Regular.otf", "NotoSansCJKsc-Regular.otf" };
        string[] licenses = { JapaneseLicensePath, ChineseLicensePath };
        for (int i = 0; i < paths.Length; i++)
        {
            if (Resources.Load<Font>("Fonts/" + Path.GetFileNameWithoutExtension(names[i])) == null)
            {
                missing.Add(names[i] + " (no está importada en Resources)");
                continue;
            }
            TrueTypeFontImporter importer = AssetImporter.GetAtPath(paths[i]) as TrueTypeFontImporter;
            if (importer == null || importer.fontTextureCase != FontTextureCase.Dynamic || !importer.includeFontData)
                missing.Add(names[i] + " (debe estar incrustada como fuente dinámica)");
            if (!File.Exists(licenses[i])) missing.Add(Path.GetFileName(licenses[i]) + " (aviso de licencia requerido)");
        }
        message = missing.Count == 0 ? "OK" : "Para publicar los ocho idiomas sin glifos ausentes, agregá/configurá estas fuentes en Assets/Resources/Fonts:\n\n" + string.Join("\n", missing) + "\n\nConsultá README.txt en esa carpeta.";
        return missing.Count == 0;
    }

    private static void CopyThirdPartyNotices(string outputPath)
    {
        string destination = Path.Combine(outputPath, "ThirdPartyNotices", "NotoCJK");
        Directory.CreateDirectory(destination);
        string[] licenses = { JapaneseLicensePath, ChineseLicensePath };
        foreach (string license in licenses)
        {
            if (!File.Exists(license)) throw new FileNotFoundException("No se puede publicar sin el aviso de licencia correspondiente.", license);
            File.Copy(license, Path.Combine(destination, Path.GetFileName(license)), true);
        }
    }

    private static void ValidateBuildOutput()
    {
        ValidateBuildOutputAt(OutputPath);
    }

    private static void ValidateBuildOutputAt(string outputPath)
    {
        string index = Path.Combine(outputPath, "index.html");
        if (!Directory.Exists(outputPath)) throw new Exception("No existe la carpeta de salida: " + outputPath);
        string[] all = Directory.GetFiles(outputPath, "*", SearchOption.AllDirectories);
        string[] wasm = all.Where(p => Path.GetFileName(p).IndexOf(".wasm", StringComparison.OrdinalIgnoreCase) >= 0).ToArray();
        string[] loader = all.Where(p => Path.GetFileName(p).IndexOf(".loader.js", StringComparison.OrdinalIgnoreCase) >= 0).ToArray();
        string[] framework = all.Where(p => Path.GetFileName(p).IndexOf(".framework.js", StringComparison.OrdinalIgnoreCase) >= 0).ToArray();
        string noticeDir = Path.Combine(outputPath, "ThirdPartyNotices", "NotoCJK");
        bool noticesPresent = File.Exists(Path.Combine(noticeDir, Path.GetFileName(JapaneseLicensePath))) &&
                              File.Exists(Path.Combine(noticeDir, Path.GetFileName(ChineseLicensePath)));
        if (!File.Exists(index) || wasm.Length == 0 || loader.Length == 0 || framework.Length == 0 || !noticesPresent)
            throw new Exception("La salida debe incluir index.html, .wasm, .loader.js, .framework.js y los dos avisos LICENSE en ThirdPartyNotices/NotoCJK.");
    }

    [MenuItem("RIO54/5 - Abrir carpeta de compilación")]
    public static void OpenBuildFolder()
    {
        Directory.CreateDirectory(OutputPath);
        EditorUtility.RevealInFinder(Path.GetFullPath(OutputPath));
    }
}
#endif
