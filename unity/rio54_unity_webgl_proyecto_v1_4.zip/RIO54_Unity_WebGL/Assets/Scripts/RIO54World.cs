using UnityEngine;

// Procedural night skyline and hovering object, generated entirely at runtime.
public class RIO54World : MonoBehaviour
{
    private Transform craft;
    private Vector3 craftBase;
    private float elapsed;

    public static void Create()
    {
        GameObject root = new GameObject("RIO54 Procedural Night Scene");
        root.AddComponent<RIO54World>();
    }

    private void Start() { Build(); }

    private void Build()
    {
        Camera camera = Camera.main;
        if (camera == null)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            camera = cameraObject.AddComponent<Camera>();
            cameraObject.tag = "MainCamera";
        }
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.012f, 0.035f, 0.055f);
        camera.fieldOfView = 52f;
        camera.transform.position = new Vector3(0, 5.2f, -19f);
        camera.transform.LookAt(new Vector3(0, 4.2f, 4f));
        camera.farClipPlane = 150f;

        RenderSettings.ambientLight = new Color(0.18f, 0.25f, 0.28f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.025f, 0.065f, 0.08f);
        RenderSettings.fogDensity = 0.012f;

        GameObject key = new GameObject("Moonlight");
        Light directional = key.AddComponent<Light>();
        directional.type = LightType.Directional;
        directional.intensity = 0.48f;
        directional.color = new Color(0.58f, 0.78f, 0.82f);
        key.transform.rotation = Quaternion.Euler(28, -25, 0);

        Material buildingMat = MaterialFor(new Color(0.018f, 0.055f, 0.07f), 0.12f);
        Material buildingMat2 = MaterialFor(new Color(0.028f, 0.075f, 0.09f), 0.16f);
        Material windowMat = EmissionMaterial(new Color(0.95f, 0.48f, 0.18f));
        Material starMat = EmissionMaterial(new Color(0.56f, 0.77f, 0.82f));
        Random.InitState(5400);
        for (int i = 0; i < 52; i++)
        {
            float x = -32f + i * 1.25f;
            float width = Random.Range(0.65f, 1.25f);
            float height = Random.Range(2.2f, 7.5f);
            float depth = Random.Range(1.2f, 3.2f);
            GameObject building = GameObject.CreatePrimitive(PrimitiveType.Cube);
            building.name = "City building " + i;
            building.transform.SetParent(transform);
            building.transform.position = new Vector3(x, height * 0.5f - 0.2f, Random.Range(2.5f, 7f));
            building.transform.localScale = new Vector3(width, height, depth);
            building.GetComponent<Renderer>().sharedMaterial = i % 3 == 0 ? buildingMat2 : buildingMat;
            Object.Destroy(building.GetComponent<Collider>());
            // A small number of lit windows per tower, kept low-poly for Web builds.
            if (i % 2 == 0)
            {
                for (int w = 0; w < 2; w++)
                {
                    GameObject window = GameObject.CreatePrimitive(PrimitiveType.Quad);
                    window.name = "Warm window";
                    window.transform.SetParent(building.transform);
                    window.transform.localPosition = new Vector3(-0.14f + w * 0.28f, Random.Range(-0.25f, 0.28f), -0.505f);
                    window.transform.localRotation = Quaternion.identity;
                    window.transform.localScale = new Vector3(0.1f, 0.14f, 1f);
                    window.GetComponent<Renderer>().sharedMaterial = windowMat;
                    Object.Destroy(window.GetComponent<Collider>());
                }
            }
        }

        GameObject moon = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        moon.name = "Moon";
        moon.transform.position = new Vector3(7.5f, 11.5f, 13f);
        moon.transform.localScale = Vector3.one * 3.3f;
        moon.GetComponent<Renderer>().sharedMaterial = EmissionMaterial(new Color(0.62f, 0.78f, 0.76f));
        Object.Destroy(moon.GetComponent<Collider>());

        CreateStarfield(starMat, 180);

        craft = new GameObject("RIO54 unidentified aerial object").transform;
        craft.SetParent(transform);
        craftBase = new Vector3(1.5f, 8.4f, 4.5f);
        craft.position = craftBase;
        GameObject hull = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        hull.name = "Metallic disc";
        hull.transform.SetParent(craft);
        hull.transform.localPosition = Vector3.zero;
        hull.transform.localScale = new Vector3(3.4f, 0.42f, 1.65f);
        hull.GetComponent<Renderer>().sharedMaterial = MaterialFor(new Color(0.22f, 0.45f, 0.48f), 0.72f);
        Object.Destroy(hull.GetComponent<Collider>());

        GameObject dome = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        dome.name = "Translucent dome";
        dome.transform.SetParent(craft);
        dome.transform.localPosition = new Vector3(0, 0.22f, 0);
        dome.transform.localScale = new Vector3(1.15f, 0.5f, 0.8f);
        dome.GetComponent<Renderer>().sharedMaterial = EmissionMaterial(new Color(0.28f, 0.62f, 0.64f));
        Object.Destroy(dome.GetComponent<Collider>());

        GameObject beam = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        beam.name = "Soft scanning beam";
        beam.transform.SetParent(craft);
        beam.transform.localPosition = new Vector3(0, -2.5f, 0);
        beam.transform.localScale = new Vector3(1.9f, 2.5f, 1.9f);
        beam.GetComponent<Renderer>().sharedMaterial = TransparentMaterial(new Color(0.16f, 0.65f, 0.68f, 0.12f));
        Object.Destroy(beam.GetComponent<Collider>());

        for (int i = 0; i < 5; i++)
        {
            GameObject lamp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            lamp.name = "Amber running light";
            lamp.transform.SetParent(craft);
            lamp.transform.localPosition = new Vector3(-1.2f + i * 0.6f, -0.08f, -0.1f);
            lamp.transform.localScale = Vector3.one * 0.11f;
            lamp.GetComponent<Renderer>().sharedMaterial = EmissionMaterial(new Color(1f, 0.52f, 0.19f));
            Object.Destroy(lamp.GetComponent<Collider>());
        }
    }

    private void CreateStarfield(Material material, int count)
    {
        // One static mesh instead of hundreds of individual sphere renderers.
        // This reduces draw calls for WebGL without changing the night-sky composition.
        var vertices = new Vector3[count * 4];
        var triangles = new int[count * 6];
        var uv = new Vector2[count * 4];
        for (int i = 0; i < count; i++)
        {
            float x = Random.Range(-35f, 35f);
            float y = Random.Range(5f, 24f);
            float z = Random.Range(12f, 30f);
            float size = Random.Range(0.035f, 0.09f);
            int v = i * 4;
            vertices[v] = new Vector3(x - size, y - size, z);
            vertices[v + 1] = new Vector3(x - size, y + size, z);
            vertices[v + 2] = new Vector3(x + size, y + size, z);
            vertices[v + 3] = new Vector3(x + size, y - size, z);
            uv[v] = new Vector2(0, 0); uv[v + 1] = new Vector2(0, 1);
            uv[v + 2] = new Vector2(1, 1); uv[v + 3] = new Vector2(1, 0);
            int t = i * 6;
            triangles[t] = v; triangles[t + 1] = v + 1; triangles[t + 2] = v + 2;
            triangles[t + 3] = v; triangles[t + 4] = v + 2; triangles[t + 5] = v + 3;
        }
        var mesh = new Mesh { name = "RIO54 Starfield Mesh" };
        mesh.vertices = vertices; mesh.triangles = triangles; mesh.uv = uv; mesh.RecalculateBounds();
        GameObject field = new GameObject("RIO54 Starfield · single draw call");
        field.transform.SetParent(transform, false);
        field.AddComponent<MeshFilter>().sharedMesh = mesh;
        field.AddComponent<MeshRenderer>().sharedMaterial = material;
        mesh.UploadMeshData(true);
    }

    private void Update()
    {
        if (craft == null) return;
        elapsed += Time.deltaTime;
        craft.position = craftBase + new Vector3(Mathf.Sin(elapsed * 0.32f) * 0.42f, Mathf.Sin(elapsed * 0.6f) * 0.12f, 0);
        craft.rotation = Quaternion.Euler(0, Mathf.Sin(elapsed * 0.22f) * 3.5f, Mathf.Sin(elapsed * 0.38f) * 1.2f);
    }

    private static Material MaterialFor(Color color, float metallic)
    {
        Shader shader = Shader.Find("Standard");
        var material = new Material(shader);
        material.color = color;
        material.SetFloat("_Metallic", metallic);
        material.SetFloat("_Glossiness", 0.42f);
        return material;
    }

    private static Material EmissionMaterial(Color color)
    {
        Material m = MaterialFor(color, 0.18f);
        m.EnableKeyword("_EMISSION");
        m.SetColor("_EmissionColor", color * 1.6f);
        return m;
    }

    private static Material TransparentMaterial(Color color)
    {
        var m = new Material(Shader.Find("Standard"));
        m.SetFloat("_Mode", 3f);
        m.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        m.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        m.SetInt("_ZWrite", 0);
        m.DisableKeyword("_ALPHATEST_ON"); m.EnableKeyword("_ALPHABLEND_ON"); m.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        m.renderQueue = 3000;
        m.color = color;
        return m;
    }
}
