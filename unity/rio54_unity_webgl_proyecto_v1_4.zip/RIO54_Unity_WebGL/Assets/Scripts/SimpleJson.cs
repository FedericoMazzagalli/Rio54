using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

// Small dependency-free JSON reader for the bundled RIO54 narrative data.
public static class SimpleJson
{
    public static object Parse(string json)
    {
        if (string.IsNullOrEmpty(json)) return null;
        var parser = new Parser(json);
        return parser.ParseValue();
    }

    private sealed class Parser
    {
        private readonly string text;
        private int index;
        public Parser(string source) { text = source; }

        private void SkipWhitespace()
        {
            while (index < text.Length && char.IsWhiteSpace(text[index])) index++;
        }

        public object ParseValue()
        {
            SkipWhitespace();
            if (index >= text.Length) return null;
            char c = text[index];
            if (c == '{') return ParseObject();
            if (c == '[') return ParseArray();
            if (c == '"') return ParseString();
            if (c == 't') { Expect("true"); return true; }
            if (c == 'f') { Expect("false"); return false; }
            if (c == 'n') { Expect("null"); return null; }
            return ParseNumber();
        }

        private Dictionary<string, object> ParseObject()
        {
            var result = new Dictionary<string, object>();
            index++; SkipWhitespace();
            if (index < text.Length && text[index] == '}') { index++; return result; }
            while (index < text.Length)
            {
                SkipWhitespace();
                string key = ParseString();
                SkipWhitespace();
                if (index >= text.Length || text[index] != ':') throw new FormatException("Expected ':' at " + index);
                index++;
                result[key] = ParseValue();
                SkipWhitespace();
                if (index < text.Length && text[index] == ',') { index++; continue; }
                if (index < text.Length && text[index] == '}') { index++; break; }
                throw new FormatException("Expected ',' or '}' at " + index);
            }
            return result;
        }

        private List<object> ParseArray()
        {
            var result = new List<object>();
            index++; SkipWhitespace();
            if (index < text.Length && text[index] == ']') { index++; return result; }
            while (index < text.Length)
            {
                result.Add(ParseValue());
                SkipWhitespace();
                if (index < text.Length && text[index] == ',') { index++; continue; }
                if (index < text.Length && text[index] == ']') { index++; break; }
                throw new FormatException("Expected ',' or ']' at " + index);
            }
            return result;
        }

        private string ParseString()
        {
            if (index >= text.Length || text[index] != '"') throw new FormatException("Expected string at " + index);
            index++;
            var sb = new StringBuilder();
            while (index < text.Length)
            {
                char c = text[index++];
                if (c == '"') return sb.ToString();
                if (c == '\\')
                {
                    if (index >= text.Length) break;
                    char e = text[index++];
                    switch (e)
                    {
                        case '"': sb.Append('"'); break;
                        case '\\': sb.Append('\\'); break;
                        case '/': sb.Append('/'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case 'n': sb.Append('\n'); break;
                        case 'r': sb.Append('\r'); break;
                        case 't': sb.Append('\t'); break;
                        case 'u':
                            if (index + 4 > text.Length) throw new FormatException("Bad unicode escape");
                            string hex = text.Substring(index, 4);
                            sb.Append((char)int.Parse(hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture));
                            index += 4;
                            break;
                        default: sb.Append(e); break;
                    }
                }
                else sb.Append(c);
            }
            throw new FormatException("Unterminated JSON string");
        }

        private object ParseNumber()
        {
            int start = index;
            if (text[index] == '-') index++;
            while (index < text.Length && char.IsDigit(text[index])) index++;
            if (index < text.Length && text[index] == '.')
            {
                index++;
                while (index < text.Length && char.IsDigit(text[index])) index++;
            }
            if (index < text.Length && (text[index] == 'e' || text[index] == 'E'))
            {
                index++;
                if (index < text.Length && (text[index] == '+' || text[index] == '-')) index++;
                while (index < text.Length && char.IsDigit(text[index])) index++;
            }
            string number = text.Substring(start, index - start);
            if (long.TryParse(number, NumberStyles.Integer, CultureInfo.InvariantCulture, out long l)) return l;
            if (double.TryParse(number, NumberStyles.Float, CultureInfo.InvariantCulture, out double d)) return d;
            throw new FormatException("Invalid number at " + start);
        }

        private void Expect(string token)
        {
            if (index + token.Length > text.Length || string.CompareOrdinal(text, index, token, 0, token.Length) != 0)
                throw new FormatException("Expected " + token + " at " + index);
            index += token.Length;
        }
    }
}
