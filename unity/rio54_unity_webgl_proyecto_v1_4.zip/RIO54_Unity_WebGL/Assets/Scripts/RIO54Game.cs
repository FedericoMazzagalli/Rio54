using System;
using System.Collections.Generic;
using UnityEngine;

public class RIO54Game : MonoBehaviour
{
    private enum ScreenState { Home, Cases, Intro, Play, Clue, Board, Verdict, Ending, Archive, Credits }
    private static readonly string[] LanguageCodes = { "es", "en", "pt-BR", "fr", "de", "it", "ja", "zh-CN" };
    private static readonly string[] LanguageNames = { "Español", "English", "Português", "Français", "Deutsch", "Italiano", "日本語", "简体中文" };
    private static readonly string[] TopFields = { "category", "title", "subtitle", "short", "description", "note", "intro", "boardQ", "verdictQ", "ending", "debrief" };
    private static readonly string[] ClueFields = { "title", "kind", "teaser", "body", "source", "good", "bad", "goodReply", "badReply" };

    [Serializable] public class SaveBlob { public int version = 1; public string current = "c1"; public string[] solved = new string[0]; public RunBlob[] runs = new RunBlob[0]; }
    [Serializable] public class RunBlob { public string id; public int[] found = new int[0]; public int method; public bool board; public bool solved; public string grade; }
    private sealed class RunState { public List<int> found = new List<int>(); public int method; public bool board; public bool solved; public string grade = ""; }
    private sealed class ClueView { public string icon, title, kind, teaser, body, source, good, bad, goodReply, badReply; }
    private sealed class OptionView { public string text, feedback; public bool correct; }
    private sealed class CaseView
    {
        public string id, num, icon, category, title, subtitle, shortText, description, note, intro, boardQ, verdictQ, ending, debrief;
        public List<ClueView> clues = new List<ClueView>();
        public List<OptionView> board = new List<OptionView>();
        public List<OptionView> verdict = new List<OptionView>();
        public List<string[]> sources = new List<string[]>();
    }

    [Header("RIO54 content is bundled in Resources/RIO54Data.json")]
    public TextAsset dataAsset;

    private Dictionary<string, object> root;
    private Dictionary<string, object> ui;
    private Dictionary<string, object> narratives;
    private readonly List<CaseView> cases = new List<CaseView>();
    private readonly Dictionary<string, RunState> runs = new Dictionary<string, RunState>();
    private readonly List<string> solved = new List<string>();
    private string currentCaseId = "c1";
    private string language = "es";
    private int languageIndex;
    private ScreenState screen = ScreenState.Home;
    private int selectedClue = -1;
    private int selectedBoard = -1;
    private int selectedVerdict = -1;
    private string feedback = "";
    private bool feedbackGood;
    private bool confirmReset;
    private Vector2 scroll;
    private GUIStyle titleStyle, subtitleStyle, bodyStyle, cardStyle, buttonStyle, smallStyle, headerStyle, accentStyle;
    private Font runtimeFont;
    private bool stylesReady;
    private Texture2D overlayTexture;

    private Dictionary<string, object> currentUi;
    private Dictionary<string, object> currentNarrative;

    private void Awake()
    {
        if (dataAsset == null) dataAsset = Resources.Load<TextAsset>("RIO54Data");
        if (dataAsset == null)
        {
            Debug.LogError("RIO54Data.json not found in Resources.");
            return;
        }
        try
        {
            root = SimpleJson.Parse(dataAsset.text) as Dictionary<string, object>;
            if (root == null) throw new Exception("Invalid root JSON object");
            ui = AsDict(Get(root, "ui"));
            narratives = AsDict(Get(root, "narrative"));
            LoadCases();
            LoadSave();
            LoadLanguage();
        }
        catch (Exception ex) { Debug.LogError("RIO54 startup error: " + ex); }
    }

    private void LoadCases()
    {
        cases.Clear();
        List<object> rawCases = AsList(Get(root, "cases"));
        foreach (object raw in rawCases)
        {
            Dictionary<string, object> d = AsDict(raw);
            var c = new CaseView();
            c.id = Str(d, "id"); c.num = Str(d, "num"); c.icon = Str(d, "icon");
            c.category = Str(d, "category"); c.title = Str(d, "title"); c.subtitle = Str(d, "subtitle");
            c.shortText = Str(d, "short"); c.description = Str(d, "description"); c.note = Str(d, "note"); c.intro = Str(d, "intro");
            c.boardQ = Str(d, "boardQ"); c.verdictQ = Str(d, "verdictQ"); c.ending = Str(d, "ending"); c.debrief = Str(d, "debrief");
            foreach (object clueObj in AsList(Get(d, "clues")))
            {
                Dictionary<string, object> cd = AsDict(clueObj);
                c.clues.Add(new ClueView {
                    icon = Str(cd, "icon"), title = Str(cd, "title"), kind = Str(cd, "kind"), teaser = Str(cd, "teaser"),
                    body = Str(cd, "body"), source = Str(cd, "source"), good = Str(cd, "good"), bad = Str(cd, "bad"),
                    goodReply = Str(cd, "goodReply"), badReply = Str(cd, "badReply")
                });
            }
            ReadOptions(c.board, Get(d, "board"));
            ReadOptions(c.verdict, Get(d, "verdict"));
            foreach (object s in AsList(Get(d, "sources")))
            {
                List<object> a = AsList(s);
                if (a.Count >= 2) c.sources.Add(new string[] { Convert.ToString(a[0]), Convert.ToString(a[1]) });
            }
            cases.Add(c);
            if (!runs.ContainsKey(c.id)) runs[c.id] = new RunState();
        }
    }

    private void ReadOptions(List<OptionView> target, object raw)
    {
        foreach (object item in AsList(raw))
        {
            Dictionary<string, object> d = AsDict(item);
            target.Add(new OptionView { text = Str(d, "text"), feedback = Str(d, "feedback"), correct = Bool(d, "correct") });
        }
    }

    private void LoadLanguage()
    {
        language = PlayerPrefs.GetString("RIO54_LANGUAGE", "es");
        languageIndex = Array.IndexOf(LanguageCodes, language);
        if (languageIndex < 0) { languageIndex = 0; language = "es"; }
        ApplyLanguage(language);
    }

    private void ApplyLanguage(string code)
    {
        if (string.IsNullOrEmpty(code) || !Array.Exists(LanguageCodes, x => x == code)) code = "es";
        language = code;
        languageIndex = Array.IndexOf(LanguageCodes, language);
        currentUi = AsDict(Get(ui, language));
        currentNarrative = AsDict(Get(narratives, language));
        if (cases.Count > 0)
        {
            ResetCasesToSpanishBase();
            if (code != "es") ApplyNarrativeToCases();
        }
        PlayerPrefs.SetString("RIO54_LANGUAGE", language);
        PlayerPrefs.Save();
        if (stylesReady) ApplyLocaleFont();
    }

    private void ResetCasesToSpanishBase()
    {
        List<object> baseCases = AsList(Get(root, "cases"));
        for (int ci = 0; ci < cases.Count && ci < baseCases.Count; ci++)
        {
            CaseView c = cases[ci]; Dictionary<string, object> d = AsDict(baseCases[ci]);
            c.category = Str(d, "category"); c.title = Str(d, "title"); c.subtitle = Str(d, "subtitle");
            c.shortText = Str(d, "short"); c.description = Str(d, "description"); c.note = Str(d, "note"); c.intro = Str(d, "intro");
            c.boardQ = Str(d, "boardQ"); c.verdictQ = Str(d, "verdictQ"); c.ending = Str(d, "ending"); c.debrief = Str(d, "debrief");
            List<object> rawClues = AsList(Get(d, "clues"));
            for (int i = 0; i < c.clues.Count && i < rawClues.Count; i++)
            {
                Dictionary<string, object> cl = AsDict(rawClues[i]); ClueView target = c.clues[i];
                target.title = Str(cl, "title"); target.kind = Str(cl, "kind"); target.teaser = Str(cl, "teaser");
                target.body = Str(cl, "body"); target.source = Str(cl, "source"); target.good = Str(cl, "good"); target.bad = Str(cl, "bad");
                target.goodReply = Str(cl, "goodReply"); target.badReply = Str(cl, "badReply");
            }
            ResetOptions(c.board, Get(d, "board")); ResetOptions(c.verdict, Get(d, "verdict"));
        }
    }

    private void ResetOptions(List<OptionView> target, object raw)
    {
        List<object> arr = AsList(raw);
        for (int i = 0; i < target.Count && i < arr.Count; i++)
        {
            Dictionary<string, object> d = AsDict(arr[i]);
            target[i].text = Str(d, "text"); target[i].feedback = Str(d, "feedback"); target[i].correct = Bool(d, "correct");
        }
    }

    private void ApplyNarrativeToCases()
    {
        List<object> baseCases = AsList(Get(root, "cases"));
        for (int ci = 0; ci < cases.Count && ci < baseCases.Count; ci++)
        {
            CaseView c = cases[ci];
            Dictionary<string, object> pack = AsDict(Get(currentNarrative, c.id));
            List<object> top = AsList(Get(pack, "top"));
            if (top.Count >= TopFields.Length)
            {
                c.category = AtString(top, 0, c.category); c.title = AtString(top, 1, c.title); c.subtitle = AtString(top, 2, c.subtitle);
                c.shortText = AtString(top, 3, c.shortText); c.description = AtString(top, 4, c.description); c.note = AtString(top, 5, c.note);
                c.intro = AtString(top, 6, c.intro); c.boardQ = AtString(top, 7, c.boardQ); c.verdictQ = AtString(top, 8, c.verdictQ);
                c.ending = AtString(top, 9, c.ending); c.debrief = AtString(top, 10, c.debrief);
            }
            List<object> cluePacks = AsList(Get(pack, "clues"));
            for (int i = 0; i < c.clues.Count && i < cluePacks.Count; i++)
            {
                List<object> fields = AsList(cluePacks[i]); ClueView cl = c.clues[i];
                if (fields.Count >= ClueFields.Length)
                {
                    cl.title = AtString(fields, 0, cl.title); cl.kind = AtString(fields, 1, cl.kind); cl.teaser = AtString(fields, 2, cl.teaser);
                    cl.body = AtString(fields, 3, cl.body); cl.source = AtString(fields, 4, cl.source); cl.good = AtString(fields, 5, cl.good);
                    cl.bad = AtString(fields, 6, cl.bad); cl.goodReply = AtString(fields, 7, cl.goodReply); cl.badReply = AtString(fields, 8, cl.badReply);
                }
            }
            ApplyOptionTranslations(c.board, Get(pack, "board"));
            ApplyOptionTranslations(c.verdict, Get(pack, "verdict"));
        }
    }

    private void ApplyOptionTranslations(List<OptionView> options, object translated)
    {
        List<object> arr = AsList(translated);
        for (int i = 0; i < options.Count && i < arr.Count; i++)
        {
            List<object> fields = AsList(arr[i]);
            if (fields.Count > 0) options[i].text = Convert.ToString(fields[0]);
            if (fields.Count > 1 && !string.IsNullOrEmpty(Convert.ToString(fields[1]))) options[i].feedback = Convert.ToString(fields[1]);
        }
    }

    private void LoadSave()
    {
        string raw = PlayerPrefs.GetString("RIO54_SAVE_V1", "");
        if (!string.IsNullOrEmpty(raw))
        {
            try
            {
                SaveBlob blob = JsonUtility.FromJson<SaveBlob>(raw);
                if (blob != null)
                {
                    currentCaseId = string.IsNullOrEmpty(blob.current) ? "c1" : blob.current;
                    if (blob.solved != null) solved.AddRange(blob.solved);
                    if (blob.runs != null)
                    {
                        foreach (RunBlob saved in blob.runs)
                        {
                            if (saved == null || string.IsNullOrEmpty(saved.id)) continue;
                            RunState r = new RunState();
                            if (saved.found != null) r.found.AddRange(saved.found);
                            r.method = saved.method; r.board = saved.board; r.solved = saved.solved; r.grade = saved.grade ?? "";
                            runs[saved.id] = r;
                        }
                    }
                }
            }
            catch (Exception ex) { Debug.LogWarning("Ignoring invalid RIO54 save: " + ex.Message); }
        }
    }

    private void Save()
    {
        var blob = new SaveBlob();
        blob.current = currentCaseId; blob.solved = solved.ToArray();
        var savedRuns = new List<RunBlob>();
        foreach (var pair in runs)
        {
            savedRuns.Add(new RunBlob { id = pair.Key, found = pair.Value.found.ToArray(), method = pair.Value.method, board = pair.Value.board, solved = pair.Value.solved, grade = pair.Value.grade });
        }
        blob.runs = savedRuns.ToArray();
        PlayerPrefs.SetString("RIO54_SAVE_V1", JsonUtility.ToJson(blob));
        PlayerPrefs.Save();
    }

    private void OnGUI()
    {
        if (cases.Count == 0) return;
        EnsureStyles();
        float scale = Mathf.Clamp(Screen.width / 1280f, 0.68f, 1.15f);
        Matrix4x4 oldMatrix = GUI.matrix;
        GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(scale, scale, 1f));
        float w = Screen.width / scale;
        float h = Screen.height / scale;
        if (overlayTexture != null) GUI.DrawTexture(new Rect(0, 0, w, h), overlayTexture);
        GUILayout.BeginArea(new Rect(18, 12, w - 36, h - 24));
        DrawHeader();
        GUILayout.Space(8);
        scroll = GUILayout.BeginScrollView(scroll, false, true, GUILayout.Height(Mathf.Max(250, h - 118)));
        GUILayout.BeginVertical();
        switch (screen)
        {
            case ScreenState.Home: DrawHome(); break;
            case ScreenState.Cases: DrawCases(); break;
            case ScreenState.Intro: DrawIntro(); break;
            case ScreenState.Play: DrawPlay(); break;
            case ScreenState.Clue: DrawClue(); break;
            case ScreenState.Board: DrawBoard(); break;
            case ScreenState.Verdict: DrawVerdict(); break;
            case ScreenState.Ending: DrawEnding(); break;
            case ScreenState.Archive: DrawArchive(); break;
            case ScreenState.Credits: DrawCredits(); break;
        }
        GUILayout.EndVertical();
        GUILayout.EndScrollView();
        GUILayout.BeginHorizontal();
        GUILayout.Label("RIO54 · " + Tx("brandTag", "ARCHIVE OF THE UNEXPLAINED"), smallStyle);
        GUILayout.FlexibleSpace();
        GUILayout.Label("UNITY WEB · " + language.ToUpperInvariant(), smallStyle);
        GUILayout.EndHorizontal();
        GUILayout.EndArea();
        GUI.matrix = oldMatrix;
    }

    private void DrawHeader()
    {
        GUILayout.BeginHorizontal(cardStyle);
        GUILayout.Label("◉  RIO54", headerStyle, GUILayout.Width(170));
        GUILayout.FlexibleSpace();
        if (GUILayout.Button(Tx("home", "Home"), buttonStyle, GUILayout.Width(90))) { screen = ScreenState.Home; feedback = ""; }
        if (GUILayout.Button(Tx("myArchive", "My archive"), buttonStyle, GUILayout.Width(120))) { screen = ScreenState.Archive; }
        if (GUILayout.Button(Tx("continue", "Continue"), buttonStyle, GUILayout.Width(100))) ContinueGame();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.Label(Tx("language", "Language") + ":", smallStyle, GUILayout.Width(85));
        int next = GUILayout.SelectionGrid(languageIndex, LanguageNames, 4, GUILayout.Height(46));
        if (next != languageIndex && next >= 0 && next < LanguageCodes.Length)
        {
            languageIndex = next; ApplyLanguage(LanguageCodes[next]);
            feedback = "";
        }
        GUILayout.EndHorizontal();
    }

    private void DrawHome()
    {
        GUILayout.Space(18);
        GUILayout.Label("RIO54 · " + Tx("brandTag", "ARCHIVE OF THE UNEXPLAINED"), accentStyle);
        GUILayout.Label(Tx("heroTitle", "The sky does not always tell the whole story."), titleStyle);
        GUILayout.Label(Tx("heroLead", "Four case files. Decades of questions. Investigate, connect documents, and distinguish what we know from what we still do not know."), bodyStyle);
        GUILayout.Space(8);
        if (confirmReset)
        {
            GUILayout.BeginVertical(cardStyle);
            GUILayout.Label(Tx("resetConfirm", "Reset progress and delete all saved case files?"), subtitleStyle);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(Tx("confirmResetYes", "Yes, reset"), buttonStyle)) ResetAllGame();
            if (GUILayout.Button(Tx("confirmResetNo", "Keep progress"), buttonStyle)) confirmReset = false;
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();
        }
        GUILayout.BeginHorizontal();
        StatPill(Tx("statCases", "✦ 4 case files"));
        StatPill(Tx("statClues", "⌕ 16 clues"));
        StatPill("◷ 20–35 min");
        StatPill("▣ " + Tx("statOffline", "Play offline"));
        GUILayout.EndHorizontal();
        GUILayout.Space(18);
        if (GUILayout.Button(Tx("start", "Start investigation"), buttonStyle, GUILayout.Height(52))) RequestNewGame();
        if (GUILayout.Button(Tx("continueGame", "Continue game"), buttonStyle, GUILayout.Height(44))) ContinueGame();
        if (GUILayout.Button(Tx("seeCases", "View case files"), buttonStyle, GUILayout.Height(44))) screen = ScreenState.Cases;
        GUILayout.Space(18);
        GUILayout.Label(Tx("investigate", "Investigate") + "  ·  " + Tx("investigateDesc", "Explore archives, timelines and witness accounts."), bodyStyle);
        GUILayout.Label(Tx("connect", "Connect") + "  ·  " + Tx("connectDesc", "Link the clues you have gathered."), bodyStyle);
        GUILayout.Label(Tx("conclude", "Conclude") + "  ·  " + Tx("concludeDesc", "Defend a hypothesis without inventing certainty."), bodyStyle);
        GUILayout.Space(18);
        GUILayout.Label(Tx("languageNote", "Four complete case files available in eight languages."), smallStyle);
        GUILayout.Label(Tx("independentNote", "Independent narrative adaptation. Dialogue and characters are fictional."), smallStyle);
        if (GUILayout.Button(Tx("creditsSources", "Credits and sources"), buttonStyle)) screen = ScreenState.Credits;
    }

    private void DrawCases()
    {
        GUILayout.Label(Tx("mainCampaign", "Main campaign"), accentStyle);
        GUILayout.Label(Tx("selectCase", "Choose a case file"), titleStyle);
        GUILayout.Label(Tx("casesUnresolved", "{n} / 4 solved").Replace("{n}", solved.Count.ToString()), subtitleStyle);
        for (int i = 0; i < cases.Count; i++)
        {
            CaseView c = cases[i];
            bool open = IsUnlocked(i);
            RunState r = GetRun(c.id);
            GUILayout.BeginVertical(cardStyle);
            GUILayout.BeginHorizontal();
            GUILayout.Label(c.icon, titleStyle, GUILayout.Width(48));
            GUILayout.BeginVertical();
            GUILayout.Label(Tx("caseLabel", "CASE FILE {n}").Replace("{n}", c.num), accentStyle);
            GUILayout.Label(c.title, subtitleStyle);
            GUILayout.Label(c.shortText, bodyStyle);
            GUILayout.Label(open ? (r.solved ? Tx("caseDone", "SOLVED") : Tx("caseClues", "{n}/4 CLUES").Replace("{n}", r.found.Count.ToString())) : Tx("caseLocked", "LOCKED"), smallStyle);
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
            GUI.enabled = open;
            string action = r.solved ? Tx("caseReview", "Review case") : (r.found.Count > 0 ? Tx("caseContinue", "Continue") : Tx("caseInvestigate", "Investigate"));
            if (GUILayout.Button(action, buttonStyle, GUILayout.Height(40))) { currentCaseId = c.id; screen = ScreenState.Intro; Save(); }
            GUI.enabled = true;
            GUILayout.EndVertical();
        }
        if (GUILayout.Button(Tx("backHome", "Back to home"), buttonStyle)) screen = ScreenState.Home;
    }

    private void DrawIntro()
    {
        CaseView c = CurrentCase();
        GUILayout.Label(Tx("caseIntro", "CASE FILE {n}").Replace("{n}", c.num) + "  ·  " + c.category, accentStyle);
        GUILayout.Label(c.title, titleStyle);
        GUILayout.Label(c.subtitle, subtitleStyle);
        GUILayout.Label(c.description, bodyStyle);
        GUILayout.Space(8);
        GUILayout.BeginVertical(cardStyle);
        GUILayout.Label(Tx("documentaryNote", "NOTA DOCUMENTAL"), accentStyle);
        GUILayout.Label(c.note, bodyStyle);
        GUILayout.EndVertical();
        if (GUILayout.Button(Tx("openCase", "Open case file"), buttonStyle, GUILayout.Height(48)))
        {
            if (GetRun(c.id).solved) screen = ScreenState.Ending; else screen = ScreenState.Play;
        }
        if (GUILayout.Button(Tx("back", "Back"), buttonStyle)) screen = ScreenState.Cases;
    }

    private void DrawPlay()
    {
        CaseView c = CurrentCase(); RunState r = GetRun(c.id);
        GUILayout.Label(Tx("caseIntro", "CASE FILE {n}").Replace("{n}", c.num) + "  ·  " + c.title, accentStyle);
        GUILayout.Label(c.intro, bodyStyle);
        GUILayout.Label(Tx("clueRecorded", "{n} of 4 clues recorded").Replace("{n}", r.found.Count.ToString()), subtitleStyle);
        Rect progressRect = GUILayoutUtility.GetRect(1, 14, GUILayout.ExpandWidth(true));
        GUI.Box(progressRect, GUIContent.none);
        if (r.found.Count > 0) GUI.Box(new Rect(progressRect.x, progressRect.y, progressRect.width * r.found.Count / 4f, progressRect.height), GUIContent.none);
        for (int i = 0; i < c.clues.Count; i++)
        {
            ClueView cl = c.clues[i]; bool found = r.found.Contains(i);
            GUILayout.BeginVertical(cardStyle);
            GUILayout.BeginHorizontal(); GUILayout.Label(found ? "✓" : cl.icon, titleStyle, GUILayout.Width(45));
            GUILayout.BeginVertical(); GUILayout.Label(cl.title, subtitleStyle); GUILayout.Label(found ? Tx("clueRegistered", "Clue added · read again") : cl.teaser, smallStyle); GUILayout.EndVertical();
            GUILayout.EndHorizontal();
            if (GUILayout.Button(found ? Tx("caseReview", "Review clue") : Tx("examine", "Examine"), buttonStyle)) { selectedClue = i; screen = ScreenState.Clue; feedback = ""; }
            GUILayout.EndVertical();
        }
        GUI.enabled = r.found.Count == 4;
        if (GUILayout.Button(Tx("boardButton", "Relationship board · {n}/4").Replace("{n}", r.found.Count.ToString()), buttonStyle, GUILayout.Height(48))) { screen = ScreenState.Board; selectedBoard = -1; feedback = ""; }
        GUI.enabled = true;
        if (GUILayout.Button(Tx("saveExit", "Save and exit"), buttonStyle)) { Save(); screen = ScreenState.Cases; }
    }

    private void DrawClue()
    {
        CaseView c = CurrentCase(); RunState r = GetRun(c.id);
        if (selectedClue < 0 || selectedClue >= c.clues.Count) { screen = ScreenState.Play; return; }
        ClueView cl = c.clues[selectedClue];
        GUILayout.Label(Tx("clueMeta", "CLUE {n} · {kind}").Replace("{n}", (selectedClue + 1).ToString("00")).Replace("{kind}", cl.kind), accentStyle);
        GUILayout.Label(cl.title, titleStyle);
        GUILayout.Label(cl.body, bodyStyle);
        GUILayout.BeginVertical(cardStyle); GUILayout.Label(Tx("sourceScope", "SOURCE / SCOPE: {source}").Replace("{source}", cl.source), smallStyle); GUILayout.EndVertical();
        if (r.found.Contains(selectedClue))
        {
            GUILayout.Label(Tx("alreadyArchived", "This clue is already in your notebook."), subtitleStyle);
        }
        else
        {
            GUILayout.Label(Tx("howRecord", "How will you record this clue?"), subtitleStyle);
            if (GUILayout.Button(Tx("registerCarefully", "Record carefully: ") + cl.good, buttonStyle, GUILayout.MinHeight(56))) RegisterClue(true);
            if (GUILayout.Button(Tx("registerQuickly", "Record hastily: ") + cl.bad, buttonStyle, GUILayout.MinHeight(56))) RegisterClue(false);
        }
        if (!string.IsNullOrEmpty(feedback)) DrawFeedback(feedback, feedbackGood);
        if (GUILayout.Button(Tx("backToCase", "Back to case file"), buttonStyle)) { screen = ScreenState.Play; feedback = ""; }
    }

    private void RegisterClue(bool careful)
    {
        CaseView c = CurrentCase(); RunState r = GetRun(c.id); ClueView cl = c.clues[selectedClue];
        if (!r.found.Contains(selectedClue)) { r.found.Add(selectedClue); if (careful) r.method++; Save(); }
        feedback = careful ? cl.goodReply : cl.badReply; feedbackGood = careful;
    }

    private void DrawBoard()
    {
        CaseView c = CurrentCase(); RunState r = GetRun(c.id);
        GUILayout.Label(Tx("analysisDesk", "Analysis desk"), accentStyle);
        GUILayout.Label(Tx("connectClues", "Connect the clues"), titleStyle);
        GUILayout.Label(Tx("boardInstruction", "Read the four clues, then choose the relationship best supported by the material."), bodyStyle);
        foreach (ClueView cl in c.clues) GUILayout.Label("• " + cl.title + " — " + cl.teaser, smallStyle);
        GUILayout.Space(8); GUILayout.Label(c.boardQ, subtitleStyle);
        for (int i = 0; i < c.board.Count; i++)
        {
            bool selected = selectedBoard == i;
            if (GUILayout.Toggle(selected, c.board[i].text, "toggle", GUILayout.MinHeight(56))) selectedBoard = i;
        }
        if (!string.IsNullOrEmpty(feedback)) DrawFeedback(feedback, feedbackGood);
        if (GUILayout.Button(Tx("validateRelation", "Validate relationship"), buttonStyle, GUILayout.Height(48))) SubmitBoard();
        if (GUILayout.Button(Tx("backToCase", "Back to case file"), buttonStyle)) screen = ScreenState.Play;
    }

    private void SubmitBoard()
    {
        CaseView c = CurrentCase(); RunState r = GetRun(c.id);
        if (selectedBoard < 0 || selectedBoard >= c.board.Count) { feedback = Tx("chooseRelation", "Choose a relationship before validating."); feedbackGood = false; return; }
        OptionView opt = c.board[selectedBoard];
        if (opt.correct)
        {
            if (!r.board) { r.board = true; r.method++; Save(); }
            feedback = opt.feedback + Tx("boardValidated", " The analysis board is validated."); feedbackGood = true; screen = ScreenState.Verdict;
            selectedVerdict = -1;
        }
        else { feedback = opt.feedback + Tx("tryAgainBoard", " Re-read the clues and try another relationship."); feedbackGood = false; }
    }

    private void DrawVerdict()
    {
        CaseView c = CurrentCase();
        GUILayout.Label(Tx("closingReport", "Closing report"), accentStyle);
        GUILayout.Label(c.verdictQ, titleStyle);
        GUILayout.Label(Tx("verdictPrompt", "Submit a conclusion based on the four clues and the validated relationship."), bodyStyle);
        for (int i = 0; i < c.verdict.Count; i++)
        {
            bool selected = selectedVerdict == i;
            if (GUILayout.Toggle(selected, c.verdict[i].text, "toggle", GUILayout.MinHeight(60))) selectedVerdict = i;
        }
        if (!string.IsNullOrEmpty(feedback)) DrawFeedback(feedback, feedbackGood);
        if (GUILayout.Button(Tx("submitReport", "Submit report"), buttonStyle, GUILayout.Height(48))) SubmitVerdict();
        if (GUILayout.Button(Tx("reviewBoard", "Review the board"), buttonStyle)) { screen = ScreenState.Board; feedback = ""; }
    }

    private void SubmitVerdict()
    {
        CaseView c = CurrentCase();
        if (selectedVerdict < 0 || selectedVerdict >= c.verdict.Count) { feedback = Tx("chooseVerdict", "Select a conclusion before submitting the report."); feedbackGood = false; return; }
        OptionView opt = c.verdict[selectedVerdict];
        if (opt.correct)
        {
            RunState r = GetRun(c.id); r.solved = true; r.grade = r.method >= 5 ? "A" : (r.method >= 3 ? "B" : "C");
            if (!solved.Contains(c.id)) solved.Add(c.id);
            Save(); feedback = ""; screen = ScreenState.Ending;
        }
        else { feedback = opt.feedback + Tx("draftVerdict", " The report remains a draft. Review the clues and try again."); feedbackGood = false; }
    }

    private void DrawEnding()
    {
        CaseView c = CurrentCase(); RunState r = GetRun(c.id);
        GUILayout.Label(Tx("researchCompleted", "INVESTIGATION COMPLETE"), accentStyle);
        GUILayout.Label(c.ending, titleStyle);
        GUILayout.Label(c.debrief, bodyStyle);
        GUILayout.BeginHorizontal(cardStyle);
        GUILayout.Label(Tx("method", "Method") + "\n" + r.method + " / 5", subtitleStyle);
        GUILayout.FlexibleSpace(); GUILayout.Label(Tx("grade", "Grade") + "\n" + r.grade, subtitleStyle);
        GUILayout.EndHorizontal();
        int idx = IndexOfCase(c.id);
        if (GUILayout.Button(idx >= cases.Count - 1 ? Tx("nextCampaign", "Back to campaign") : Tx("nextCase", "Next case file"), buttonStyle, GUILayout.Height(48)))
        {
            if (idx >= cases.Count - 1) screen = ScreenState.Cases;
            else { currentCaseId = cases[idx + 1].id; screen = ScreenState.Intro; Save(); }
        }
        if (GUILayout.Button(Tx("viewCampaign", "View campaign"), buttonStyle)) screen = ScreenState.Cases;
    }

    private void DrawArchive()
    {
        GUILayout.Label(Tx("myFile", "My archive"), accentStyle);
        GUILayout.Label(Tx("yourProgress", "Your progress"), titleStyle);
        GUILayout.Label(Tx("closedTotal", "{n} / 4 closed").Replace("{n}", solved.Count.ToString()), subtitleStyle);
        if (solved.Count == 0) GUILayout.Label(Tx("emptyArchive", "You have not closed any case files yet."), bodyStyle);
        foreach (string id in solved)
        {
            CaseView c = FindCase(id); RunState r = GetRun(id);
            if (c == null) continue;
            GUILayout.BeginVertical(cardStyle);
            GUILayout.Label(c.title, subtitleStyle); GUILayout.Label(c.debrief, bodyStyle);
            GUILayout.Label(Tx("methodIndexScore", "Method score: {n}/5").Replace("{n}", r.method.ToString()) + " · " + Tx("grade", "Grade") + " " + r.grade, smallStyle);
            GUILayout.EndVertical();
        }
        if (GUILayout.Button(Tx("resetGame", "Reset entire game"), buttonStyle))
        {
            confirmReset = true; screen = ScreenState.Home; scroll = Vector2.zero;
        }
        if (GUILayout.Button(Tx("creditsSources", "Credits and sources"), buttonStyle)) screen = ScreenState.Credits;
        if (GUILayout.Button(Tx("back", "Back"), buttonStyle)) screen = ScreenState.Home;
    }

    private void DrawCredits()
    {
        GUILayout.Label(Tx("creditsSources", "Credits and sources"), accentStyle);
        GUILayout.Label(Tx("editorialNote", "Editorial note"), titleStyle);
        foreach (CaseView c in cases)
        {
            GUILayout.BeginVertical(cardStyle);
            GUILayout.Label(c.num + " · " + c.title, subtitleStyle);
            foreach (string[] source in c.sources)
            {
                if (GUILayout.Button(source[0], buttonStyle, GUILayout.MinHeight(34))) Application.OpenURL(source[1]);
            }
            GUILayout.EndVertical();
        }
        GUILayout.Label(Tx("languageNote", "The complete story is available in eight languages."), bodyStyle);
        GUILayout.Label(Tx("independentNote", "This is an independent fictional adaptation."), bodyStyle);
        if (GUILayout.Button(Tx("back", "Back"), buttonStyle)) screen = ScreenState.Home;
    }

    private void DrawFeedback(string text, bool good)
    {
        GUIStyle style = new GUIStyle(cardStyle); style.normal.textColor = good ? new Color(0.55f, 0.9f, 0.72f) : new Color(1f, 0.63f, 0.5f);
        GUILayout.Label(text, style);
    }

    private void StatPill(string text) { GUILayout.Label("  " + text + "  ", smallStyle, GUILayout.Height(26)); }
    private void ContinueGame()
    {
        if (string.IsNullOrEmpty(currentCaseId) || FindCase(currentCaseId) == null)
        {
            currentCaseId = cases.Count > 0 ? cases[0].id : "c1";
        }
        int idx = IndexOfCase(currentCaseId);
        if (!IsUnlocked(idx)) currentCaseId = cases[0].id;
        screen = GetRun(currentCaseId).solved ? ScreenState.Ending : ScreenState.Intro;
    }
    private void RequestNewGame()
    {
        bool hasProgress = solved.Count > 0;
        foreach (var pair in runs) if (pair.Value.found.Count > 0) hasProgress = true;
        if (hasProgress) { confirmReset = true; return; }
        ResetAllGame();
    }

    private void ResetAllGame()
    {
        confirmReset = false; solved.Clear(); runs.Clear(); foreach (CaseView c in cases) runs[c.id] = new RunState();
        currentCaseId = "c1"; Save(); screen = ScreenState.Intro;
    }
    private bool IsUnlocked(int index) { return index <= 0 || (index > 0 && solved.Contains(cases[index - 1].id)); }
    private CaseView CurrentCase() { return FindCase(currentCaseId) ?? (cases.Count > 0 ? cases[0] : null); }
    private CaseView FindCase(string id) { return cases.Find(x => x.id == id); }
    private int IndexOfCase(string id) { return cases.FindIndex(x => x.id == id); }
    private RunState GetRun(string id) { if (!runs.ContainsKey(id)) runs[id] = new RunState(); return runs[id]; }

    private string Tx(string key, string fallback)
    {
        object value = Get(currentUi, key);
        if (value != null && !string.IsNullOrEmpty(Convert.ToString(value))) return Convert.ToString(value);
        object es = Get(AsDict(Get(ui, "es")), key);
        return es != null ? Convert.ToString(es) : fallback;
    }

    private void EnsureStyles()
    {
        if (stylesReady) return;
        // Unity Web cannot query fonts installed on the player's operating system.
        // Both CJK font assets are embedded in Resources; choose one per locale.
        runtimeFont = ResolveLocaleFont();
#if !UNITY_WEBGL || UNITY_EDITOR
        if (runtimeFont == null)
        {
            try
            {
                runtimeFont = Font.CreateDynamicFontFromOSFont(new string[] { "Arial", "Noto Sans", "Liberation Sans" }, 18);
            }
            catch { }
        }
#endif
        titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 34, fontStyle = FontStyle.Bold, wordWrap = true, richText = true, normal = { textColor = new Color(0.88f, 0.96f, 0.95f) } };
        subtitleStyle = new GUIStyle(GUI.skin.label) { fontSize = 21, fontStyle = FontStyle.Bold, wordWrap = true, normal = { textColor = new Color(0.74f, 0.91f, 0.9f) } };
        bodyStyle = new GUIStyle(GUI.skin.label) { fontSize = 17, wordWrap = true, richText = true, padding = new RectOffset(5, 5, 7, 7), normal = { textColor = new Color(0.83f, 0.88f, 0.89f) } };
        smallStyle = new GUIStyle(GUI.skin.label) { fontSize = 13, wordWrap = true, normal = { textColor = new Color(0.55f, 0.69f, 0.72f) } };
        headerStyle = new GUIStyle(GUI.skin.label) { fontSize = 25, fontStyle = FontStyle.Bold, normal = { textColor = new Color(0.46f, 0.86f, 0.82f) } };
        accentStyle = new GUIStyle(GUI.skin.label) { fontSize = 14, fontStyle = FontStyle.Bold, wordWrap = true, normal = { textColor = new Color(0.94f, 0.66f, 0.36f) } };
        overlayTexture = MakeTexture(1, 1, new Color(0.006f, 0.018f, 0.026f, 0.36f));
        cardStyle = new GUIStyle(GUI.skin.box) { padding = new RectOffset(15, 15, 12, 12), margin = new RectOffset(0, 0, 5, 7), normal = { background = MakeTexture(2, 2, new Color(0.035f, 0.075f, 0.095f, 0.94f)) } };
        buttonStyle = new GUIStyle(GUI.skin.button) { fontSize = 16, fontStyle = FontStyle.Bold, wordWrap = true, padding = new RectOffset(12, 12, 10, 10), margin = new RectOffset(0, 0, 5, 5), normal = { textColor = new Color(0.88f, 0.95f, 0.93f), background = MakeTexture(2, 2, new Color(0.08f, 0.22f, 0.25f, 0.98f)) }, hover = { background = MakeTexture(2, 2, new Color(0.13f, 0.34f, 0.36f, 1f)) } };
        if (runtimeFont != null) ApplyLocaleFont();
        stylesReady = true;
    }

    private Font ResolveLocaleFont()
    {
        if (language == "zh-CN")
            return Resources.Load<Font>("Fonts/NotoSansCJKsc-Regular");
        return Resources.Load<Font>("Fonts/NotoSansCJKjp-Regular");
    }

    private void ApplyLocaleFont()
    {
        Font selected = ResolveLocaleFont();
        if (selected == null) return;
        runtimeFont = selected;
        titleStyle.font = subtitleStyle.font = bodyStyle.font = smallStyle.font = headerStyle.font = accentStyle.font = cardStyle.font = buttonStyle.font = selected;
    }

    private Texture2D MakeTexture(int w, int h, Color color)
    {
        var texture = new Texture2D(w, h); texture.hideFlags = HideFlags.HideAndDontSave;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) texture.SetPixel(x, y, color);
        texture.Apply(); return texture;
    }

    private static object Get(Dictionary<string, object> d, string key) { object v; return d != null && d.TryGetValue(key, out v) ? v : null; }
    private static Dictionary<string, object> AsDict(object value) { return value as Dictionary<string, object> ?? new Dictionary<string, object>(); }
    private static List<object> AsList(object value) { return value as List<object> ?? new List<object>(); }
    private static string Str(Dictionary<string, object> d, string key) { object v = Get(d, key); return v == null ? "" : Convert.ToString(v); }
    private static bool Bool(Dictionary<string, object> d, string key) { object v = Get(d, key); return v != null && Convert.ToBoolean(v); }
    private static string AtString(List<object> arr, int index, string fallback) { return index >= 0 && index < arr.Count && arr[index] != null ? Convert.ToString(arr[index]) : fallback; }
}
