#!/usr/bin/env python3
"""Download and validate the two official Noto CJK fonts required by RIO54.

The font binaries are fetched from the upstream Google Fonts/Noto CJK release at
build time. They are deliberately not redistributed inside the RIO54 source ZIP.
"""
from __future__ import annotations

import argparse
import io
import os
from pathlib import Path
import re
import sys
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FONT_DIR = ROOT / "Assets" / "Resources" / "Fonts"
MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
MAX_FONT_BYTES = 45 * 1024 * 1024
USER_AGENT = "RIO54-Unity-WebGL-Font-Setup/1.3"

FONTS = (
    {
        "name": "Noto Sans CJK JP",
        "file": "NotoSansCJKjp-Regular.otf",
        "url": "https://github.com/googlefonts/noto-cjk/releases/download/Sans2.004/06_NotoSansCJKjp.zip",
        "license": "LICENSE_NotoSansCJKjp.txt",
    },
    {
        "name": "Noto Sans CJK SC",
        "file": "NotoSansCJKsc-Regular.otf",
        "url": "https://github.com/googlefonts/noto-cjk/releases/download/Sans2.004/08_NotoSansCJKsc.zip",
        "license": "LICENSE_NotoSansCJKsc.txt",
    },
)


def valid_opentype(path: Path) -> bool:
    try:
        with path.open("rb") as stream:
            signature = stream.read(4)
        return signature in (b"OTTO", b"\x00\x01\x00\x00", b"true") and path.stat().st_size > 1024 * 1024
    except OSError:
        return False


def download(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=90) as response:
        content_length = response.headers.get("Content-Length")
        if content_length and int(content_length) > MAX_ARCHIVE_BYTES:
            raise RuntimeError(f"El paquete remoto supera el límite permitido: {content_length} bytes")
        chunks: list[bytes] = []
        total = 0
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_ARCHIVE_BYTES:
                raise RuntimeError("El paquete remoto supera el límite de descarga de 100 MiB")
            chunks.append(chunk)
    return b"".join(chunks)


def find_license(archive: zipfile.ZipFile) -> tuple[str, bytes] | None:
    candidates = []
    for info in archive.infolist():
        if info.is_dir() or info.file_size > 256 * 1024:
            continue
        base = Path(info.filename).name.lower()
        if base in {"license", "license.txt", "ofl.txt", "ofl"} or re.fullmatch(r"license[^/]*\.txt", base):
            candidates.append(info)
    if not candidates:
        return None
    # Prefer the upstream top-level license where available.
    candidates.sort(key=lambda item: (item.filename.count("/"), len(item.filename)))
    info = candidates[0]
    return info.filename, archive.read(info)


def install_one(spec: dict[str, str], force: bool) -> None:
    target = FONT_DIR / spec["file"]
    license_target = FONT_DIR / spec["license"]
    if not force and valid_opentype(target) and license_target.is_file():
        print(f"OK · {spec['name']} ya está instalada")
        return

    print(f"Descargando {spec['name']} desde el release oficial…")
    payload = download(spec["url"])
    try:
        archive = zipfile.ZipFile(io.BytesIO(payload))
    except zipfile.BadZipFile as exc:
        raise RuntimeError(f"El paquete de {spec['name']} no es un ZIP válido") from exc

    target_info = next((item for item in archive.infolist()
                        if not item.is_dir() and Path(item.filename).name == spec["file"]), None)
    if target_info is None:
        # Report archive contents as actionable information instead of guessing a font.
        candidates = [item.filename for item in archive.infolist() if item.filename.lower().endswith(".otf")]
        raise RuntimeError(f"No se encontró {spec['file']} en el ZIP. OTF disponibles: {candidates[:12]}")
    if target_info.file_size > MAX_FONT_BYTES:
        raise RuntimeError(f"La fuente {spec['file']} supera el límite de tamaño")
    font_bytes = archive.read(target_info)
    if len(font_bytes) < 4 or font_bytes[:4] not in (b"OTTO", b"\x00\x01\x00\x00", b"true"):
        raise RuntimeError(f"La fuente {spec['file']} no tiene una firma OpenType/TrueType válida")

    license_data = find_license(archive)
    if license_data is None:
        raise RuntimeError(f"El ZIP oficial no contiene un archivo LICENSE reconocible para {spec['name']}; se detiene para no omitir avisos legales")

    FONT_DIR.mkdir(parents=True, exist_ok=True)
    # Atomic writes prevent partially downloaded resources from looking installed.
    for path, data in ((target, font_bytes), (license_target, license_data[1])):
        fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=FONT_DIR)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
    if not valid_opentype(target):
        raise RuntimeError(f"La fuente instalada no pasó la verificación: {target}")
    try:
        target_label = target.relative_to(ROOT)
        license_label = license_target.relative_to(ROOT)
    except ValueError:
        target_label = target
        license_label = license_target
    print(f"INSTALADA · {target_label}")
    print(f"LICENCIA · {license_label} (origen: {license_data[0]})")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="solo comprobar archivos; no descarga nada")
    parser.add_argument("--force", action="store_true", help="volver a descargar aunque ya existan")
    args = parser.parse_args()

    if args.check:
        missing = []
        for spec in FONTS:
            path = FONT_DIR / spec["file"]
            license_path = FONT_DIR / spec["license"]
            if not valid_opentype(path):
                missing.append(spec["file"])
            if not license_path.is_file():
                missing.append(spec["license"])
        if missing:
            print("FALTAN RECURSOS: " + ", ".join(missing))
            return 1
        print("FUENTES CJK OK · Noto Sans CJK JP y SC, con sus licencias")
        return 0

    try:
        for spec in FONTS:
            install_one(spec, args.force)
    except Exception as exc:
        print(f"ERROR AL PREPARAR FUENTES: {exc}", file=sys.stderr)
        print("Comprobá la conexión y que GitHub Releases esté accesible. También podés colocar manualmente los OTF y LICENSE indicados en README_ES.txt.", file=sys.stderr)
        return 2

    print("\nFuentes internacionales preparadas. Abrí Unity y ejecutá RIO54 > 2 - Configurar fuentes internacionales.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
