#!/usr/bin/env python3
"""Serve a compiled RIO54 Unity WebGL player locally for browser testing."""
from __future__ import annotations

import argparse
import mimetypes
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


def main() -> None:
    project = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", default=str(project / "Build" / "WebGL"), help="Carpeta del build WebGL")
    parser.add_argument("--host", default="127.0.0.1", help="Dirección de escucha (por defecto, solo local)")
    parser.add_argument("--port", type=int, default=8000, help="Puerto HTTP")
    args = parser.parse_args()
    root = Path(args.build).expanduser().resolve()
    if not (root / "index.html").is_file():
        parser.error(f"No encuentro index.html en {root}. Primero compilá el proyecto Unity WebGL.")

    mimetypes.add_type("application/wasm", ".wasm")
    mimetypes.add_type("application/javascript", ".js")
    handler = partial(SimpleHTTPRequestHandler, directory=str(root))
    server = ThreadingHTTPServer((args.host, args.port), handler)
    print(f"RIO54 WebGL local: http://{args.host}:{args.port}")
    print(f"Sirviendo: {root}")
    print("Presioná Ctrl+C para detener el servidor.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
