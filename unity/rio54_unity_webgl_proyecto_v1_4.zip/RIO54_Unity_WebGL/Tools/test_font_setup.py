#!/usr/bin/env python3
"""Offline unit tests for the Noto CJK font installer."""
import io
from pathlib import Path
import tempfile
import unittest
import zipfile
from unittest.mock import patch

import setup_cjk_fonts as setup


class FontInstallerTests(unittest.TestCase):
    def make_release_zip(self, filename: str) -> bytes:
        out = io.BytesIO()
        # A >1 MiB synthetic OpenType-like payload exercises signature and size checks.
        fake_font = b"OTTO" + (b"R" * (1024 * 1024 + 128))
        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(filename, fake_font)
            archive.writestr("LICENSE", "SIL OPEN FONT LICENSE Version 1.1\n")
        return out.getvalue()

    def test_install_extracts_otf_and_license(self):
        spec = {
            "name": "Test Noto CJK",
            "file": "NotoSansCJKtest-Regular.otf",
            "url": "https://example.invalid/test.zip",
            "license": "LICENSE_NotoSansCJKtest.txt",
        }
        payload = self.make_release_zip(spec["file"])
        with tempfile.TemporaryDirectory() as tmp:
            font_dir = Path(tmp)
            with patch.object(setup, "FONT_DIR", font_dir), patch.object(setup, "download", return_value=payload):
                setup.install_one(spec, force=True)
            self.assertTrue(setup.valid_opentype(font_dir / spec["file"]))
            self.assertIn("SIL OPEN FONT LICENSE", (font_dir / spec["license"]).read_text())

    def test_installer_refuses_archive_without_license(self):
        spec = {
            "name": "Test Noto CJK",
            "file": "NotoSansCJKtest-Regular.otf",
            "url": "https://example.invalid/test.zip",
            "license": "LICENSE_NotoSansCJKtest.txt",
        }
        out = io.BytesIO()
        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(spec["file"], b"OTTO" + b"R" * (1024 * 1024 + 128))
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(setup, "FONT_DIR", Path(tmp)), patch.object(setup, "download", return_value=out.getvalue()):
                with self.assertRaisesRegex(RuntimeError, "no contiene un archivo LICENSE"):
                    setup.install_one(spec, force=True)

    def test_existing_font_and_license_skip_download(self):
        spec = {
            "name": "Test Noto CJK",
            "file": "NotoSansCJKtest-Regular.otf",
            "url": "https://example.invalid/test.zip",
            "license": "LICENSE_NotoSansCJKtest.txt",
        }
        with tempfile.TemporaryDirectory() as tmp:
            font_dir = Path(tmp)
            (font_dir / spec["file"]).write_bytes(b"OTTO" + b"R" * (1024 * 1024 + 128))
            (font_dir / spec["license"]).write_text("License")
            with patch.object(setup, "FONT_DIR", font_dir), patch.object(setup, "download", side_effect=AssertionError("must not download")):
                setup.install_one(spec, force=False)


if __name__ == "__main__":
    unittest.main(verbosity=2)
