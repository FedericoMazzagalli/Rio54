#!/usr/bin/env python3
"""Offline tests for the compiled Unity WebGL output validator."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

PROJECT = Path(__file__).resolve().parents[1]
VALIDATOR = PROJECT / "Tools" / "validate_webgl_output.py"


class WebGLOutputValidatorTests(unittest.TestCase):
    def make_build(self, root: Path, compressed: bool = True, notices: bool = True) -> None:
        (root / "Build").mkdir(parents=True)
        (root / "index.html").write_text("<html>RIO54</html>")
        (root / "Build" / "RIO54.loader.js").write_text("loader")
        (root / "Build" / "RIO54.framework.js").write_text("framework")
        (root / "Build" / "RIO54.data.br").write_bytes(b"data")
        wasm_name = "RIO54.wasm.br" if compressed else "RIO54.wasm"
        wasm = b"brotli-placeholder" if compressed else b"\x00asm" + b"payload"
        (root / "Build" / wasm_name).write_bytes(wasm)
        if notices:
            notice_dir = root / "ThirdPartyNotices" / "NotoCJK"
            notice_dir.mkdir(parents=True)
            (notice_dir / "LICENSE_NotoSansCJKjp.txt").write_text("JP license")
            (notice_dir / "LICENSE_NotoSansCJKsc.txt").write_text("SC license")

    def run_validator(self, root: Path) -> subprocess.CompletedProcess[str]:
        return subprocess.run([sys.executable, str(VALIDATOR), "--path", str(root)],
                              capture_output=True, text=True, check=False)

    def test_accepts_compressed_unity_wasm_and_notices(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.make_build(root, compressed=True, notices=True)
            result = self.run_validator(root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_accepts_plain_wasm_only_with_magic_header(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.make_build(root, compressed=False, notices=True)
            result = self.run_validator(root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_rejects_missing_font_license_notices(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.make_build(root, compressed=True, notices=False)
            result = self.run_validator(root)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("Noto CJK JP and SC license notices", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
