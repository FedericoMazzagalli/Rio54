#!/usr/bin/env python3
"""Run all pre-build checks that do not require the Unity Editor."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
checks = [
    [sys.executable, str(root / "Tools" / "validate_rio54_data.py")],
    [sys.executable, str(root / "Tools" / "test_font_setup.py")],
    [sys.executable, str(root / "Tools" / "test_webgl_validator.py")],
]
for command in checks:
    result = subprocess.run(command, cwd=root)
    if result.returncode:
        sys.exit(result.returncode)

required = [
    root / "Assets/Scripts/RIO54Game.cs",
    root / "Assets/Scripts/RIO54World.cs",
    root / "Assets/Scripts/SimpleJson.cs",
    root / "Assets/Editor/RIO54BuildTools.cs",
    root / "Assets/WebGLTemplates/RIO54/index.html",
    root / "Assets/Resources/Fonts/README.txt",
    root / "Tools/setup_cjk_fonts.py",
    root / "Tools/test_font_setup.py",
    root / "Tools/test_webgl_validator.py",
    root / ".github/workflows/rio54-webgl.yml",
    root / "Packages/manifest.json",
    root / "ProjectSettings/ProjectVersion.txt",
]
missing = [str(p.relative_to(root)) for p in required if not p.is_file()]
if missing:
    print("ERROR: faltan archivos del proyecto:")
    print("\n".join(" - " + item for item in missing))
    sys.exit(1)

cs = (root / "Assets/Scripts/RIO54Game.cs").read_text(encoding="utf-8")
assert 'Resources.Load<Font>("Fonts/NotoSansCJKjp-Regular")' in cs, "Game font must load the bundled resource font"
editor = (root / "Assets/Editor/RIO54BuildTools.cs").read_text(encoding="utf-8")
for marker in ("BatchBuildWebGL", "GameCIBuildWebGL", "ConfigureInternationalFonts", "ConfigureFontAssets();", 'PROJECT:RIO54', "ValidateBuildOutputAt", "CopyThirdPartyNotices", "ThirdPartyNotices", "decompressionFallback", "dataCaching", "FontTextureCase.Dynamic", "includeFontData"):
    assert marker in editor, f"Missing build feature: {marker}"
for marker in ("ResolveLocaleFont", "ApplyLocaleFont", 'language == "zh-CN"'):
    assert marker in cs, f"Missing locale font selection feature: {marker}"
world = (root / "Assets/Scripts/RIO54World.cs").read_text(encoding="utf-8")
assert "CreateStarfield" in world and "UploadMeshData(true)" in world, "Optimized starfield mesh is missing"
workflow = (root / ".github/workflows/rio54-webgl.yml").read_text(encoding="utf-8")
for marker in ("game-ci/unity-builder@v4", "RIO54BuildTools.GameCIBuildWebGL", "UNITY_LICENSE", "upload-artifact@v4", "Tools/setup_cjk_fonts.py", "ThirdPartyNotices/NotoCJK"):
    assert marker in workflow, f"Missing CI workflow feature: {marker}"
html = (root / "Assets/WebGLTemplates/RIO54/index.html").read_text(encoding="utf-8")
for marker in ("{{{ LOADER_FILENAME }}}", "{{{ DATA_FILENAME }}}", "{{{ FRAMEWORK_FILENAME }}}", "{{{ CODE_FILENAME }}}", "createUnityInstance"):
    assert marker in html, f"Missing Unity template token: {marker}"
print("PROJECT STRUCTURE OK")
print("Unity Web template, local/CI build entrypoints, locale-specific CJK font setup and output checks are present.")
print("GitHub Actions downloads official Noto CJK fonts, preserves their licenses and configures the font importers before WebGL build.")
print("Unity Editor/Web Build Support and a Unity license secret for CI are still required to produce a distributable player.")
