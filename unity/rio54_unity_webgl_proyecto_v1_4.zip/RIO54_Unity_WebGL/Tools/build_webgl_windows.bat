@echo off
setlocal
set PROJECT_DIR=%~dp0..
for %%I in ("%PROJECT_DIR%") do set PROJECT_DIR=%%~fI
if "%UNITY_EDITOR%"=="" set UNITY_EDITOR=C:\Program Files\Unity\Hub\Editor\6000.3.0f1\Editor\Unity.exe
if not exist "%UNITY_EDITOR%" (
  echo No encuentro Unity Editor. Defini UNITY_EDITOR con la ruta a Unity 6.3 LTS.
  echo Debe estar instalado el modulo Web Build Support.
  exit /b 2
)
if not exist "%PROJECT_DIR%\Logs" mkdir "%PROJECT_DIR%\Logs"
py -3 "%PROJECT_DIR%\Tools\setup_cjk_fonts.py"
if errorlevel 1 exit /b 2
"%UNITY_EDITOR%" -batchmode -quit -nographics -projectPath "%PROJECT_DIR%" -buildTarget webgl -executeMethod RIO54BuildTools.BatchBuildWebGL -logFile "%PROJECT_DIR%\Logs\webgl-build.log"
if errorlevel 1 (
  echo Error de compilacion. Revisar %PROJECT_DIR%\Logs\webgl-build.log
  exit /b 1
)
py -3 "%PROJECT_DIR%\Tools\validate_webgl_output.py"
if errorlevel 1 exit /b 1
echo Build WebGL listo en %PROJECT_DIR%\Build\WebGL
endlocal
