#!/usr/bin/env python3
"""Structural and localization validation for the RIO54 Unity project."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "Assets" / "Resources" / "RIO54Data.json"
data = json.loads(path.read_text(encoding="utf-8"))
expected = ["es", "en", "pt-BR", "fr", "de", "it", "ja", "zh-CN"]
assert data["languages"] == expected, "Language list/order mismatch"
assert len(data["cases"]) == 4, "Campaign must contain four cases"
assert set(data["ui"]) == set(expected), "UI locale mismatch"
assert set(data["narrative"]) == set(expected[1:]), "Narrative locale mismatch"

base_ui_keys = set(data["ui"]["es"])
for lang in expected:
    actual = set(data["ui"][lang])
    assert actual == base_ui_keys, f"{lang}: UI key set mismatch; missing={base_ui_keys-actual}; extra={actual-base_ui_keys}"
    for key, value in data["ui"][lang].items():
        assert isinstance(value, str) and value.strip(), f"{lang}.{key}: empty or non-string UI text"

seen_ids = set()
source_count = 0
for case in data["cases"]:
    cid = case["id"]
    assert cid not in seen_ids, f"Duplicate case id: {cid}"
    seen_ids.add(cid)
    assert len(case["clues"]) == 4, (cid, "clues")
    assert len(case["board"]) == 3, (cid, "board")
    assert len(case["verdict"]) == 3, (cid, "verdict")
    assert sum(1 for x in case["board"] if x.get("correct")) == 1, (cid, "board must have one correct option")
    assert sum(1 for x in case["verdict"] if x.get("correct")) == 1, (cid, "verdict must have one correct option")
    for source in case.get("sources", []):
        assert len(source) >= 2 and source[0].strip(), (cid, "source title")
        assert source[1].startswith("https://"), (cid, "source URL must be HTTPS")
        source_count += 1

for lang in expected[1:]:
    for case in data["cases"]:
        cid = case["id"]
        pack = data["narrative"][lang][cid]
        assert len(pack["top"]) == 11, (lang, cid, "top fields")
        assert all(isinstance(x, str) and x.strip() for x in pack["top"]), (lang, cid, "empty top translation")
        assert len(pack["clues"]) == 4, (lang, cid, "clues")
        assert all(len(clue) == 9 for clue in pack["clues"]), (lang, cid, "clue fields")
        assert all(isinstance(x, str) and x.strip() for clue in pack["clues"] for x in clue), (lang, cid, "empty clue translation")
        assert len(pack["board"]) == 3 and all(len(option) == 2 for option in pack["board"]), (lang, cid, "board options")
        assert len(pack["verdict"]) == 3 and all(len(option) == 2 for option in pack["verdict"]), (lang, cid, "verdict options")
        assert all(isinstance(option[0], str) and option[0].strip() for group in (pack["board"], pack["verdict"]) for option in group), (lang, cid, "empty option label")
        assert all(isinstance(option[1], str) for group in (pack["board"], pack["verdict"]) for option in group), (lang, cid, "option feedback must be a string")

print("RIO54 DATA OK")
print(f"Cases: {len(data['cases'])} · Clues: {sum(len(c['clues']) for c in data['cases'])} · Sources: {source_count}")
print(f"Locales: {len(expected)} UI packs · {len(expected)-1} translated narrative packs")
print("Per translated case: 11 story fields + 36 clue fields + board/verdict questions and options")
print(f"JSON size: {path.stat().st_size:,} bytes")
