#!/usr/bin/env python3
"""Validate the expected files in a Unity WebGL player output."""
from pathlib import Path
import argparse
import sys

project = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--path", default=str(project / "Build" / "WebGL"), help="Carpeta de salida WebGL")
args = parser.parse_args()
out = Path(args.path).expanduser().resolve()
if not out.is_dir():
    print(f"ERROR: no existe la carpeta {out}")
    sys.exit(1)
files = [p for p in out.rglob("*") if p.is_file()]

def match_any(token: str) -> list[Path]:
    return [p for p in files if token in p.name]

index = out / "index.html"
wasm = match_any(".wasm")
loader = match_any(".loader.js")
framework = match_any(".framework.js")
data = [p for p in files if ".data" in p.name]
notices = out / "ThirdPartyNotices" / "NotoCJK"
licenses = [notices / "LICENSE_NotoSansCJKjp.txt", notices / "LICENSE_NotoSansCJKsc.txt"]
def wasm_file_is_valid(path: Path) -> bool:
    # Unity may emit plain .wasm or a compressed .wasm.br/.wasm.gz artifact.
    try:
        if path.name.endswith(".wasm"):
            with path.open("rb") as stream:
                return stream.read(4) == b"\x00asm"
        return path.stat().st_size > 0 and (path.name.endswith(".wasm.br") or path.name.endswith(".wasm.gz"))
    except OSError:
        return False

wasm_header_ok = bool(wasm) and any(wasm_file_is_valid(item) for item in wasm)
missing = []
for label, ok in (("index.html", index.is_file() and index.stat().st_size > 0),
                  ("WebAssembly player (.wasm or compressed .wasm.br/.wasm.gz)", wasm_header_ok),
                  ("loader JavaScript", bool(loader) and loader[0].stat().st_size > 0),
                  ("framework JavaScript", bool(framework) and framework[0].stat().st_size > 0),
                  ("data file", bool(data) and data[0].stat().st_size > 0),
                  ("Noto CJK JP and SC license notices", all(p.is_file() and p.stat().st_size > 0 for p in licenses))):
    if not ok:
        missing.append(label)
if missing:
    print("ERROR: faltan artefactos: " + ", ".join(missing))
    sys.exit(1)
size = sum(p.stat().st_size for p in files)
print("RIO54 WEBGL OUTPUT OK")
print(f"Files: {len(files)}")
print(f"Total: {size / (1024 * 1024):.2f} MiB")
print(f"Index: {index}")
print(f"WASM: {wasm[0].name} · present")
print("Third-party notices: Noto CJK JP / SC present")
