#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
UNITY_EDITOR="${UNITY_EDITOR:-}"
if [[ -z "$UNITY_EDITOR" ]]; then
  CANDIDATES=(
    "$HOME/Unity/Hub/Editor/6000.3.0f1/Editor/Unity"
    "/opt/unity/Editor/Unity"
    "/opt/Unity/Editor/Unity"
  )
  for candidate in "${CANDIDATES[@]}"; do
    if [[ -x "$candidate" ]]; then UNITY_EDITOR="$candidate"; break; fi
  done
fi
if [[ -z "$UNITY_EDITOR" || ! -x "$UNITY_EDITOR" ]]; then
  echo "No encuentro Unity Editor. Configurá UNITY_EDITOR con la ruta al ejecutable de Unity 6.3 LTS."
  echo "El Editor debe tener instalado el módulo Web Build Support."
  exit 2
fi
mkdir -p "$PROJECT_DIR/Logs" "$PROJECT_DIR/Build"
LOG="$PROJECT_DIR/Logs/webgl-build.log"
# Download the exact upstream Noto CJK assets if they are not already installed.
python3 "$PROJECT_DIR/Tools/setup_cjk_fonts.py"
echo "RIO54 WebGL build · Unity: $UNITY_EDITOR"
echo "Project: $PROJECT_DIR"
set +e
"$UNITY_EDITOR" -batchmode -quit -nographics \
  -projectPath "$PROJECT_DIR" \
  -buildTarget webgl \
  -executeMethod RIO54BuildTools.BatchBuildWebGL \
  -logFile "$LOG"
UNITY_STATUS=$?
set -e
if [[ $UNITY_STATUS -ne 0 ]]; then
  echo "Unity build failed (exit $UNITY_STATUS). Log: $LOG"
  tail -n 70 "$LOG" || true
  exit "$UNITY_STATUS"
fi
python3 "$PROJECT_DIR/Tools/validate_webgl_output.py"
echo "Build WebGL listo en: $PROJECT_DIR/Build/WebGL"
