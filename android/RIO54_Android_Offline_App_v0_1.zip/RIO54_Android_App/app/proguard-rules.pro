# RIO54 does not currently require custom ProGuard rules.
