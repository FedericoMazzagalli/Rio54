#!/usr/bin/env python3
"""Static checks for the HTML5 payload packaged into the offline Android shell."""
from pathlib import Path
import json
import re
import struct

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "app/src/main/assets/www"
REQUIRED = [
    "index.html", "narrative_translations.js", "webgl_renderer.js",
    "service-worker.js", "manifest.webmanifest", "icons/icon-192.png", "icons/icon-512.png",
]
for item in REQUIRED:
    if not (WEB / item).is_file():
        raise SystemExit(f"Android package is missing: {item}")
html = (WEB / "index.html").read_text(encoding="utf-8")
if "narrative_translations.js" not in html or "webgl_renderer.js" not in html:
    raise SystemExit("HTML script references are incomplete")
if "serviceWorker.register('./service-worker.js')" not in html:
    raise SystemExit("Offline service worker registration changed; review Android shell")
manifest = json.loads((WEB / "manifest.webmanifest").read_text(encoding="utf-8"))
for icon in manifest.get("icons", []):
    path = WEB / icon["src"]
    if not path.is_file():
        raise SystemExit(f"Manifest icon missing: {icon['src']}")
    data = path.read_bytes()[:24]
    if len(data) != 24 or data[:8] != b"\x89PNG\r\n\x1a\n":
        raise SystemExit(f"Invalid PNG icon: {icon['src']}")
    size = struct.unpack(">II", data[16:24])
    expected = tuple(map(int, icon["sizes"].split("x")))
    if size != expected:
        raise SystemExit(f"PNG size mismatch: {icon['src']} {size} != {expected}")
translations = (WEB / "narrative_translations.js").read_text(encoding="utf-8")
for locale in ("en", "pt-BR", "fr", "de", "it", "ja", "zh-CN"):
    locale_pattern = rf"(?m)^\s*(?:'{re.escape(locale)}'|{re.escape(locale)}):\s*\{{"
    if not re.search(locale_pattern, translations):
        raise SystemExit(f"Translated narrative pack not found: {locale}")
if "android.permission.INTERNET" in (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8"):
    raise SystemExit("Offline APK must not declare INTERNET permission")
print(f"RIO54 Android assets OK: {len(REQUIRED)} required files, 8 locales, local PWA cache payload.")
