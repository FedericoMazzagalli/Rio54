# RIO54 Android — aplicación instalable offline

Este módulo genera una APK Android de la edición HTML5/PWA 1.4.2. No es la compilación Unity WebGL ni una conversión a motor nativo: es un contenedor Android con WebView que incluye los recursos del juego dentro del propio APK.

## Qué incluye

- Campaña HTML5 con los cuatro expedientes, dieciséis pistas y ocho idiomas.
- Escena WebGL del encabezado, si la versión de Android System WebView del dispositivo admite WebGL.
- WebViewAssetLoader con origen HTTPS local `appassets.androidplatform.net` (no usa `file://`).
- JavaScript y DOM Storage para guardar la campaña.
- Service worker local preparado para interceptar sus peticiones a los recursos empaquetados y almacenar el shell offline.
- Sin permiso `INTERNET`: la campaña y los assets se entregan desde el APK; los enlaces a fuentes externas se abren en el navegador del sistema cuando hay conectividad.
- Pantalla adaptable, rotación y botones de navegación Android.

## Versiones de construcción

- Android Gradle Plugin: 9.4.1.
- Gradle: 9.6.0.
- JDK: 17.
- Compile SDK: 36.
- Target SDK: 36 (Android 16).
- Min SDK: 26 (Android 8.0).
- AndroidX WebKit: 1.18.0.

Google Play requiere que las nuevas aplicaciones y actualizaciones enviadas desde el 31 de agosto de 2026 apunten a Android 16/API 36 o superior. Ver [política oficial de target API](https://developer.android.com/google/play/requirements/target-sdk).

## Abrir en Android Studio

1. Descomprimí el paquete completo RIO54 y abrí la carpeta `android/RIO54_Android_App` en Android Studio.
2. Permití que Gradle sincronice el proyecto y descargue Android Gradle Plugin 9.4.1, Gradle 9.6.0 y AndroidX WebKit 1.18.0.
3. Instalá Android SDK Platform 36 y Build Tools 36.0.0 desde SDK Manager si no están instalados.
4. Elegí `app` como configuración y ejecutá en un dispositivo Android o emulador.

Para compilar desde una terminal con Gradle 9.6.0 instalado:

```bash
gradle :app:assembleDebug
```

La APK de depuración queda en:

`app/build/outputs/apk/debug/app-debug.apk`

## Compilación automática

El workflow `RIO54 Android APK` construye la APK de depuración al modificar este directorio y publica el artefacto `RIO54-Android-debug-APK` en GitHub Actions. La APK debug sirve para pruebas e instalación manual; antes de distribuirla en Google Play se deberá preparar una clave de firma privada, generar un AAB firmado y completar las declaraciones de privacidad, contenido y clasificación correspondientes.

## Pruebas físicas pendientes

- Instalar la APK debug en teléfono Android real.
- Abrir cada idioma, completar un expediente y cerrar/abrir la app para probar persistencia.
- Reiniciar en modo avión y comprobar el modo offline.
- Probar rotación, pantalla dividida, WebGL y memoria en equipos distintos.
- Comprobar que los enlaces de fuentes abren el navegador externo cuando hay Internet.

## Seguridad

- La APK no solicita permiso de Internet.
- No se expone `addJavascriptInterface`.
- Solo se admiten navegación interna en `appassets.androidplatform.net` y enlaces externos HTTP/HTTPS lanzados mediante una actividad del sistema.
- Acceso a archivos locales, contenido local y mezcla HTTP/HTTPS permanecen deshabilitados.
