RIO54 — ARCHIVO DE LO INEXPLICADO
Versión 1.3 · Multilingüe · Navegador HTML5 + escena WebGL

CÓMO JUGAR
1. Descomprimí el paquete ZIP.
2. Abrí index.html con Firefox, Chrome o Chromium actualizado.
3. No requiere instalación, cuenta ni conexión a Internet.
4. La escena animada de portada se renderiza con WebGL (GPU del navegador); si WebGL no está disponible, se activa automáticamente una ilustración CSS de respaldo.
5. Elegí un idioma en el selector superior y pulsá «Comenzar investigación».
6. Cada expediente se desbloquea al completar el anterior. Examiná cuatro indicios por capítulo, elegí cómo registrarlos, conectá la evidencia y presentá una conclusión.

IDIOMAS
Los cuatro expedientes completos están disponibles en ocho idiomas: español, inglés, portugués de Brasil, francés, alemán, italiano, japonés y chino simplificado. Se traducen descripciones, pistas, categorías, preguntas, opciones de registro, devoluciones, hipótesis, conclusiones y finales. Los títulos originales de las publicaciones citadas se conservan en español para que las fuentes puedan localizarse y verificarse.

GUARDADO
El progreso se guarda automáticamente en el almacenamiento local del navegador. El guardado queda asociado al navegador y dispositivo donde jugás; no se sincroniza en la nube.

CONTENIDO
- Cuatro expedientes narrativos basados en publicaciones de RIO54.
- 16 indicios examinables con decisiones de análisis y retroalimentación.
- Tablero de relaciones y evaluación de conclusiones por capítulo.
- Calificación de método (A, B o C), desbloqueo progresivo y archivo de progreso.
- Guardado automático local, opción de reinicio y navegación adaptable a escritorio y móvil.
- Ocho idiomas completos, con selección persistente independiente del progreso.
- Fuentes originales vinculadas desde el apartado «Fuentes, créditos y notas».
- Diseño CSS/vectorial propio y escena WebGL 1 procedural, sin dependencias ni recursos externos.
- Arquitectura híbrida: WebGL renderiza la escena visual; la interfaz accesible, los diálogos y la lógica narrativa se mantienen en HTML/CSS/JavaScript.
- Compatible con juego offline.

EXPEDIENTES
001 · La luz de septiembre: Buenos Aires, 17/09/1985. RIO54 recoge la identificación posterior como globo sonda francés.
002 · La comisión bajo la lupa: anuncios, formalización y primer informe de la CEFAE según la cronología y comentarios publicados en RIO54.
003 · La noche de Monte Grande: episodio trágico del 26/09/2011. Se distingue el relato de vecinos de las hipótesis; el juego no atribuye una causa no demostrada.
004 · Ecos desde el continente blanco: memoria documental del comunicado naval de 1965 y la comisión COPEFO, retomada por RIO54 en 2016.

NOTA EDITORIAL Y DERECHOS
Las publicaciones de RIO54 son el punto de partida de esta reconstrucción narrativa, no una verificación independiente de cada afirmación. El juego distingue entre lo que una publicación afirma, los testimonios que reproduce y las conclusiones posibles. Los personajes, diálogos y situaciones interactivas son ficticios. Esta es una adaptación independiente y no implica respaldo ni participación oficial de los autores del blog. Para explotar comercialmente el nombre/marca RIO54, logotipos, fotografías, textos originales o testimonios de terceros, deben tramitarse las autorizaciones correspondientes.

ARCHIVOS DEL PAQUETE
- index.html: aplicación y lógica del juego.
- webgl_renderer.js: renderizador WebGL 1 de la escena animada de portada, con respaldo CSS si el navegador no soporta WebGL.
- narrative_translations.js: traducciones narrativas completas de los cuatro expedientes a los siete idiomas adicionales.
- README.txt: estas instrucciones.
- IDIOMAS.txt: alcance de las traducciones.
- FUENTES_Y_CREDITOS.txt: referencias y alcance editorial.
- CHANGELOG.txt: historial de versiones.
- JUGAR_EN_LINUX.sh / JUGAR_EN_WINDOWS.bat: lanzadores.
- jugar.py: servidor local opcional para un guardado más fiable en navegadores con restricciones de archivos locales.

EJECUCIÓN RECOMENDADA
Abrí index.html directamente. Si el navegador restringe el guardado local, ejecutá jugar.py con Python 3. También podés usar JUGAR_EN_LINUX.sh o JUGAR_EN_WINDOWS.bat. El servidor local no se conecta a Internet.
