#!/usr/bin/env python3
"""Inicia RIO54 localmente sin conexión y abre el navegador predeterminado."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import webbrowser

BASE = Path(__file__).resolve().parent

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

handler = partial(QuietHandler, directory=str(BASE))
server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
host, port = server.server_address
url = f"http://{host}:{port}/index.html"
print("RIO54 — ARCHIVO DE LO INEXPLICADO")
print("El juego se está ejecutando localmente; no usa internet.")
print(f"Dirección: {url}")
print("Dejá esta ventana abierta mientras jugás. Para salir, presioná Ctrl+C.")
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\nCerrando RIO54...")
finally:
    server.server_close()
