@echo off
cd /d "%~dp0"
python jugar.py
if errorlevel 1 py jugar.py
pause
