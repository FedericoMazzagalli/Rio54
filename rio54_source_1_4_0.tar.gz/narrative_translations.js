/* RIO54 - traducciones narrativas completas. Los títulos originales de las fuentes se conservan para trazabilidad. */
window.RIO54_NARRATIVE = {
  en: {
    c1: {
      top: [
        "Historical reconstruction", "The September Light", "Buenos Aires and the surrounding metropolitan area · 17 September 1985",
        "An aerial object is seen by many people. Years later, the RIO54 archive records a specific explanation.",
        "This case begins with a widely observed event over Buenos Aires and its metropolitan area. Your task is to reconstruct what was published, which later explanation the archive records, and how far the available information allows you to go.",
        "Documentary starting point: a RIO54 post published on 27 December 2011 credits Carlos Demaría’s investigation with explaining the episode as a French-origin sounding balloon.",
        "The city remembers an unusual light. Newspaper clippings, dates, and a note revisiting the case lie in an archive folder. You will not find a magic photograph that explains everything: you must reconstruct the chain of information.",
        "Which relationship best describes the complete case file?", "Given the information gathered, what conclusion should be submitted?",
        "The case file finds a documented explanation in the source consulted.",
        "The RIO54 post attributes the identification of the object as a French sounding balloon to Carlos Demaría’s inquiries. This conclusion is limited to this episode and to what that post reports: it does not resolve other cases or invalidate other testimony."
      ],
      clues: [
        ["The date of the event", "TIMELINE", "A specific date reference.", "The RIO54 post places the event on 17 September 1985 and says the object was seen from the city of Buenos Aires and the surrounding metropolitan area.", "Post “Los blogs de Carlos Demaría”, RIO54, 27 Dec 2011.", "Record the date, area, and scope exactly as stated in the publication.", "Treating the number of observers as automatic proof of an extraordinary origin.", "Correct. You recorded the verifiable information in this source without claiming more than it says.", "A large number of observers makes the case worth examining, but does not by itself establish what the object was."],
        ["Accounts of the sighting", "REPORTED TESTIMONY", "What collective testimony can contribute.", "The publication mentions numerous witnesses. The archive does not reproduce each individual account here, nor does this post provide an interview database that would allow descriptions, viewing angles, or timings to be compared.", "The RIO54 post summarizes the case; it does not reproduce all original testimonies.", "Distinguish the general reference to witnesses from the full statements that are not included.", "Claiming that everyone saw exactly the same thing even though the text does not specify that.", "Good. You did not confuse the existence of accounts with access to each original statement.", "The archive does not allow us to claim that everyone described the same object in identical detail."],
        ["The later investigation", "DOCUMENTARY ATTRIBUTION", "The explanation recorded by RIO54.", "RIO54 recalls Carlos Demaría’s contribution to clarifying the case and states that, after the relevant inquiries, the object turned out to be a sounding balloon of French origin.", "Post “Los blogs de Carlos Demaría”, RIO54, 27 Dec 2011.", "Note that this is the explanation the publication attributes to Demaría’s inquiries.", "Attributing technical details to the post that do not appear in it.", "Exactly. You preserved the attribution to the source and avoided inventing details about the balloon.", "The text provides a general identification, but does not describe every technical detail of the investigation in that post."],
        ["The limits of the term UFO", "CRITERION", "Unidentified does not mean extraterrestrial.", "In an investigation, “unidentified flying object” describes a sighting whose identity is unknown at that time. It is not a classification of its origin, nor proof of non-human technology.", "Methodological criterion built into the game; not a literal quotation from the blog.", "Separate the initial description of the object from the later explanation recorded by the source.", "Treating the label UFO as a synonym for an extraterrestrial spacecraft.", "That is the central step in this case: a label expressing uncertainty is not a conclusion about origin.", "The acronym means that something was not identified at that time; it does not prove an extraterrestrial origin."]
      ],
      boardQ: "Which relationship best describes the complete case file?",
      board: [
        ["The initial accounts prompted an investigation; the later publication records an identification as a French sounding balloon.", "The summary respects the sequence of events and the source attribution."],
        ["The large number of witnesses proves that the object was an extraterrestrial spacecraft.", "The number of witnesses does not establish the nature of the object."],
        ["Because a later explanation existed, the original testimonies must have been fabricated.", "A later identification does not prove that the observers lied."]
      ],
      verdictQ: "Given the information gathered, what conclusion should be submitted?",
      verdict: [
        ["According to the reconstruction published by RIO54, the object was later identified as a sounding balloon of French origin.", ""],
        ["The episode proves that an extraterrestrial spacecraft flew over Buenos Aires.", "There is no evidence in this case file to support that claim."],
        ["No sighting ever took place: the entire case was fabricated.", "The source does report numerous observations; what changes is the explanation of the object."]
      ]
    },
    c2: {
      top: [
        "Institutions and documents", "The Commission Under Scrutiny", "CEFAE · 2010–2015",
        "An official commission announces its mission, is formally established, and later a first report cited by the blog appears.",
        "This case examines how a public institution can be assessed through announcements, resolutions, stated missions, and published documents. It also requires distinguishing a source’s content from its authors’ opinions.",
        "The RIO54 blog brings together posts from 2011 and 2015 about the Commission for the Study of Aerospace Phenomena (CEFAE). The blog’s editorial criticism is presented as such, not as facts proven by the game.",
        "On the table are clippings, a resolution mentioned in a report, and a page describing the institution’s mission. Years later, the blog returns to the subject when commenting on the appearance of a report. Your task is to separate chronology, documents, and evaluation.",
        "What is the most rigorous reading of the timeline?", "What should the investigator’s final report say?",
        "Good research separates administrative facts, publications, and opinions.",
        "The timeline in the blog distinguishes an announcement in 2010, the formal establishment of CEFAE in 2011, and the publication of a report in 2015. Objections to the report’s format are criticisms made by the blog’s authors. A full audit would require consulting the Air Force’s original resolution and report."
      ],
      clues: [
        ["The initial announcement", "TIMELINE", "The news appeared in December 2010.", "In the article “Los misterios de la comisión oficial sobre ovnis”, RIO54 places the first televised announcement of the future commission on 22 December 2010, during an interview with Commodore Guillermo Daniel Tealdi.", "“Los misterios de la comisión oficial sobre ovnis”, RIO54, 22 Dec 2011.", "Record this date as the announcement of a commission yet to be created, not as its formal date of establishment.", "Confusing the first television announcement with the administrative resolution.", "Good. A news announcement and the administrative act that formally establishes an organization are two different things.", "The announcement came before the formal resolution mentioned in the article itself."],
        ["Name and mission", "INSTITUTIONAL DOCUMENT", "CEFAE: the study of aerospace phenomena.", "The June 2011 post says the unit was named the Commission for the Study of Aerospace Phenomena (CEFAE). It reproduces a mission aimed at documenting, analyzing, and systematically and accurately studying phenomena not identified by conventional control systems in the national jurisdiction’s airspace.", "“La comisión de la Fuerza Aérea ya está en la web”, RIO54, 19 Jun 2011; the article transcribes the official introductory text.", "Distinguish the formal name and stated mission from any conclusion about the results of its investigations.", "Reading the institution’s mission as proof that an extraordinary case was confirmed.", "Correct. A mission describes what an office says it is supposed to do; it does not predict the results.", "The mandate to study unidentified phenomena does not mean that the institution confirmed a hypothesis."],
        ["The resolution mentioned", "REPORTED ADMINISTRATIVE ACT", "The formal establishment described by the blog.", "The December 2011 article states that the resolution officially establishing CEFAE was signed on 5 May 2011. The same post reproduces the general purpose of advising the Air Force on matters related to unidentified aerospace phenomena.", "“Los misterios de la comisión oficial sobre ovnis”, RIO54, 22 Dec 2011.", "Record the date and make clear that the information comes from the blog’s documentary account.", "Claiming to know the full text of the resolution without consulting the original document.", "Good practice: you preserved both the information and the provenance of the claim.", "The post summarizes and quotes parts of the resolution; that is not the same as reviewing the complete administrative document here."],
        ["The 2015 report", "PUBLICATION AND CRITICISM", "The blog comments on the first published report.", "In a post dated 18 December 2015, RIO54 says that the CEFAE’s first report was published on the Air Force website earlier that month, four and a half years after its creation. The authors also question the PDF’s format and the absence of signatures, as they describe it.", "“Luego de cuatro años y medio, la comisión oficial sobre ovnis lanzó su primer informe”, RIO54, 18 Dec 2015. This is the blog authors’ description and evaluation.", "Separate the event reported by the blog—the publication of the report—from the authors’ criticism of how it was presented.", "Concluding that the report proves a cover-up or that no work was done at all.", "Exactly. Documentary criticism may be relevant without proving an intention to conceal information on its own.", "The delay and formal objections may justify questions, but they do not automatically prove a cover-up."]
      ],
      boardQ: "What is the most rigorous reading of the timeline?",
      board: [
        ["There was an announcement in 2010, formal establishment in 2011, and the blog reported the publication of a first report in 2015; criticism of that report should be attributed to its authors.", "Correct: you separated the timeline from the editorial assessment."],
        ["The existence of CEFAE proves that the Air Force confirmed extraterrestrial visits.", "The institution’s mission refers to studying unidentified phenomena, not confirming extraterrestrials."],
        ["The late appearance of a report necessarily proves that the entire commission was fictitious.", "The source describes a commission, its formal establishment, and a report; the delay does not prove that it never existed."]
      ],
      verdictQ: "What should the investigator’s final report say?",
      verdict: [
        ["According to the timeline recorded by RIO54, CEFAE was announced and formally established; the blog reported a first report in 2015 and criticized its presentation. Those criticisms do not by themselves prove a cover-up.", ""],
        ["CEFAE found extraterrestrial spacecraft and secretly confirmed it.", "There is no evidence for this claim in the documents in the case file."],
        ["The commission never existed and all announcements were false.", "The timeline in the archive contradicts that conclusion."]
      ]
    },
    c3: {
      top: [
        "Testimony and caution", "The Night in Monte Grande", "Monte Grande, Buenos Aires Province · 26 September 2011",
        "An explosion, a fatality, and accounts of a light in the sky gave rise to hypotheses that must be examined carefully.",
        "This case addresses a tragic event mentioned in the blog’s reports. It will be approached respectfully: without recreating the harm, turning grief into spectacle, or presenting a hypothesis about the cause of the explosion as fact.",
        "The RIO54 publication reports one fatality. The game does not graphically depict the event and does not claim to have established the cause of the explosion.",
        "The archive contains a short news report: an explosion destroyed homes and a shop. Local residents linked a bright light to the moment of the blast. The case became a topic of discussion and very different explanations circulated. The first rule is not to confuse temporal proximity with proven causation.",
        "How should the account of the light be related to the explosion?", "What conclusion is responsible given the available material?",
        "Sometimes the strongest conclusion is to acknowledge what could not be established.",
        "RIO54’s report mentions an explosion with serious human consequences and records that residents spoke of a bright light. It also lists hypotheses that circulated. The information consulted does not establish the cause; out of respect for those affected, the game avoids turning a tragedy into a UFO spectacle."
      ],
      clues: [
        ["The event", "REPORTED EVENT", "Date and human consequences.", "RIO54’s report places the explosion in the early hours of Monday, 26 September 2011. It says that two houses and a shop were completely destroyed and that one person died.", "“OVNIS: exitosa reunión RIO54 de octubre”, RIO54, 9 Oct 2011.", "Record the event and its human consequences without speculating about the cause.", "Treating the tragedy as a fictional scene or as proof of a non-human origin.", "Thank you for keeping the focus on the event and the people affected. Investigation must begin there.", "The tragedy deserves respect. Its severity does not by itself determine the cause of the explosion."],
        ["What residents said", "REPORTED TESTIMONY", "A bright light was reportedly seen.", "The report says that local residents claimed a bright light came from the sky at the moment of the blast. The post consulted here does not provide full statements, instrumental records, or expert reports that would allow each account to be assessed separately.", "RIO54’s report summarizes the testimony of local residents.", "Record the light as an account attributed to residents and seek original statements before evaluating it.", "Claiming that the light caused the explosion because it was reported at the same time.", "Good. A coincidence in time is a lead to investigate, not proof of causation.", "Perceived simultaneity is not enough to prove that the light caused the explosion."],
        ["The hypotheses that circulated", "PUBLIC HYPOTHESES", "Meteorite, space debris, or spacecraft.", "The post lists hypotheses that circulated quickly: a meteorite fall, space debris, or even a craft of non-terrestrial origin. The list documents the public discussion; it confirms none of those options.", "“OVNIS: exitosa reunión RIO54 de octubre”, RIO54, 9 Oct 2011.", "Classify these options as hypotheses that were mentioned and still require independent evidence.", "Choosing the most spectacular hypothesis because it spread quickly.", "Correct. The appearance of a hypothesis in a news report is not equivalent to an expert finding.", "Rapid circulation does not make a hypothesis stronger or replace material evidence."],
        ["What is missing to resolve it", "LIMITS OF THE ARCHIVE", "The report provides no conclusive expert findings.", "In the passages consulted, the blog summarizes the event, records residents’ accounts, and mentions hypotheses. This material alone does not identify the origin of the explosion. Further work would require, among other things, expert assessments, official case files, technical records, and original testimonies that can be cross-checked.", "Assessment of the scope of the RIO54 posts consulted; this is not a claim that no other documents exist.", "Conclude that the information in this case file is insufficient to assign a cause.", "Filling the gaps in the evidence with an unsupported certainty.", "That is a valid conclusion: recognizing a limit is also a research result.", "When documents are missing, inventing an explanation does not solve the case."]
      ],
      boardQ: "How should the account of the light be related to the explosion?",
      board: [
        ["The account is relevant and deserves checking, but the timing alone does not prove that the light caused the explosion.", "Correct. You distinguish a lead from an established causal relationship."],
        ["The light was necessarily a spacecraft that caused the explosion.", "The report provides no evidence identifying the light or linking it causally to the explosion."],
        ["Because an explosion occurred, residents could not have seen any light.", "The occurrence of a tragedy does not automatically invalidate testimony; it must be examined."]
      ],
      verdictQ: "What conclusion is responsible given the available material?",
      verdict: [
        ["The report records a tragic explosion and accounts of a light, but the posts consulted are not enough to determine the cause of the event.", ""],
        ["It has been proven that an extraterrestrial spacecraft crashed in Monte Grande.", "The case file contains no expert findings or evidence that would support this claim."],
        ["It has been proven that all the accounts were fabricated.", "Insufficient corroboration does not prove that the witnesses lied."]
      ]
    },
    c4: {
      top: [
        "Antarctic archive", "Echoes from the White Continent", "Argentine Antarctica · 1965 / documentary recollection from 2016",
        "A 1965 naval statement and a 2016 RIO54 meeting help reconstruct the history of official investigations.",
        "The final case follows the traces of an Antarctic episode cited in the RIO54 archive. The story appears decades later in a newspaper clipping and at a commemorative meeting. You must distinguish the historical announcement, later recollections, and subsequent interpretations.",
        "The game material is based on the RIO54 post of 26 July 2016. To cross-check technical details and complete testimonies, consult the original publications and documents mentioned there.",
        "The cold preserves documents, but time also changes how we remember them. At a meeting in July 2016, RIO54 revisited a naval statement issued 51 years earlier and the history of a study commission. Your task is to reconstruct what this documentary memory claims.",
        "Which reconstruction best respects the distance between the documents?", "Which conclusion is best supported?",
        "Historical memory opens questions; original documents help refine them.",
        "The July 2016 RIO54 post recalls a 1965 naval statement, reproduces a newspaper clipping, and mentions COPEFO. It also includes participants’ recollections and bibliographic references. It is a starting point for archival research, not sufficient proof of the nature of the phenomena observed."
      ],
      clues: [
        ["The 1965 clipping", "REPORTED PRESS DOCUMENT", "A report in the newspaper Crónica, 7 July.", "The July 2016 RIO54 post shows a clipping from the newspaper Crónica dated 7 July 1965. The text links it to the Navy’s first official statement about UFO sightings in Argentine Antarctica.", "“En RIO54 se recordó a la comisión OVNI de la Armada Argentina”, RIO54, 26 Jul 2016.", "Record the clipping as a press reference reproduced in a later post.", "Claiming that the clipping alone proves the nature of the phenomenon observed.", "Good. You identified the documentary medium and the time gap between the event and the later post recalling it.", "A clipping can establish that a statement or news item existed; it does not automatically establish the origin of the phenomenon."],
        ["The COPEFO commission", "INSTITUTIONAL CONTEXT", "A naval study commission in the 1960s.", "The post mentions the Permanent Commission for the Study of the UFO Phenomenon (COPEFO), under the command of Captain Omar Roque Pagani, and describes its work as an official investigation conducted by the Navy during the 1960s.", "RIO54 post of 26 Jul 2016, summarizing references from the book “Los ovnis de la Antártida”.", "Record the existence of a commission mentioned by the source and look for its original documents.", "Assuming that every official commission necessarily reached an extraterrestrial conclusion.", "Correct. Institutional context adds to the history of the investigation; it is not a verdict on the origin.", "The existence of a study body does not mean that it confirmed a particular hypothesis."],
        ["The 2016 recollection", "MEMORY AND RETROSPECTIVE", "RIO54 revisits the episode 51 years later.", "On 7 July 2016, the 51st anniversary of the 1965 communication, RIO54 devoted part of its meeting to remembering the subject. The post mentions Rubén Morales’s book “Los ovnis de la Antártida” and its chapter on Antarctic investigations.", "“En RIO54 se recordó a la comisión OVNI de la Armada Argentina”, 26 Jul 2016.", "Separate the 2016 recollection from the 1965 document and events it seeks to remember.", "Treating memories from 2016 as if they were contemporary testimony for every sighting.", "Good. Later recollections can guide research, but they do not replace contemporary sources.", "Later memories are valuable, but they must be distinguished from records produced at the time."],
        ["The voices of the investigation", "TESTIMONY AND CONTEXT", "Recalled experiences and fieldwork.", "The report includes Mario Coen’s recollections of fieldwork in 1964 and 1965 near Dique Los Molinos, Córdoba, where—according to his account—almost twenty cases had been reported. It also recalls conversations with former Navy investigators.", "The post reproduces recollections shared at a RIO54 meeting in July 2016.", "Identify these passages as recollections attributed to participants, not as complete technical reports.", "Turning remembered anecdotes into definitive evidence of a non-human origin.", "Exactly. Retrospective testimony can be a lead, but it should be checked against contemporary records.", "An anecdote deserves to be heard and examined, but it is not enough on its own to establish an extraordinary origin."]
      ],
      boardQ: "Which reconstruction best respects the distance between the documents?",
      board: [
        ["A 1965 clipping was revisited in 2016; the meeting also recalled COPEFO and historical testimonies, which need to be checked against their original sources.", "Correct: you distinguished the document, institutional memory, and personal recollections."],
        ["The 2016 meeting proves that every Antarctic sighting involved extraterrestrial spacecraft.", "Remembering one case does not establish the nature of all sightings."],
        ["Because the clipping was shown in 2016, it cannot provide any information about 1965.", "A later reproduction can guide the search for a document, although locating the original is advisable."]
      ],
      verdictQ: "Which conclusion is best supported?",
      verdict: [
        ["RIO54 recalls a 1965 naval statement and a history of official investigations; the summarized material documents that recollection but does not by itself prove an extraterrestrial origin.", ""],
        ["The Navy officially confirmed that the sightings were extraterrestrial spacecraft.", "The post does not say that the statement confirmed an extraterrestrial origin."],
        ["There were no official investigations or documents on the subject.", "The source mentions the statement, the clipping, and the COPEFO commission."]
      ]
    }
  },
  'pt-BR': {
    c1: {
      top: [
        "Reconstrução histórica", "A Luz de Setembro", "Buenos Aires e região metropolitana · 17 de setembro de 1985",
        "Um objeto aéreo é observado por muitas pessoas. Anos depois, o arquivo do RIO54 registra uma explicação concreta.",
        "Este caso parte de uma observação em massa sobre Buenos Aires e sua região metropolitana. A tarefa é reconstruir o que foi publicado, qual explicação posterior aparece no arquivo e até onde essas informações permitem chegar.",
        "Ponto de partida documental: uma publicação do RIO54, de 27 de dezembro de 2011, atribui à investigação de Carlos Demaría o esclarecimento do episódio como um balão-sonda de origem francesa.",
        "A cidade se lembra de uma luz estranha. Em uma pasta de hemeroteca há recortes, datas e uma nota que retoma o caso. Você não encontrará uma fotografia mágica que explique tudo: terá de reconstruir a cadeia de informações.",
        "Qual relação descreve melhor o caso completo?", "Com as informações reunidas, que conclusão deve ser apresentada?",
        "O caso encontra uma explicação documentada na fonte consultada.",
        "A publicação do RIO54 atribui às investigações de Carlos Demaría a identificação do objeto como um balão-sonda francês. A conclusão se limita a este episódio e ao que aquela publicação relata: não resolve outros casos nem invalida outros testemunhos."
      ],
      clues: [
        ["A data do episódio", "CRONOLOGIA", "Uma referência temporal específica.", "A publicação do RIO54 situa o episódio em 17 de setembro de 1985 e informa que o objeto foi observado na cidade de Buenos Aires e na região metropolitana bonaerense.", "Publicação “Los blogs de Carlos Demaría”, RIO54, 27/12/2011.", "Registrar a data, a região e o alcance exatamente como aparecem na publicação.", "Transformar a quantidade de observadores em prova automática de uma origem extraordinária.", "Correto. Você registrou o dado verificável nesta fonte sem atribuir a ele mais do que diz.", "Muitos observadores tornam o caso interessante, mas não determinam por si só o que era o objeto."],
        ["Os relatos da observação", "TESTEMUNHOS MENCIONADOS", "O que um testemunho coletivo pode acrescentar.", "A publicação fala de numerosas testemunhas. O arquivo não transcreve aqui cada relato individual nem oferece, nesta entrada, uma base de entrevistas que permita comparar descrições, ângulos de observação ou horários.", "A publicação do RIO54 resume o caso; não reproduz todos os testemunhos originais.", "Distinguir a referência geral às testemunhas dos depoimentos completos que não foram incluídos.", "Afirmar que todos viram exatamente a mesma coisa, embora o texto não detalhe isso.", "Muito bem. Você não confundiu a existência de relatos com o acesso a cada declaração original.", "O arquivo não permite afirmar que todos descreveram o mesmo objeto com detalhes idênticos."],
        ["A investigação posterior", "ATRIBUIÇÃO DOCUMENTAL", "A explicação registrada pelo RIO54.", "O RIO54 lembra a contribuição de Carlos Demaría para o esclarecimento do caso e afirma que, após as averiguações pertinentes, o objeto acabou sendo identificado como um balão-sonda de origem francesa.", "Publicação “Los blogs de Carlos Demaría”, RIO54, 27/12/2011.", "Anotar que esta é a explicação que a publicação atribui às averiguações de Demaría.", "Atribuir à entrada detalhes técnicos que não aparecem nela.", "Exatamente. Você preservou a atribuição à fonte e evitou inventar detalhes sobre o balão.", "O texto fornece uma identificação geral, mas não descreve naquela entrada todos os detalhes técnicos da investigação."],
        ["O limite da palavra OVNI", "CRITÉRIO", "Não identificado não significa extraterrestre.", "Em uma investigação, “objeto voador não identificado” descreve uma observação cuja identidade é desconhecida naquele momento. Não é uma classificação de sua procedência nem uma prova de tecnologia não humana.", "Critério metodológico incorporado à experiência de jogo; não é uma citação literal do blog.", "Separar a descrição inicial do objeto da explicação posterior registrada pela fonte.", "Tratar a sigla OVNI como sinônimo de nave extraterrestre.", "Esse é o passo central do caso: um rótulo de incerteza não é uma conclusão sobre a origem.", "A sigla indica que algo não foi identificado naquele momento; não prova uma procedência extraterrestre."]
      ],
      boardQ: "Qual relação descreve melhor o caso completo?",
      board: [
        ["Os relatos iniciais motivaram a investigação; a publicação posterior registra uma identificação como balão-sonda francês.", "A síntese respeita a sequência dos fatos e a atribuição à fonte."],
        ["A grande quantidade de testemunhas prova que se tratava de uma nave extraterrestre.", "A quantidade de testemunhas não estabelece a natureza do objeto."],
        ["Como houve uma explicação posterior, os testemunhos originais necessariamente foram inventados.", "Uma identificação posterior não prova que os observadores mentiram."]
      ],
      verdictQ: "Com as informações reunidas, que conclusão deve ser apresentada?",
      verdict: [
        ["Segundo a reconstrução publicada pelo RIO54, o objeto foi posteriormente identificado como um balão-sonda de origem francesa.", ""],
        ["O episódio prova que uma nave extraterrestre sobrevoou Buenos Aires.", "Não há evidências neste caso que sustentem essa afirmação."],
        ["Nunca houve observação alguma: o caso foi totalmente inventado.", "A fonte menciona numerosas observações; o que muda é a explicação do objeto."]
      ]
    },
    c2: {
      top: [
        "Instituições e documentos", "A Comissão sob Escrutínio", "CEFAE · 2010–2015",
        "Uma comissão oficial anuncia sua missão, é formalizada e, mais tarde, surge um primeiro relatório citado pelo blog.",
        "Este caso investiga como avaliar uma instituição pública a partir de anúncios, resoluções, missões declaradas e documentos publicados. Também exige distinguir o conteúdo de uma fonte das opiniões de seus autores.",
        "O blog do RIO54 reúne publicações de 2011 e 2015 sobre a Comissão de Estudo de Fenômenos Aeroespaciais (CEFAE). As críticas editoriais do blog são apresentadas como tais, não como fatos comprovados pelo jogo.",
        "Sobre a mesa há recortes, uma resolução mencionada em uma reportagem e uma página com a missão institucional. Anos depois, o blog retoma o tema ao comentar o aparecimento de um relatório. Seu trabalho é separar cronologia, documento e avaliação.",
        "Qual é a leitura mais rigorosa da cronologia?", "O que deveria dizer o relatório final do investigador?",
        "A melhor investigação separa fatos administrativos, publicações e opiniões.",
        "A cronologia do blog distingue um anúncio em 2010, a formalização da CEFAE em 2011 e a publicação de um relatório em 2015. As objeções à forma do relatório são críticas dos autores do blog. Uma auditoria completa exigiria consultar a resolução e o relatório originais da Força Aérea."
      ],
      clues: [
        ["O anúncio inicial", "CRONOLOGIA", "A notícia aparece em dezembro de 2010.", "No artigo “Los misterios de la comisión oficial sobre ovnis”, o RIO54 situa o primeiro anúncio televisivo da futura comissão em 22 de dezembro de 2010, durante uma entrevista com o comodoro Guillermo Daniel Tealdi.", "“Los misterios de la comisión oficial sobre ovnis”, RIO54, 22/12/2011.", "Registrar a data como o anúncio de uma comissão ainda por criar, não como sua data formal de criação.", "Confundir o primeiro anúncio televisivo com a resolução administrativa.", "Muito bem. Uma notícia de anúncio e o ato administrativo que formaliza um órgão são coisas diferentes.", "O anúncio ocorreu antes da resolução formal mencionada pelo próprio artigo."],
        ["Nome e missão", "DOCUMENTO INSTITUCIONAL", "CEFAE: estudo de fenômenos aeroespaciais.", "A publicação de junho de 2011 informa que a unidade foi denominada Comissão de Estudo de Fenômenos Aeroespaciais (CEFAE). Reproduz uma missão voltada a documentar, analisar e estudar de forma ordenada e precisa fenômenos não identificados por sistemas de controle convencionais no espaço aéreo sob jurisdição nacional.", "“La comisión de la Fuerza Aérea ya está en la web”, RIO54, 19/06/2011; o artigo transcreve o texto de apresentação oficial.", "Diferenciar o nome formal e a missão declarada de qualquer conclusão sobre os resultados das investigações.", "Ler a missão institucional como se fosse prova de que um caso extraordinário foi confirmado.", "Correto. Uma missão define o que um órgão diz que deve fazer, não antecipa seus resultados.", "O mandato de estudar fenômenos não identificados não significa que a instituição tenha confirmado uma hipótese."],
        ["A resolução mencionada", "ATO ADMINISTRATIVO REFERIDO", "A formalização descrita pelo blog.", "O artigo de dezembro de 2011 afirma que a resolução que oficializou a CEFAE foi assinada em 5 de maio de 2011. A mesma publicação reproduz o propósito geral de assessorar a Força Aérea em assuntos relacionados a fenômenos aeroespaciais não identificados.", "“Los misterios de la comisión oficial sobre ovnis”, RIO54, 22/12/2011.", "Anotar a data e registrar que a informação vem do relato documental do blog.", "Afirmar conhecer o texto completo da resolução sem ter consultado o documento original.", "Boa prática: você preservou o dado e a procedência da afirmação.", "A publicação resume e cita partes da resolução; isso não equivale a consultar aqui o documento administrativo completo."],
        ["O relatório de 2015", "PUBLICAÇÃO E CRÍTICA", "O blog comenta o primeiro relatório publicado.", "Em uma publicação de 18 de dezembro de 2015, o RIO54 afirma que o primeiro relatório da CEFAE foi publicado no site da Força Aérea no início daquele mês, quatro anos e meio após sua criação. Os autores também questionam o formato do PDF e a falta de assinaturas que, segundo descrevem, ele apresentava.", "“Luego de cuatro años y medio, la comisión oficial sobre ovnis lanzó su primer informe”, RIO54, 18/12/2015. Trata-se da descrição e avaliação dos autores do blog.", "Separar o fato relatado pelo blog — a publicação do relatório — das críticas dos autores à sua apresentação.", "Concluir que o relatório prova um encobrimento ou que nenhum trabalho foi realizado.", "Exatamente. Uma crítica documental pode ser relevante sem provar, por si só, uma intenção de ocultar informações.", "A demora e as objeções formais podem justificar perguntas, mas não provam automaticamente um encobrimento."]
      ],
      boardQ: "Qual é a leitura mais rigorosa da cronologia?",
      board: [
        ["Houve um anúncio em 2010, a formalização em 2011 e o blog informou a publicação de um primeiro relatório em 2015; as críticas a esse relatório devem ser atribuídas a seus autores.", "Correto: você separou a cronologia da avaliação editorial."],
        ["A existência da CEFAE prova que a Força Aérea confirmou visitas extraterrestres.", "A missão institucional fala em estudar fenômenos não identificados, não em confirmar extraterrestres."],
        ["O aparecimento tardio de um relatório prova necessariamente que toda a comissão era fictícia.", "A fonte descreve uma comissão, sua formalização e um relatório; a demora não prova que ela não existiu."]
      ],
      verdictQ: "O que deveria dizer o relatório final do investigador?",
      verdict: [
        ["Segundo a cronologia registrada pelo RIO54, a CEFAE foi anunciada e formalizada; o blog informou um primeiro relatório em 2015 e criticou sua apresentação. Essas críticas, por si só, não provam um encobrimento.", ""],
        ["A CEFAE encontrou naves extraterrestres e confirmou isso em segredo.", "Não há evidências dessa afirmação nos documentos deste caso."],
        ["A comissão nunca existiu e todos os anúncios eram falsos.", "A cronologia do próprio arquivo contradiz essa conclusão."]
      ]
    },
    c3: {
      top: [
        "Testemunhos e prudência", "A Noite de Monte Grande", "Monte Grande, Província de Buenos Aires · 26 de setembro de 2011",
        "Uma explosão, uma vítima fatal e relatos de uma luz no céu geram hipóteses que precisam ser examinadas com cuidado.",
        "Este caso aborda um acontecimento trágico mencionado nas crônicas do blog. O tratamento será respeitoso: sem recriar o dano, sem transformar a dor em espetáculo e sem apresentar como fato uma hipótese sobre a origem da explosão.",
        "A publicação do RIO54 informa que houve uma vítima fatal. O jogo não representa graficamente o ocorrido e não afirma ter estabelecido a causa da explosão.",
        "O arquivo contém uma notícia breve: uma explosão destruiu casas e um comércio. Moradores relacionaram uma luz intensa ao momento do estrondo. O caso virou assunto de conversa e circularam explicações muito diferentes. A primeira regra é não confundir proximidade temporal com causalidade comprovada.",
        "Como o relato da luz deve ser relacionado à explosão?", "Que conclusão é responsável diante do material disponível?",
        "Às vezes, a conclusão mais sólida é reconhecer o que não pôde ser estabelecido.",
        "A crônica do RIO54 menciona uma explosão com graves consequências humanas e registra que moradores falaram de uma luz intensa. Também lista hipóteses que circularam. As informações consultadas não permitem determinar a causa; por respeito às pessoas afetadas, o jogo evita transformar uma tragédia em espetáculo ufológico."
      ],
      clues: [
        ["O acontecimento", "FATO RELATADO", "Data e consequências humanas.", "A crônica do RIO54 situa a explosão na madrugada de segunda-feira, 26 de setembro de 2011. Informa que duas casas e um comércio foram completamente destruídos e que houve uma vítima fatal.", "“OVNIS: exitosa reunión RIO54 de octubre”, RIO54, 09/10/2011.", "Registrar o fato e suas consequências humanas sem especular sobre a causa.", "Tratar a tragédia como uma cena de ficção ou como prova de origem não humana.", "Obrigado por manter o foco no acontecimento e nas pessoas afetadas. A investigação deve começar por aí.", "A tragédia merece respeito. Sua gravidade não determina, por si só, a origem da explosão."],
        ["O que disseram os moradores", "TESTEMUNHO REFERIDO", "Uma luz intensa teria sido vista.", "A crônica afirma que moradores do local disseram que uma luz intensa veio do céu no momento da explosão. A publicação consultada não apresenta declarações completas, registros instrumentais ou perícias que permitam avaliar separadamente cada relato.", "A crônica do RIO54 resume os testemunhos dos moradores.", "Registrar a luz como um relato atribuído aos moradores e procurar declarações originais antes de avaliá-lo.", "Afirmar que a luz causou a explosão porque foi relatada no mesmo momento.", "Muito bem. Uma coincidência temporal é uma pista para investigar, não uma demonstração causal.", "A simultaneidade percebida não basta para provar que a luz causou a explosão."],
        ["As hipóteses que circularam", "HIPÓTESES PÚBLICAS", "Meteoro, lixo espacial ou nave.", "A publicação enumera hipóteses que circularam rapidamente: queda de um meteoro, lixo espacial ou até uma nave de origem não terrestre. A lista documenta a conversa pública, mas não confirma nenhuma dessas opções.", "“OVNIS: exitosa reunión RIO54 de octubre”, RIO54, 09/10/2011.", "Classificar essas opções como hipóteses mencionadas, ainda dependentes de provas independentes.", "Escolher a hipótese mais espetacular porque ela se difundiu rapidamente.", "Correto. A presença de uma hipótese em uma crônica não equivale a uma conclusão pericial.", "A velocidade de divulgação não aumenta a qualidade de uma hipótese nem substitui evidências materiais."],
        ["O que falta para resolver", "LIMITES DO ARQUIVO", "A crônica não apresenta perícias conclusivas.", "Nos trechos consultados, o blog resume o fato, registra relatos de moradores e menciona hipóteses. Esse material, por si só, não identifica a origem da explosão. Para avançar seriam necessárias, entre outras coisas, perícias, processos oficiais, registros técnicos e testemunhos originais que pudessem ser confrontados.", "Avaliação do alcance das publicações do RIO54 consultadas; não é uma afirmação de que não existam outros documentos.", "Concluir que as informações deste caso são insuficientes para atribuir uma causa.", "Preencher a falta de dados com uma certeza sem sustentação.", "Essa é uma conclusão válida: reconhecer um limite também é um resultado de investigação.", "Quando faltam documentos, inventar uma explicação não resolve o caso."]
      ],
      boardQ: "Como o relato da luz deve ser relacionado à explosão?",
      board: [
        ["O relato é relevante e merece ser verificado, mas a coincidência temporal não prova que a luz tenha causado a explosão.", "Correto. Você diferencia uma pista de uma relação causal estabelecida."],
        ["A luz era necessariamente uma nave que provocou a explosão.", "A crônica não apresenta evidências que identifiquem a luz nem que a relacionem causalmente à explosão."],
        ["Como houve uma explosão, os moradores não poderiam ter visto nenhuma luz.", "A ocorrência de uma tragédia não invalida automaticamente os testemunhos; eles devem ser examinados."]
      ],
      verdictQ: "Que conclusão é responsável diante do material disponível?",
      verdict: [
        ["A crônica registra uma explosão trágica e testemunhos sobre uma luz, mas as publicações consultadas não bastam para determinar a causa do ocorrido.", ""],
        ["Está provado que uma nave extraterrestre caiu em Monte Grande.", "O caso não contém perícias nem evidências que permitam afirmar isso."],
        ["Está provado que todos os testemunhos foram inventados.", "A falta de confirmação suficiente não prova que as testemunhas tenham mentido."]
      ]
    },
    c4: {
      top: [
        "Arquivo antártico", "Ecos do Continente Branco", "Antártida Argentina · 1965 / memória documental de 2016",
        "Um comunicado naval de 1965 e uma reunião do RIO54 em 2016 ajudam a reconstruir a memória de investigações oficiais.",
        "O último caso segue os rastros de um episódio antártico citado no arquivo do RIO54. A história aparece décadas depois em um recorte de jornal e em uma reunião comemorativa. É preciso distinguir o anúncio histórico, as lembranças e as interpretações posteriores.",
        "O material do jogo se baseia na publicação do RIO54 de 26 de julho de 2016. Para confrontar detalhes técnicos e testemunhos completos, é necessário consultar as publicações e os documentos originais ali mencionados.",
        "O frio conserva os documentos, mas o tempo também muda a forma como nos lembramos deles. Em uma reunião de julho de 2016, o RIO54 retomou um comunicado naval emitido 51 anos antes e a história de uma comissão de estudo. Sua tarefa é reconstruir o que essa memória documental afirma.",
        "Qual reconstrução respeita melhor a distância entre os documentos?", "Qual conclusão tem melhor sustentação?",
        "A memória histórica abre perguntas; os documentos originais permitem refiná-las.",
        "A publicação do RIO54 de julho de 2016 recorda um comunicado naval de 1965, reproduz um recorte de jornal e menciona a COPEFO. Também inclui lembranças de participantes e referências bibliográficas. É um ponto de partida para pesquisar arquivos, não uma prova suficiente da natureza dos fenômenos observados."
      ],
      clues: [
        ["O recorte de 1965", "DOCUMENTO DE IMPRENSA MENCIONADO", "Notícia do jornal Crónica, 7 de julho.", "A publicação do RIO54 de julho de 2016 mostra um recorte do jornal Crónica datado de 7 de julho de 1965. O texto o relaciona ao primeiro comunicado oficial da Marinha sobre avistamentos de OVNIs na Antártida Argentina.", "“En RIO54 se recordó a la comisión OVNI de la Armada Argentina”, RIO54, 26/07/2016.", "Registrar o recorte como uma referência jornalística reproduzida em uma publicação posterior.", "Afirmar que o recorte, por si só, prova a natureza do fenômeno observado.", "Muito bem. Você identificou o suporte documental e a distância temporal entre o acontecimento e a publicação que o recorda.", "Um recorte pode comprovar que houve uma comunicação ou notícia; não estabelece automaticamente a origem do fenômeno."],
        ["A comissão COPEFO", "CONTEXTO INSTITUCIONAL", "Uma comissão naval de estudo nos anos sessenta.", "A publicação menciona a Comissão Permanente para o Estudo do Fenômeno OVNI (COPEFO), sob o comando do capitão Omar Roque Pagani, e descreve seu trabalho como uma investigação oficial desenvolvida pela Marinha durante a década de 1960.", "Publicação do RIO54 de 26/07/2016, que resume referências do livro “Los ovnis de la Antártida”.", "Registrar a existência de uma comissão mencionada pela fonte e procurar seus documentos originais.", "Supor que toda comissão oficial necessariamente chegou a uma conclusão extraterrestre.", "Correto. O contexto institucional acrescenta história da investigação, não um veredito sobre a origem.", "A existência de um órgão de estudo não significa que ele tenha confirmado uma hipótese específica."],
        ["A lembrança de 2016", "MEMÓRIA E RETROSPECTIVA", "O RIO54 retoma o episódio 51 anos depois.", "Em 7 de julho de 2016, no 51º aniversário da comunicação de 1965, o RIO54 dedicou parte de sua reunião a recordar o tema. A publicação menciona o livro “Los ovnis de la Antártida”, de Rubén Morales, e o capítulo dedicado às investigações antárticas.", "“En RIO54 se recordó a la comisión OVNI de la Armada Argentina”, 26/07/2016.", "Separar a memória de 2016 do documento e dos acontecimentos de 1965 que ela procura recordar.", "Tratar as lembranças de 2016 como se fossem testemunhos contemporâneos de cada observação.", "Muito bem. A memória posterior orienta a pesquisa, mas não substitui as fontes contemporâneas.", "As lembranças posteriores são valiosas, mas devem ser distinguidas dos registros produzidos na época."],
        ["As vozes da investigação", "TESTEMUNHO E CONTEXTO", "Experiências lembradas e trabalho de campo.", "A crônica reúne lembranças de Mario Coen sobre trabalhos de campo de 1964 e 1965 na região de Dique Los Molinos, Córdoba, onde — segundo seu relato — quase vinte casos haviam sido registrados. Também recorda conversas com antigos pesquisadores da Marinha.", "A publicação reproduz lembranças compartilhadas em uma reunião do RIO54 em julho de 2016.", "Identificar essas passagens como lembranças atribuídas aos participantes, e não como relatórios técnicos completos.", "Transformar relatos lembrados em evidência definitiva de uma origem não humana.", "Exatamente. O testemunho retrospectivo pode ser uma pista, mas deve ser confrontado com registros contemporâneos.", "Uma anedota merece ser ouvida e analisada, mas não basta, por si só, para estabelecer uma origem extraordinária."]
      ],
      boardQ: "Qual reconstrução respeita melhor a distância entre os documentos?",
      board: [
        ["Um recorte de 1965 foi retomado em 2016; a reunião também recordou a COPEFO e testemunhos históricos, que precisam ser confrontados com suas fontes originais.", "Correto: você separou o documento, a memória institucional e as lembranças pessoais."],
        ["A reunião de 2016 prova que todos os avistamentos antárticos envolveram naves extraterrestres.", "A lembrança de um caso não estabelece a natureza de todos os avistamentos."],
        ["Como o recorte foi mostrado em 2016, ele não pode fornecer nenhuma informação sobre 1965.", "Uma reprodução posterior pode orientar a busca pelo documento, embora seja recomendável localizar o original."]
      ],
      verdictQ: "Qual conclusão tem melhor sustentação?",
      verdict: [
        ["O RIO54 recorda um comunicado naval de 1965 e uma história de investigações oficiais; o material resumido documenta essa memória, mas não prova, por si só, uma origem extraterrestre.", ""],
        ["A Marinha confirmou oficialmente que as observações eram naves extraterrestres.", "A publicação não afirma que o comunicado tenha confirmado uma origem extraterrestre."],
        ["Não houve investigações oficiais nem documentos sobre o tema.", "A fonte menciona o comunicado, o recorte e a comissão COPEFO."]
      ]
    }
  },
  fr: {
    c1: {
      top: [
        "Reconstitution historique", "La lumière de septembre", "Buenos Aires et son agglomération · 17 septembre 1985",
        "Un objet aérien est observé par de nombreuses personnes. Des années plus tard, les archives de RIO54 rapportent une explication précise.",
        "Ce dossier part d’une observation collective au-dessus de Buenos Aires et de son agglomération. Votre tâche consiste à reconstituer ce qui a été publié, l’explication ultérieure rapportée par les archives et les limites de ce que ces informations permettent d’affirmer.",
        "Point de départ documentaire : un article de RIO54 publié le 27 décembre 2011 attribue à l’enquête de Carlos Demaría l’élucidation de l’épisode, identifié comme un ballon-sonde d’origine française.",
        "La ville se souvient d’une lumière étrange. Des coupures de presse, des dates et un article qui revient sur l’affaire se trouvent dans un dossier d’archives. Vous ne trouverez pas de photographie miraculeuse qui explique tout : vous devrez reconstituer la chaîne d’informations.",
        "Quelle relation décrit le mieux l’ensemble du dossier ?", "Compte tenu des informations recueillies, quelle conclusion faut-il présenter ?",
        "Le dossier trouve une explication documentée dans la source consultée.",
        "L’article de RIO54 attribue aux recherches de Carlos Demaría l’identification de l’objet comme un ballon-sonde français. Cette conclusion se limite à cet épisode et à ce que rapporte cet article : elle ne résout pas d’autres affaires et n’invalide pas d’autres témoignages."
      ],
      clues: [
        ["La date de l’événement", "CHRONOLOGIE", "Une référence temporelle précise.", "L’article de RIO54 situe l’épisode au 17 septembre 1985 et indique que l’objet a été observé depuis la ville de Buenos Aires et son agglomération.", "Article « Los blogs de Carlos Demaría », RIO54, 27/12/2011.", "Consigner la date, la zone et la portée exactement comme elles apparaissent dans la publication.", "Transformer le nombre d’observateurs en preuve automatique d’une origine extraordinaire.", "Exact. Vous avez consigné l’information vérifiable contenue dans cette source sans lui faire dire davantage.", "Un grand nombre d’observateurs rend l’affaire intéressante, mais ne suffit pas à déterminer ce qu’était l’objet."],
        ["Les récits de l’observation", "TÉMOIGNAGES RAPPORTÉS", "Ce qu’un témoignage collectif peut apporter.", "La publication évoque de nombreux témoins. Les archives ne reproduisent pas ici chaque récit individuel et cet article ne fournit pas de base d’entretiens permettant de comparer les descriptions, les angles d’observation ou les horaires.", "L’article de RIO54 résume l’affaire ; il ne reproduit pas tous les témoignages originaux.", "Distinguer la mention générale de témoins des déclarations complètes qui ne sont pas incluses.", "Affirmer que tout le monde a vu exactement la même chose alors que le texte ne le précise pas.", "Bien. Vous n’avez pas confondu l’existence de récits avec l’accès à chaque déclaration originale.", "Les archives ne permettent pas d’affirmer que tous ont décrit le même objet avec des détails identiques."],
        ["L’enquête ultérieure", "ATTRIBUTION DOCUMENTAIRE", "L’explication rapportée par RIO54.", "RIO54 rappelle la contribution de Carlos Demaría à l’élucidation de l’affaire et affirme qu’après les vérifications nécessaires, l’objet s’est révélé être un ballon-sonde d’origine française.", "Article « Los blogs de Carlos Demaría », RIO54, 27/12/2011.", "Noter qu’il s’agit de l’explication que la publication attribue aux recherches de Demaría.", "Attribuer à l’article des détails techniques qui n’y figurent pas.", "Exactement. Vous avez conservé l’attribution à la source et évité d’inventer des détails sur le ballon.", "Le texte donne une identification générale, mais ne décrit pas dans cet article tous les détails techniques de l’enquête."],
        ["Les limites du terme OVNI", "CRITÈRE", "Non identifié ne signifie pas extraterrestre.", "Dans une enquête, l’expression « objet volant non identifié » désigne une observation dont l’identité est inconnue à ce moment-là. Elle ne classe pas son origine et ne prouve pas une technologie non humaine.", "Critère méthodologique intégré à l’expérience de jeu ; il ne s’agit pas d’une citation littérale du blog.", "Séparer la description initiale de l’objet de l’explication ultérieure rapportée par la source.", "Prendre le terme OVNI pour un synonyme de vaisseau extraterrestre.", "C’est l’étape centrale de ce dossier : une étiquette exprimant l’incertitude n’est pas une conclusion sur l’origine.", "Le sigle indique que quelque chose n’a pas été identifié à ce moment-là ; il ne prouve pas une origine extraterrestre."]
      ],
      boardQ: "Quelle relation décrit le mieux l’ensemble du dossier ?",
      board: [
        ["Les récits initiaux ont motivé l’enquête ; la publication ultérieure rapporte une identification comme ballon-sonde français.", "La synthèse respecte la chronologie et l’attribution à la source."],
        ["Le grand nombre de témoins prouve qu’il s’agissait d’un vaisseau extraterrestre.", "Le nombre de témoins ne détermine pas la nature de l’objet."],
        ["Puisqu’une explication ultérieure existe, les témoignages originaux ont forcément été inventés.", "Une identification ultérieure ne prouve pas que les observateurs aient menti."]
      ],
      verdictQ: "Compte tenu des informations recueillies, quelle conclusion faut-il présenter ?",
      verdict: [
        ["Selon la reconstitution publiée par RIO54, l’objet a ensuite été identifié comme un ballon-sonde d’origine française.", ""],
        ["L’épisode prouve qu’un vaisseau extraterrestre a survolé Buenos Aires.", "Aucun élément du dossier ne vient étayer cette affirmation."],
        ["Aucune observation n’a jamais eu lieu : toute l’affaire a été inventée.", "La source fait bien état de nombreuses observations ; c’est l’explication de l’objet qui change."]
      ]
    },
    c2: {
      top: [
        "Institutions et documents", "La commission passée au crible", "CEFAE · 2010–2015",
        "Une commission officielle annonce sa mission, est créée formellement, puis un premier rapport cité par le blog paraît.",
        "Ce dossier examine comment évaluer une institution publique à partir d’annonces, de résolutions, de missions déclarées et de documents publiés. Il exige également de distinguer le contenu d’une source des opinions de ses auteurs.",
        "Le blog RIO54 rassemble des articles de 2011 et 2015 sur la Commission d’étude des phénomènes aérospatiaux (CEFAE). Les critiques éditoriales du blog sont présentées comme telles, et non comme des faits démontrés par le jeu.",
        "Sur la table se trouvent des coupures de presse, une résolution mentionnée dans un article et une page présentant la mission institutionnelle. Des années plus tard, le blog revient sur le sujet en commentant la parution d’un rapport. Votre travail consiste à distinguer chronologie, document et appréciation.",
        "Quelle lecture de la chronologie est la plus rigoureuse ?", "Que devrait dire le rapport final de l’enquêteur ?",
        "Une bonne enquête sépare les faits administratifs, les publications et les opinions.",
        "La chronologie du blog distingue une annonce en 2010, la création officielle de la CEFAE en 2011 et la publication d’un rapport en 2015. Les objections concernant la forme du rapport sont des critiques formulées par les auteurs du blog. Un audit complet nécessiterait de consulter la résolution et le rapport originaux de l’armée de l’air."
      ],
      clues: [
        ["L’annonce initiale", "CHRONOLOGIE", "La nouvelle paraît en décembre 2010.", "Dans l’article « Los misterios de la comisión oficial sobre ovnis », RIO54 situe la première annonce télévisée de la future commission au 22 décembre 2010, lors d’un entretien avec le commodore Guillermo Daniel Tealdi.", "« Los misterios de la comisión oficial sobre ovnis », RIO54, 22/12/2011.", "Consigner cette date comme l’annonce d’une commission à créer, et non comme sa date officielle de création.", "Confondre la première annonce télévisée avec la résolution administrative.", "Bien. Une annonce dans les médias et l’acte administratif qui officialise un organisme sont deux choses différentes.", "L’annonce a eu lieu avant la résolution officielle mentionnée dans l’article lui-même."],
        ["Nom et mission", "DOCUMENT INSTITUTIONNEL", "CEFAE : étude des phénomènes aérospatiaux.", "L’article de juin 2011 indique que l’organisme a été nommé Commission d’étude des phénomènes aérospatiaux (CEFAE). Il reproduit une mission visant à documenter, analyser et étudier de manière méthodique et rigoureuse les phénomènes non identifiés par les systèmes de contrôle conventionnels dans l’espace aérien relevant de la juridiction nationale.", "« La comisión de la Fuerza Aérea ya está en la web », RIO54, 19/06/2011 ; l’article retranscrit le texte officiel de présentation.", "Distinguer le nom officiel et la mission déclarée de toute conclusion sur les résultats de ses enquêtes.", "Lire la mission institutionnelle comme la preuve qu’un cas extraordinaire a été confirmé.", "Exact. Une mission définit ce qu’un service dit devoir faire ; elle ne préjuge pas de ses résultats.", "Le mandat d’étudier des phénomènes non identifiés ne signifie pas que l’institution ait confirmé une hypothèse."],
        ["La résolution mentionnée", "ACTE ADMINISTRATIF RAPPORTÉ", "La formalisation décrite par le blog.", "L’article de décembre 2011 affirme que la résolution officialisant la CEFAE a été signée le 5 mai 2011. Le même article reproduit l’objectif général consistant à conseiller l’armée de l’air sur les questions liées aux phénomènes aérospatiaux non identifiés.", "« Los misterios de la comisión oficial sobre ovnis », RIO54, 22/12/2011.", "Noter la date et préciser que l’information provient du récit documentaire du blog.", "Prétendre connaître le texte intégral de la résolution sans avoir consulté le document original.", "Bonne méthode : vous avez conservé l’information et la provenance de l’affirmation.", "L’article résume et cite des passages de la résolution ; cela ne revient pas à consulter ici le document administratif complet."],
        ["Le rapport de 2015", "PUBLICATION ET CRITIQUE", "Le blog commente le premier rapport publié.", "Dans un article du 18 décembre 2015, RIO54 affirme que le premier rapport de la CEFAE a été publié sur le site de l’armée de l’air au début du mois, quatre ans et demi après sa création. Les auteurs critiquent également le format du PDF et l’absence de signatures qu’ils disent y avoir constatée.", "« Luego de cuatro años y medio, la comisión oficial sobre ovnis lanzó su primer informe », RIO54, 18/12/2015. Il s’agit de la description et de l’évaluation des auteurs du blog.", "Séparer le fait rapporté par le blog — la publication du rapport — des critiques formulées par les auteurs sur sa présentation.", "Conclure que le rapport prouve une dissimulation ou qu’aucun travail n’a été effectué.", "Exactement. Une critique documentaire peut être pertinente sans prouver à elle seule une intention de dissimulation.", "Le retard et les objections formelles peuvent justifier des questions, mais ils ne prouvent pas automatiquement une dissimulation."]
      ],
      boardQ: "Quelle lecture de la chronologie est la plus rigoureuse ?",
      board: [
        ["Une annonce a eu lieu en 2010, la commission a été officialisée en 2011 et le blog a signalé la publication d’un premier rapport en 2015 ; les critiques de ce rapport doivent être attribuées à leurs auteurs.", "Exact : vous avez séparé la chronologie de l’appréciation éditoriale."],
        ["L’existence de la CEFAE prouve que l’armée de l’air a confirmé des visites extraterrestres.", "La mission institutionnelle parle d’étudier des phénomènes non identifiés, et non de confirmer la présence d’extraterrestres."],
        ["La parution tardive d’un rapport prouve nécessairement que toute la commission était fictive.", "La source décrit une commission, sa création officielle et un rapport ; le retard ne prouve pas son inexistence."]
      ],
      verdictQ: "Que devrait dire le rapport final de l’enquêteur ?",
      verdict: [
        ["Selon la chronologie rapportée par RIO54, la CEFAE a été annoncée puis officialisée ; le blog a signalé un premier rapport en 2015 et critiqué sa présentation. Ces critiques ne prouvent pas, à elles seules, une dissimulation.", ""],
        ["La CEFAE a découvert des vaisseaux extraterrestres et l’a confirmé en secret.", "Aucun élément des documents de ce dossier ne confirme cette affirmation."],
        ["La commission n’a jamais existé et toutes les annonces étaient fausses.", "La chronologie présentée dans les archives contredit cette conclusion."]
      ]
    },
    c3: {
      top: [
        "Témoignages et prudence", "La nuit de Monte Grande", "Monte Grande, province de Buenos Aires · 26 septembre 2011",
        "Une explosion, une victime et des récits faisant état d’une lumière dans le ciel suscitent des hypothèses à examiner avec prudence.",
        "Ce dossier porte sur un événement tragique mentionné dans les articles du blog. Il sera abordé avec respect : sans reconstituer les dommages, sans transformer la douleur en spectacle et sans présenter comme un fait une hypothèse sur l’origine de l’explosion.",
        "La publication de RIO54 signale un décès. Le jeu ne représente pas graphiquement l’événement et ne prétend pas avoir établi la cause de l’explosion.",
        "Les archives contiennent un bref article : une explosion a détruit des logements et un commerce. Des riverains ont associé une lumière intense au moment de la déflagration. L’affaire a suscité de nombreuses discussions et des explications très différentes ont circulé. La première règle est de ne pas confondre proximité temporelle et causalité démontrée.",
        "Comment faut-il relier le témoignage concernant la lumière à l’explosion ?", "Quelle conclusion est responsable au vu des éléments disponibles ?",
        "Parfois, la conclusion la plus solide consiste à reconnaître ce qui n’a pas pu être établi.",
        "L’article de RIO54 mentionne une explosion aux conséquences humaines graves et rapporte que des riverains ont parlé d’une lumière intense. Il énumère également plusieurs hypothèses qui ont circulé. Les informations consultées ne permettent pas de déterminer la cause ; par respect pour les personnes touchées, le jeu évite de transformer une tragédie en spectacle ufologique."
      ],
      clues: [
        ["L’événement", "FAIT RAPPORTÉ", "Date et conséquences humaines.", "L’article de RIO54 situe l’explosion aux premières heures du lundi 26 septembre 2011. Il indique que deux maisons et un commerce ont été entièrement détruits et qu’une personne a perdu la vie.", "« OVNIS: exitosa reunión RIO54 de octubre », RIO54, 09/10/2011.", "Consigner les faits et leurs conséquences humaines sans spéculer sur la cause.", "Traiter la tragédie comme une scène de fiction ou comme une preuve d’origine non humaine.", "Merci de garder l’attention sur l’événement et les personnes touchées. L’enquête doit commencer par là.", "Cette tragédie mérite le respect. Sa gravité ne détermine pas, à elle seule, l’origine de l’explosion."],
        ["Ce qu’ont dit les riverains", "TÉMOIGNAGE RAPPORTÉ", "Une lumière intense aurait été aperçue.", "L’article indique que des riverains ont affirmé qu’une lumière intense venait du ciel au moment de l’explosion. La publication consultée ne présente pas de déclarations complètes, d’enregistrements instrumentaux ni d’expertises permettant d’évaluer séparément chaque récit.", "L’article de RIO54 résume les témoignages des riverains.", "Consigner la lumière comme un récit attribué aux riverains et rechercher les déclarations originales avant de l’évaluer.", "Affirmer que la lumière a causé l’explosion parce qu’elle a été signalée au même moment.", "Bien. Une coïncidence temporelle est une piste à examiner, pas une preuve de causalité.", "La simultanéité perçue ne suffit pas à prouver que la lumière a provoqué l’explosion."],
        ["Les hypothèses qui ont circulé", "HYPOTHÈSES PUBLIQUES", "Météorite, débris spatiaux ou vaisseau.", "L’article énumère des hypothèses qui ont rapidement circulé : chute d’une météorite, débris spatiaux ou même vaisseau d’origine non terrestre. Cette liste documente le débat public ; elle ne confirme aucune de ces options.", "« OVNIS: exitosa reunión RIO54 de octubre », RIO54, 09/10/2011.", "Classer ces options comme des hypothèses mentionnées, qui nécessitent encore des preuves indépendantes.", "Choisir l’hypothèse la plus spectaculaire parce qu’elle s’est rapidement diffusée.", "Exact. La présence d’une hypothèse dans un article ne constitue pas une conclusion d’expertise.", "La vitesse de diffusion ne renforce pas une hypothèse et ne remplace pas les preuves matérielles."],
        ["Ce qui manque pour résoudre l’affaire", "LIMITES DES ARCHIVES", "L’article ne fournit pas d’expertise concluante.", "Dans les passages consultés, le blog résume l’événement, rapporte le récit des riverains et mentionne des hypothèses. Ces éléments ne permettent pas à eux seuls d’identifier l’origine de l’explosion. Pour aller plus loin, il faudrait notamment des expertises, des dossiers officiels, des relevés techniques et des témoignages originaux pouvant être recoupés.", "Évaluation de la portée des articles de RIO54 consultés ; elle n’affirme pas qu’aucun autre document n’existe.", "Conclure que les informations de ce dossier ne suffisent pas à attribuer une cause.", "Combler le manque de données par une certitude sans fondement.", "C’est une conclusion valable : reconnaître une limite est aussi un résultat de recherche.", "Lorsque des documents manquent, inventer une explication ne résout pas l’affaire."]
      ],
      boardQ: "Comment faut-il relier le témoignage concernant la lumière à l’explosion ?",
      board: [
        ["Le témoignage est pertinent et mérite d’être vérifié, mais la coïncidence temporelle ne prouve pas que la lumière ait causé l’explosion.", "Exact. Vous distinguez une piste d’un lien de causalité établi."],
        ["La lumière était nécessairement un vaisseau qui a provoqué l’explosion.", "L’article ne fournit aucune preuve permettant d’identifier la lumière ou de la relier causalement à l’explosion."],
        ["Puisqu’il y a eu une explosion, les riverains n’ont pas pu voir de lumière.", "L’existence d’un événement tragique n’invalide pas automatiquement les témoignages ; ils doivent être examinés."]
      ],
      verdictQ: "Quelle conclusion est responsable au vu des éléments disponibles ?",
      verdict: [
        ["L’article rapporte une explosion tragique et des témoignages faisant état d’une lumière, mais les publications consultées ne suffisent pas à déterminer la cause de l’événement.", ""],
        ["Il est prouvé qu’un vaisseau extraterrestre s’est écrasé à Monte Grande.", "Le dossier ne contient ni expertise ni preuve permettant d’affirmer cela."],
        ["Il est prouvé que tous les témoignages ont été inventés.", "L’absence de corroboration suffisante ne prouve pas que les témoins aient menti."]
      ]
    },
    c4: {
      top: [
        "Archives antarctiques", "Échos du continent blanc", "Antarctique argentine · 1965 / mémoire documentaire de 2016",
        "Un communiqué naval de 1965 et une réunion de RIO54 en 2016 permettent de reconstituer la mémoire des enquêtes officielles.",
        "Ce dernier dossier suit les traces d’un épisode antarctique cité dans les archives de RIO54. L’histoire réapparaît des décennies plus tard dans une coupure de presse et lors d’une réunion commémorative. Il faut distinguer l’annonce historique, les souvenirs et les interprétations ultérieures.",
        "Le contenu du jeu repose sur l’article de RIO54 du 26 juillet 2016. Pour recouper les détails techniques et les témoignages complets, il faut consulter les publications et documents originaux qui y sont mentionnés.",
        "Le froid conserve les documents, mais le temps transforme aussi notre manière de nous en souvenir. Lors d’une réunion en juillet 2016, RIO54 est revenu sur un communiqué naval publié 51 ans plus tôt et sur l’histoire d’une commission d’étude. Votre tâche consiste à reconstituer ce qu’affirme cette mémoire documentaire.",
        "Quelle reconstitution respecte le mieux l’écart entre les documents ?", "Quelle conclusion est la mieux étayée ?",
        "La mémoire historique ouvre des questions ; les documents originaux permettent de les préciser.",
        "L’article de RIO54 de juillet 2016 rappelle un communiqué naval de 1965, reproduit une coupure de presse et mentionne la COPEFO. Il comprend également des souvenirs de participants et des références bibliographiques. C’est un point de départ pour rechercher dans les archives, et non une preuve suffisante de la nature des phénomènes observés."
      ],
      clues: [
        ["La coupure de 1965", "DOCUMENT DE PRESSE RAPPORTÉ", "Article du journal Crónica, 7 juillet.", "L’article de RIO54 de juillet 2016 montre une coupure du journal Crónica datée du 7 juillet 1965. Le texte la relie au premier communiqué officiel de la marine sur des observations d’OVNI en Antarctique argentine.", "« En RIO54 se recordó a la comisión OVNI de la Armada Argentina », RIO54, 26/07/2016.", "Consigner la coupure comme une référence de presse reproduite dans un article ultérieur.", "Affirmer que la coupure prouve à elle seule la nature du phénomène observé.", "Bien. Vous avez identifié le support documentaire et l’écart temporel entre l’événement et l’article qui le rappelle.", "Une coupure peut établir qu’une communication ou un article a existé ; elle ne détermine pas automatiquement l’origine du phénomène."],
        ["La commission COPEFO", "CONTEXTE INSTITUTIONNEL", "Une commission navale d’étude dans les années soixante.", "L’article mentionne la Commission permanente d’étude du phénomène OVNI (COPEFO), dirigée par le capitaine Omar Roque Pagani, et décrit son travail comme une enquête officielle menée par la marine pendant les années 1960.", "Article RIO54 du 26/07/2016, qui résume des références du livre « Los ovnis de la Antártida ».", "Noter l’existence d’une commission mentionnée par la source et rechercher ses documents originaux.", "Supposer que toute commission officielle est nécessairement parvenue à une conclusion extraterrestre.", "Exact. Le contexte institutionnel enrichit l’histoire de l’enquête ; il ne constitue pas un verdict sur l’origine.", "L’existence d’un organisme d’étude ne signifie pas qu’il ait confirmé une hypothèse précise."],
        ["Le souvenir de 2016", "MÉMOIRE ET RÉTROSPECTIVE", "RIO54 revient sur l’épisode 51 ans plus tard.", "Le 7 juillet 2016, pour le 51e anniversaire de la communication de 1965, RIO54 a consacré une partie de sa réunion à évoquer le sujet. L’article mentionne le livre « Los ovnis de la Antártida » de Rubén Morales et le chapitre consacré aux enquêtes antarctiques.", "« En RIO54 se recordó a la comisión OVNI de la Armada Argentina », 26/07/2016.", "Séparer le souvenir de 2016 du document et des événements de 1965 qu’il cherche à rappeler.", "Traiter les souvenirs de 2016 comme s’il s’agissait de témoignages contemporains de chaque observation.", "Bien. La mémoire ultérieure guide la recherche, mais ne remplace pas les sources contemporaines.", "Les souvenirs ultérieurs sont précieux, mais ils doivent être distingués des archives produites à l’époque."],
        ["Les voix de l’enquête", "TÉMOIGNAGE ET CONTEXTE", "Expériences rapportées et travail de terrain.", "L’article rapporte les souvenirs de Mario Coen sur des travaux de terrain menés en 1964 et 1965 dans la région de Dique Los Molinos, à Córdoba, où, selon son récit, près de vingt cas avaient été signalés. Il rappelle également des conversations avec d’anciens enquêteurs de la marine.", "L’article reproduit des souvenirs partagés lors d’une réunion de RIO54 en juillet 2016.", "Identifier ces passages comme des souvenirs attribués à des participants, et non comme des rapports techniques complets.", "Transformer des anecdotes remémorées en preuve définitive d’une origine non humaine.", "Exactement. Un témoignage rétrospectif peut constituer une piste, mais il doit être confronté aux archives contemporaines.", "Une anecdote mérite d’être écoutée et examinée, mais elle ne suffit pas à elle seule à établir une origine extraordinaire."]
      ],
      boardQ: "Quelle reconstitution respecte le mieux l’écart entre les documents ?",
      board: [
        ["Une coupure de 1965 a été reprise en 2016 ; la réunion a également évoqué la COPEFO et des témoignages historiques, à confronter à leurs sources originales.", "Exact : vous avez distingué le document, la mémoire institutionnelle et les souvenirs personnels."],
        ["La réunion de 2016 prouve que toutes les observations antarctiques concernaient des vaisseaux extraterrestres.", "Le souvenir d’un cas ne détermine pas la nature de toutes les observations."],
        ["Puisque la coupure a été montrée en 2016, elle ne peut fournir aucune information sur 1965.", "Une reproduction ultérieure peut orienter la recherche du document, même s’il est préférable de retrouver l’original."]
      ],
      verdictQ: "Quelle conclusion est la mieux étayée ?",
      verdict: [
        ["RIO54 rappelle un communiqué naval de 1965 et une histoire d’enquêtes officielles ; le contenu résumé documente cette mémoire, mais ne prouve pas à lui seul une origine extraterrestre.", ""],
        ["La marine a officiellement confirmé que les observations étaient des vaisseaux extraterrestres.", "L’article n’affirme pas que le communiqué ait confirmé une origine extraterrestre."],
        ["Il n’y a jamais eu d’enquête officielle ni de document sur le sujet.", "La source mentionne le communiqué, la coupure de presse et la commission COPEFO."]
      ]
    }
  },
  de: {
    c1: {
      top: [
        "Historische Rekonstruktion", "Das Licht im September", "Buenos Aires und das Umland · 17. September 1985",
        "Ein Flugobjekt wird von zahlreichen Menschen beobachtet. Jahre später hält das RIO54-Archiv eine konkrete Erklärung fest.",
        "Dieser Fall beginnt mit einer weithin beobachteten Erscheinung über Buenos Aires und dem Umland. Deine Aufgabe ist es, zu rekonstruieren, was veröffentlicht wurde, welche spätere Erklärung das Archiv wiedergibt und wie weit die verfügbaren Informationen tragen.",
        "Dokumentarischer Ausgangspunkt: Ein am 27. Dezember 2011 veröffentlichter RIO54-Beitrag schreibt Carlos Demarías Nachforschungen die Aufklärung des Vorfalls als französischen Höhenforschungsballon zu.",
        "Die Stadt erinnert sich an ein ungewöhnliches Licht. In einer Archivmappe liegen Zeitungsausschnitte, Daten und ein Beitrag, der den Fall erneut aufgreift. Du wirst kein magisches Foto finden, das alles erklärt: Du musst die Informationskette rekonstruieren.",
        "Welche Beziehung beschreibt die gesamte Akte am besten?", "Welche Schlussfolgerung sollte auf Grundlage der gesammelten Informationen vorgelegt werden?",
        "Die Akte findet in der konsultierten Quelle eine dokumentierte Erklärung.",
        "Der RIO54-Beitrag schreibt Carlos Demarías Nachforschungen die Identifizierung des Objekts als französischen Höhenforschungsballon zu. Diese Schlussfolgerung beschränkt sich auf diesen Vorfall und auf die Angaben des Beitrags: Sie klärt keine anderen Fälle und entwertet keine weiteren Zeugenaussagen."
      ],
      clues: [
        ["Das Datum des Vorfalls", "CHRONOLOGIE", "Ein konkreter zeitlicher Bezug.", "Der RIO54-Beitrag datiert den Vorfall auf den 17. September 1985 und gibt an, dass das Objekt von der Stadt Buenos Aires und ihrem Umland aus beobachtet wurde.", "Beitrag „Los blogs de Carlos Demaría“, RIO54, 27.12.2011.", "Halte Datum, Gebiet und Reichweite genau so fest, wie sie in der Veröffentlichung erscheinen.", "Die Zahl der Beobachter als automatischen Beweis für einen außergewöhnlichen Ursprung zu behandeln.", "Richtig. Du hast die überprüfbare Angabe aus dieser Quelle festgehalten, ohne mehr daraus abzuleiten, als dort steht.", "Viele Beobachter machen den Fall untersuchenswert, bestimmen aber nicht allein, was das Objekt war."],
        ["Die Beobachtungsberichte", "WIEDERGEGEBENE ZEUGENBERICHTE", "Was eine kollektive Zeugenaussage beitragen kann.", "Die Veröffentlichung spricht von zahlreichen Zeugen. Das Archiv gibt hier nicht jeden einzelnen Bericht wieder und enthält in diesem Beitrag keine Interviewdatenbank, mit der sich Beschreibungen, Blickwinkel oder Zeitangaben vergleichen ließen.", "Der RIO54-Beitrag fasst den Fall zusammen; er gibt nicht alle ursprünglichen Zeugenaussagen wieder.", "Unterscheide den allgemeinen Hinweis auf Zeugen von den vollständigen Aussagen, die nicht enthalten sind.", "Zu behaupten, alle hätten genau dasselbe gesehen, obwohl der Text das nicht ausführt.", "Gut. Du hast die Existenz von Berichten nicht mit dem Zugang zu jeder ursprünglichen Aussage verwechselt.", "Das Archiv erlaubt nicht die Behauptung, alle hätten dasselbe Objekt mit identischen Einzelheiten beschrieben."],
        ["Die spätere Untersuchung", "DOKUMENTARISCHE ZUSCHREIBUNG", "Die von RIO54 wiedergegebene Erklärung.", "RIO54 erinnert an Carlos Demarías Beitrag zur Aufklärung des Falls und erklärt, dass sich das Objekt nach entsprechenden Nachforschungen als Höhenforschungsballon französischer Herkunft herausstellte.", "Beitrag „Los blogs de Carlos Demaría“, RIO54, 27.12.2011.", "Vermerke, dass dies die Erklärung ist, die der Beitrag Demarías Nachforschungen zuschreibt.", "Dem Beitrag technische Einzelheiten zuzuschreiben, die darin nicht vorkommen.", "Genau. Du hast die Zuschreibung zur Quelle beibehalten und keine Einzelheiten über den Ballon erfunden.", "Der Text nennt eine allgemeine Identifizierung, beschreibt in diesem Beitrag aber nicht alle technischen Einzelheiten der Untersuchung."],
        ["Die Grenze des Begriffs UFO", "KRITERIUM", "Unidentifiziert bedeutet nicht außerirdisch.", "In einer Untersuchung bezeichnet „unidentifiziertes Flugobjekt“ eine Beobachtung, deren Identität zu diesem Zeitpunkt unbekannt ist. Der Begriff klassifiziert weder die Herkunft noch beweist er nichtmenschliche Technologie.", "Methodisches Kriterium des Spielerlebnisses; kein wörtliches Zitat aus dem Blog.", "Trenne die anfängliche Beschreibung des Objekts von der späteren Erklärung, die die Quelle wiedergibt.", "Die Bezeichnung UFO als Synonym für ein außerirdisches Raumschiff zu verwenden.", "Das ist der zentrale Schritt dieser Akte: Eine Bezeichnung für Unsicherheit ist keine Schlussfolgerung über die Herkunft.", "Das Kürzel bedeutet, dass etwas zu diesem Zeitpunkt nicht identifiziert wurde; es beweist keine außerirdische Herkunft."]
      ],
      boardQ: "Welche Beziehung beschreibt die gesamte Akte am besten?",
      board: [
        ["Die ersten Berichte führten zur Untersuchung; die spätere Veröffentlichung nennt eine Identifizierung als französischen Höhenforschungsballon.", "Die Zusammenfassung respektiert die Reihenfolge und die Zuschreibung an die Quelle."],
        ["Die große Zahl der Zeugen beweist, dass es sich um ein außerirdisches Raumschiff handelte.", "Die Zahl der Zeugen bestimmt nicht die Beschaffenheit des Objekts."],
        ["Da es später eine Erklärung gab, müssen die ursprünglichen Zeugenaussagen erfunden gewesen sein.", "Eine spätere Identifizierung beweist nicht, dass die Beobachter gelogen haben."]
      ],
      verdictQ: "Welche Schlussfolgerung sollte auf Grundlage der gesammelten Informationen vorgelegt werden?",
      verdict: [
        ["Laut der von RIO54 veröffentlichten Rekonstruktion wurde das Objekt später als Höhenforschungsballon französischer Herkunft identifiziert.", ""],
        ["Der Vorfall beweist, dass ein außerirdisches Raumschiff über Buenos Aires flog.", "Die Akte enthält keine Belege für diese Behauptung."],
        ["Es gab überhaupt keine Beobachtung: Der gesamte Fall wurde erfunden.", "Die Quelle berichtet sehr wohl von zahlreichen Beobachtungen; verändert hat sich die Erklärung des Objekts."]
      ]
    },
    c2: {
      top: [
        "Institutionen und Dokumente", "Die Kommission unter der Lupe", "CEFAE · 2010–2015",
        "Eine offizielle Kommission kündigt ihre Aufgabe an, wird formal eingerichtet und später erscheint ein vom Blog erwähnter erster Bericht.",
        "Diese Akte untersucht, wie eine öffentliche Institution anhand von Ankündigungen, Beschlüssen, erklärten Aufgaben und veröffentlichten Dokumenten bewertet werden kann. Außerdem muss zwischen dem Inhalt einer Quelle und den Meinungen ihrer Autoren unterschieden werden.",
        "Der RIO54-Blog versammelt Beiträge aus den Jahren 2011 und 2015 über die Kommission zur Untersuchung aerospacebezogener Phänomene (CEFAE). Die redaktionelle Kritik des Blogs wird als solche dargestellt und nicht als vom Spiel bewiesene Tatsache.",
        "Auf dem Tisch liegen Zeitungsausschnitte, ein in einem Bericht erwähnter Beschluss und eine Seite mit der institutionellen Aufgabe. Jahre später greift der Blog das Thema auf, als er über das Erscheinen eines Berichts schreibt. Deine Aufgabe ist es, Chronologie, Dokument und Bewertung zu trennen.",
        "Welche Lesart der Chronologie ist am sorgfältigsten?", "Was sollte im Abschlussbericht der untersuchenden Person stehen?",
        "Gute Recherche trennt Verwaltungsvorgänge, Veröffentlichungen und Meinungen.",
        "Die Chronologie des Blogs unterscheidet eine Ankündigung im Jahr 2010, die formelle Einrichtung der CEFAE im Jahr 2011 und die Veröffentlichung eines Berichts im Jahr 2015. Einwände gegen die Form des Berichts sind Kritik der Blogautoren. Für eine vollständige Prüfung müssten der ursprüngliche Beschluss und der Originalbericht der Luftwaffe eingesehen werden."
      ],
      clues: [
        ["Die erste Ankündigung", "CHRONOLOGIE", "Die Nachricht erscheint im Dezember 2010.", "Im Artikel „Los misterios de la comisión oficial sobre ovnis“ datiert RIO54 die erste Fernsehankündigung der geplanten Kommission auf den 22. Dezember 2010. Sie erfolgte in einem Interview mit Commodore Guillermo Daniel Tealdi.", "„Los misterios de la comisión oficial sobre ovnis“, RIO54, 22.12.2011.", "Halte das Datum als Ankündigung einer erst zu gründenden Kommission fest, nicht als ihr formelles Gründungsdatum.", "Die erste Fernsehankündigung mit dem Verwaltungsbeschluss zu verwechseln.", "Gut. Eine Nachrichtenankündigung und der Verwaltungsakt, der eine Einrichtung formal gründet, sind unterschiedliche Dinge.", "Die Ankündigung erfolgte vor dem formellen Beschluss, den der Artikel selbst erwähnt."],
        ["Name und Aufgabe", "INSTITUTIONELLES DOKUMENT", "CEFAE: Untersuchung aerospacebezogener Phänomene.", "Der Beitrag vom Juni 2011 berichtet, dass die Dienststelle Kommission zur Untersuchung aerospacebezogener Phänomene (CEFAE) genannt wurde. Er gibt eine Aufgabe wieder, die darauf ausgerichtet war, Phänomene im nationalen Luftraum, die von herkömmlichen Kontrollsystemen nicht identifiziert werden, geordnet und zuverlässig zu dokumentieren, zu analysieren und zu untersuchen.", "„La comisión de la Fuerza Aérea ya está en la web“, RIO54, 19.06.2011; der Artikel zitiert den offiziellen Vorstellungstext.", "Unterscheide den offiziellen Namen und die erklärte Aufgabe von jeder Schlussfolgerung über die Untersuchungsergebnisse.", "Die institutionelle Aufgabe als Beweis dafür zu lesen, dass ein außergewöhnlicher Fall bestätigt wurde.", "Richtig. Eine Aufgabenbeschreibung legt fest, was eine Dienststelle tun soll; sie nimmt ihre Ergebnisse nicht vorweg.", "Der Auftrag, unidentifizierte Phänomene zu untersuchen, bedeutet nicht, dass die Institution eine Hypothese bestätigt hat."],
        ["Der erwähnte Beschluss", "ERWÄHNTER VERWALTUNGSAKT", "Die vom Blog beschriebene formelle Einrichtung.", "Der Artikel vom Dezember 2011 behauptet, dass der Beschluss zur offiziellen Einrichtung der CEFAE am 5. Mai 2011 unterzeichnet wurde. Derselbe Beitrag gibt den allgemeinen Zweck wieder, die Luftwaffe in Fragen zu nicht identifizierten aerospacebezogenen Phänomenen zu beraten.", "„Los misterios de la comisión oficial sobre ovnis“, RIO54, 22.12.2011.", "Notiere das Datum und halte fest, dass die Information aus dem dokumentarischen Bericht des Blogs stammt.", "Zu behaupten, den vollständigen Wortlaut des Beschlusses zu kennen, ohne das Originaldokument eingesehen zu haben.", "Gute Praxis: Du hast sowohl die Angabe als auch die Herkunft der Behauptung bewahrt.", "Der Beitrag fasst Teile des Beschlusses zusammen und zitiert sie; das ist nicht dasselbe wie die vollständige Verwaltungsakte hier einzusehen."],
        ["Der Bericht von 2015", "VERÖFFENTLICHUNG UND KRITIK", "Der Blog kommentiert den ersten veröffentlichten Bericht.", "In einem Beitrag vom 18. Dezember 2015 erklärt RIO54, dass der erste CEFAE-Bericht Anfang desselben Monats auf der Website der Luftwaffe veröffentlicht worden sei, viereinhalb Jahre nach der Gründung. Die Autoren kritisieren außerdem das PDF-Format und die ihrer Beschreibung nach fehlenden Unterschriften.", "„Luego de cuatro años y medio, la comisión oficial sobre ovnis lanzó su primer informe“, RIO54, 18.12.2015. Dies ist die Beschreibung und Bewertung der Blogautoren.", "Trenne das vom Blog berichtete Ereignis – die Veröffentlichung des Berichts – von der Kritik der Autoren an seiner Präsentation.", "Zu folgern, der Bericht beweise eine Vertuschung oder es habe überhaupt keine Arbeit gegeben.", "Genau. Dokumentenkritik kann relevant sein, ohne für sich allein eine Verschleierungsabsicht zu beweisen.", "Die Verzögerung und formale Einwände können Fragen rechtfertigen, beweisen aber nicht automatisch eine Vertuschung."]
      ],
      boardQ: "Welche Lesart der Chronologie ist am sorgfältigsten?",
      board: [
        ["2010 gab es eine Ankündigung, 2011 die formelle Einrichtung, und 2015 berichtete der Blog über die Veröffentlichung eines ersten Berichts; Kritik an diesem Bericht ist seinen Autoren zuzuschreiben.", "Richtig: Du hast Chronologie und redaktionelle Bewertung getrennt."],
        ["Die Existenz der CEFAE beweist, dass die Luftwaffe außerirdische Besuche bestätigt hat.", "Die institutionelle Aufgabe spricht von der Untersuchung nicht identifizierter Phänomene, nicht von der Bestätigung Außerirdischer."],
        ["Das späte Erscheinen eines Berichts beweist zwangsläufig, dass die gesamte Kommission erfunden war.", "Die Quelle beschreibt eine Kommission, ihre formelle Einrichtung und einen Bericht; die Verzögerung beweist nicht ihre Nichtexistenz."]
      ],
      verdictQ: "Was sollte im Abschlussbericht der untersuchenden Person stehen?",
      verdict: [
        ["Laut der von RIO54 wiedergegebenen Chronologie wurde die CEFAE angekündigt und formell eingerichtet; der Blog berichtete 2015 über einen ersten Bericht und kritisierte dessen Präsentation. Diese Kritik beweist für sich allein keine Vertuschung.", ""],
        ["Die CEFAE fand außerirdische Raumschiffe und bestätigte dies heimlich.", "Die Dokumente in dieser Akte enthalten keinen Beleg für diese Behauptung."],
        ["Die Kommission hat nie existiert und alle Ankündigungen waren falsch.", "Die Chronologie im Archiv widerspricht dieser Schlussfolgerung."]
      ]
    },
    c3: {
      top: [
        "Zeugenaussagen und Vorsicht", "Die Nacht von Monte Grande", "Monte Grande, Provinz Buenos Aires · 26. September 2011",
        "Eine Explosion, ein Todesopfer und Berichte über ein Licht am Himmel führen zu Hypothesen, die sorgfältig geprüft werden müssen.",
        "Diese Akte behandelt ein tragisches Ereignis, das der Blog in seinen Berichten erwähnt. Die Behandlung erfolgt respektvoll: ohne den Schaden nachzustellen, ohne Leid zum Spektakel zu machen und ohne eine Hypothese zur Ursache der Explosion als Tatsache darzustellen.",
        "Die RIO54-Veröffentlichung berichtet von einem Todesopfer. Das Spiel zeigt das Ereignis nicht grafisch und behauptet nicht, die Ursache der Explosion ermittelt zu haben.",
        "Im Archiv befindet sich eine kurze Nachricht: Eine Explosion zerstörte Wohnhäuser und ein Geschäft. Anwohner brachten ein helles Licht mit dem Zeitpunkt der Detonation in Verbindung. Der Fall wurde diskutiert, und sehr unterschiedliche Erklärungen verbreiteten sich. Die erste Regel lautet, zeitliche Nähe nicht mit nachgewiesener Kausalität zu verwechseln.",
        "Wie ist der Bericht über das Licht mit der Explosion in Beziehung zu setzen?", "Welche Schlussfolgerung ist angesichts des verfügbaren Materials verantwortbar?",
        "Manchmal besteht die stärkste Schlussfolgerung darin anzuerkennen, was nicht festgestellt werden konnte.",
        "Der RIO54-Bericht erwähnt eine Explosion mit schwerwiegenden menschlichen Folgen und gibt wieder, dass Anwohner von einem hellen Licht berichteten. Er listet auch kursierende Hypothesen auf. Die konsultierten Informationen erlauben keine Bestimmung der Ursache; aus Respekt vor den Betroffenen vermeidet das Spiel, eine Tragödie in ein UFO-Spektakel zu verwandeln."
      ],
      clues: [
        ["Das Ereignis", "BERICHTETES EREIGNIS", "Datum und menschliche Folgen.", "Der RIO54-Bericht datiert die Explosion auf die frühen Morgenstunden des Montags, 26. September 2011. Er informiert, dass zwei Häuser und ein Geschäft vollständig zerstört wurden und ein Mensch ums Leben kam.", "„OVNIS: exitosa reunión RIO54 de octubre“, RIO54, 09.10.2011.", "Halte das Ereignis und seine menschlichen Folgen fest, ohne über die Ursache zu spekulieren.", "Die Tragödie wie eine fiktive Szene oder als Beweis für einen nichtmenschlichen Ursprung zu behandeln.", "Danke, dass du den Blick auf das Ereignis und die betroffenen Menschen richtest. Dort muss die Untersuchung beginnen.", "Die Tragödie verdient Respekt. Ihre Schwere bestimmt nicht von selbst die Ursache der Explosion."],
        ["Was Anwohner berichteten", "WIEDERGEGEBENE ZEUGENAUSSAGE", "Es soll ein helles Licht gesehen worden sein.", "Der Bericht sagt, Anwohner hätten erklärt, dass zum Zeitpunkt der Explosion ein helles Licht vom Himmel gekommen sei. Der konsultierte Beitrag veröffentlicht hier keine vollständigen Aussagen, instrumentellen Aufzeichnungen oder Gutachten, anhand derer sich jeder Bericht einzeln bewerten ließe.", "Der RIO54-Bericht fasst die Aussagen der Anwohner zusammen.", "Erfasse das Licht als den Anwohnern zugeschriebenen Bericht und suche vor der Bewertung nach Originalaussagen.", "Zu behaupten, das Licht habe die Explosion verursacht, weil es zum selben Zeitpunkt gemeldet wurde.", "Gut. Eine zeitliche Übereinstimmung ist ein Ansatzpunkt für Nachforschungen, kein Kausalitätsbeweis.", "Die wahrgenommene Gleichzeitigkeit reicht nicht aus, um zu beweisen, dass das Licht die Explosion verursacht hat."],
        ["Die kursierenden Hypothesen", "ÖFFENTLICHE HYPOTHESEN", "Meteorit, Weltraumschrott oder Raumschiff.", "Der Beitrag listet Hypothesen auf, die sich schnell verbreiteten: ein Meteoriteneinschlag, Weltraumschrott oder sogar ein Flugkörper nichtirdischen Ursprungs. Die Liste dokumentiert die öffentliche Diskussion, bestätigt aber keine dieser Möglichkeiten.", "„OVNIS: exitosa reunión RIO54 de octubre“, RIO54, 09.10.2011.", "Ordne diese Möglichkeiten als erwähnte Hypothesen ein, die unabhängige Belege benötigen.", "Die spektakulärste Hypothese zu wählen, weil sie sich schnell verbreitet hat.", "Richtig. Dass eine Hypothese in einem Bericht auftaucht, ist kein Sachverständigengutachten.", "Schnelle Verbreitung verbessert eine Hypothese nicht und ersetzt keine materiellen Beweise."],
        ["Was zur Klärung fehlt", "GRENZEN DES ARCHIVS", "Der Bericht enthält keine schlüssigen Gutachten.", "In den konsultierten Auszügen fasst der Blog das Ereignis zusammen, gibt Berichte von Anwohnern wieder und nennt Hypothesen. Dieses Material allein identifiziert nicht den Ursprung der Explosion. Für weitere Schritte wären unter anderem Gutachten, offizielle Akten, technische Aufzeichnungen und überprüfbare Originalaussagen erforderlich.", "Bewertung der Reichweite der konsultierten RIO54-Beiträge; keine Behauptung, dass es keine weiteren Dokumente gibt.", "Schließe daraus, dass die Informationen in dieser Akte nicht ausreichen, um eine Ursache zuzuschreiben.", "Die fehlenden Daten mit einer unbelegten Gewissheit zu füllen.", "Das ist eine gültige Schlussfolgerung: Eine Grenze anzuerkennen, ist ebenfalls ein Forschungsergebnis.", "Wenn Dokumente fehlen, löst eine erfundene Erklärung den Fall nicht."]
      ],
      boardQ: "Wie ist der Bericht über das Licht mit der Explosion in Beziehung zu setzen?",
      board: [
        ["Der Bericht ist relevant und sollte überprüft werden, doch die zeitliche Übereinstimmung beweist nicht, dass das Licht die Explosion verursacht hat.", "Richtig. Du unterscheidest einen Hinweis von einem nachgewiesenen Kausalzusammenhang."],
        ["Das Licht war zwangsläufig ein Raumschiff, das die Explosion auslöste.", "Der Bericht enthält keinen Beleg, der das Licht identifiziert oder kausal mit der Explosion verknüpft."],
        ["Da es eine Explosion gab, können die Anwohner kein Licht gesehen haben.", "Ein tragisches Ereignis macht Zeugenaussagen nicht automatisch ungültig; sie müssen geprüft werden."]
      ],
      verdictQ: "Welche Schlussfolgerung ist angesichts des verfügbaren Materials verantwortbar?",
      verdict: [
        ["Der Bericht dokumentiert eine tragische Explosion und Aussagen über ein Licht, doch die konsultierten Beiträge reichen nicht aus, um die Ursache des Ereignisses zu bestimmen.", ""],
        ["Es ist bewiesen, dass ein außerirdisches Raumschiff in Monte Grande abgestürzt ist.", "Die Akte enthält keine Gutachten oder Belege, die diese Behauptung stützen."],
        ["Es ist bewiesen, dass alle Zeugenaussagen erfunden wurden.", "Unzureichende Bestätigung beweist nicht, dass die Zeugen gelogen haben."]
      ]
    },
    c4: {
      top: [
        "Antarktisches Archiv", "Echos vom Weißen Kontinent", "Argentinische Antarktis · 1965 / dokumentarische Erinnerung von 2016",
        "Eine Marine-Mitteilung aus dem Jahr 1965 und ein RIO54-Treffen im Jahr 2016 helfen, die Erinnerung an offizielle Untersuchungen zu rekonstruieren.",
        "Die letzte Akte verfolgt die Spuren eines antarktischen Vorfalls, der im RIO54-Archiv erwähnt wird. Jahrzehnte später taucht die Geschichte in einem Zeitungsausschnitt und bei einem Gedenktreffen wieder auf. Zu unterscheiden sind die historische Mitteilung, spätere Erinnerungen und nachträgliche Deutungen.",
        "Das Spielmaterial basiert auf dem RIO54-Beitrag vom 26. Juli 2016. Um technische Einzelheiten und vollständige Zeugenaussagen abzugleichen, müssen die dort genannten Originalveröffentlichungen und Dokumente konsultiert werden.",
        "Die Kälte bewahrt Dokumente, doch die Zeit verändert auch die Art, wie wir uns erinnern. Bei einem Treffen im Juli 2016 griff RIO54 eine 51 Jahre zuvor veröffentlichte Mitteilung der Marine und die Geschichte einer Untersuchungskommission wieder auf. Deine Aufgabe ist es, zu rekonstruieren, was diese dokumentarische Erinnerung aussagt.",
        "Welche Rekonstruktion berücksichtigt den zeitlichen Abstand zwischen den Dokumenten am besten?", "Welche Schlussfolgerung ist am besten belegt?",
        "Historische Erinnerung wirft Fragen auf; Originaldokumente helfen, sie zu präzisieren.",
        "Der RIO54-Beitrag vom Juli 2016 erinnert an eine Marine-Mitteilung von 1965, gibt einen Zeitungsausschnitt wieder und erwähnt COPEFO. Er enthält außerdem Erinnerungen von Beteiligten und bibliografische Hinweise. Er ist ein Ausgangspunkt für Archivforschung, aber kein ausreichender Beweis für die Beschaffenheit der beobachteten Phänomene."
      ],
      clues: [
        ["Der Zeitungsausschnitt von 1965", "ERWÄHNTES PRESSEDOKUMENT", "Bericht der Zeitung Crónica vom 7. Juli.", "Der RIO54-Beitrag vom Juli 2016 zeigt einen Ausschnitt der Zeitung Crónica vom 7. Juli 1965. Der Text bringt ihn mit der ersten offiziellen Mitteilung der Marine über UFO-Sichtungen in der argentinischen Antarktis in Verbindung.", "„En RIO54 se recordó a la comisión OVNI de la Armada Argentina“, RIO54, 26.07.2016.", "Erfasse den Ausschnitt als Presseverweis, der in einem späteren Beitrag wiedergegeben wurde.", "Zu behaupten, der Ausschnitt beweise allein die Beschaffenheit des beobachteten Phänomens.", "Gut. Du hast das Dokumentenmedium und den zeitlichen Abstand zwischen Ereignis und späterem Erinnerungsbeitrag erkannt.", "Ein Zeitungsausschnitt kann belegen, dass eine Mitteilung oder Nachricht existierte; er bestimmt nicht automatisch den Ursprung des Phänomens."],
        ["Die COPEFO-Kommission", "INSTITUTIONELLER KONTEXT", "Eine marine Untersuchungskommission in den sechziger Jahren.", "Der Beitrag erwähnt die Ständige Kommission zur Untersuchung des UFO-Phänomens (COPEFO) unter dem Kommando von Kapitän Omar Roque Pagani und beschreibt ihre Arbeit als offizielle Untersuchung der Marine in den 1960er-Jahren.", "RIO54-Beitrag vom 26.07.2016, der Verweise aus dem Buch „Los ovnis de la Antártida“ zusammenfasst.", "Halte die von der Quelle erwähnte Existenz einer Kommission fest und suche nach ihren Originaldokumenten.", "Anzunehmen, dass jede offizielle Kommission zwangsläufig zu einer außerirdischen Schlussfolgerung gelangte.", "Richtig. Der institutionelle Kontext ergänzt die Geschichte der Untersuchung, ist aber kein Urteil über den Ursprung.", "Die Existenz einer Untersuchungseinrichtung bedeutet nicht, dass sie eine bestimmte Hypothese bestätigt hat."],
        ["Die Erinnerung von 2016", "ERINNERUNG UND RÜCKBLICK", "RIO54 greift den Vorfall 51 Jahre später wieder auf.", "Am 7. Juli 2016, dem 51. Jahrestag der Mitteilung von 1965, widmete RIO54 einen Teil seines Treffens dem Gedenken an das Thema. Der Beitrag erwähnt Rubén Morales’ Buch „Los ovnis de la Antártida“ und das Kapitel über die antarktischen Untersuchungen.", "„En RIO54 se recordó a la comisión OVNI de la Armada Argentina“, 26.07.2016.", "Trenne die Erinnerung von 2016 von dem Dokument und den Ereignissen aus dem Jahr 1965, an die sie erinnern soll.", "Die Erinnerungen aus dem Jahr 2016 wie zeitgenössische Zeugenaussagen zu jeder Sichtung zu behandeln.", "Gut. Spätere Erinnerungen können die Recherche leiten, ersetzen aber keine zeitgenössischen Quellen.", "Spätere Erinnerungen sind wertvoll, müssen jedoch von den damals entstandenen Aufzeichnungen unterschieden werden."],
        ["Die Stimmen der Untersuchung", "ZEUGNIS UND KONTEXT", "Erinnerte Erlebnisse und Feldarbeit.", "Der Bericht gibt Erinnerungen von Mario Coen an Feldarbeiten in den Jahren 1964 und 1965 in der Gegend von Dique Los Molinos in Córdoba wieder, wo seinen Angaben zufolge fast zwanzig Fälle gemeldet worden waren. Außerdem erinnert er an Gespräche mit ehemaligen Ermittlern der Marine.", "Der Beitrag gibt Erinnerungen wieder, die bei einem RIO54-Treffen im Juli 2016 geäußert wurden.", "Ordne diese Passagen als Erinnerungen ein, die Beteiligten zugeschrieben werden, nicht als vollständige technische Berichte.", "Erinnerte Anekdoten in endgültige Beweise für einen nichtmenschlichen Ursprung umzuwandeln.", "Genau. Rückblickende Zeugenaussagen können ein Hinweis sein, müssen aber mit zeitgenössischen Aufzeichnungen abgeglichen werden.", "Eine Anekdote verdient Gehör und Prüfung, reicht allein aber nicht aus, um einen außergewöhnlichen Ursprung festzustellen."]
      ],
      boardQ: "Welche Rekonstruktion berücksichtigt den zeitlichen Abstand zwischen den Dokumenten am besten?",
      board: [
        ["Ein Ausschnitt von 1965 wurde 2016 erneut aufgegriffen; bei dem Treffen erinnerte man auch an COPEFO und historische Zeugenaussagen, die mit ihren Originalquellen abgeglichen werden müssen.", "Richtig: Du hast Dokument, institutionelle Erinnerung und persönliche Erinnerungen getrennt."],
        ["Das Treffen von 2016 beweist, dass alle antarktischen Sichtungen außerirdische Raumschiffe waren.", "Die Erinnerung an einen Fall bestimmt nicht die Natur aller Sichtungen."],
        ["Weil der Ausschnitt 2016 gezeigt wurde, kann er keinerlei Informationen über 1965 liefern.", "Eine spätere Wiedergabe kann bei der Suche nach dem Dokument helfen, auch wenn das Original gefunden werden sollte."]
      ],
      verdictQ: "Welche Schlussfolgerung ist am besten belegt?",
      verdict: [
        ["RIO54 erinnert an eine Marine-Mitteilung von 1965 und an die Geschichte offizieller Untersuchungen; das zusammengefasste Material dokumentiert diese Erinnerung, beweist aber für sich allein keinen außerirdischen Ursprung.", ""],
        ["Die Marine bestätigte offiziell, dass die Sichtungen außerirdische Raumschiffe waren.", "Der Beitrag behauptet nicht, dass die Mitteilung einen außerirdischen Ursprung bestätigte."],
        ["Es gab keine offiziellen Untersuchungen und keine Dokumente zu diesem Thema.", "Die Quelle erwähnt die Mitteilung, den Zeitungsausschnitt und die COPEFO-Kommission."]
      ]
    }
  },
  it: {
    c1: {
      top: [
        "Ricostruzione storica", "La luce di settembre", "Buenos Aires e area metropolitana · 17 settembre 1985",
        "Un oggetto aereo viene osservato da molte persone. Anni dopo, l’archivio RIO54 riporta una spiegazione precisa.",
        "Questo caso parte da un’osservazione collettiva sopra Buenos Aires e la sua area metropolitana. Il compito è ricostruire ciò che fu pubblicato, quale spiegazione successiva viene riportata nell’archivio e fin dove consentono di arrivare le informazioni disponibili.",
        "Punto di partenza documentale: un articolo di RIO54 pubblicato il 27 dicembre 2011 attribuisce alle indagini di Carlos Demaría il chiarimento dell’episodio come pallone sonda di origine francese.",
        "La città ricorda una luce insolita. In una cartella d’archivio si trovano ritagli di giornale, date e una nota che torna sul caso. Non troverai una fotografia miracolosa capace di spiegare tutto: dovrai ricostruire la catena delle informazioni.",
        "Quale relazione descrive meglio l’intero fascicolo?", "In base alle informazioni raccolte, quale conclusione occorre presentare?",
        "Il fascicolo trova una spiegazione documentata nella fonte consultata.",
        "L’articolo di RIO54 attribuisce alle indagini di Carlos Demaría l’identificazione dell’oggetto come pallone sonda francese. La conclusione riguarda soltanto questo episodio e ciò che riferisce quell’articolo: non risolve altri casi né invalida altre testimonianze."
      ],
      clues: [
        ["La data dell’episodio", "CRONOLOGIA", "Un riferimento temporale preciso.", "L’articolo di RIO54 colloca l’episodio il 17 settembre 1985 e indica che l’oggetto fu osservato dalla città di Buenos Aires e dall’area metropolitana circostante.", "Articolo “Los blogs de Carlos Demaría”, RIO54, 27/12/2011.", "Registrare data, area e portata esattamente come compaiono nella pubblicazione.", "Trasformare il numero degli osservatori in una prova automatica di un’origine straordinaria.", "Corretto. Hai registrato il dato verificabile contenuto in questa fonte senza attribuirle più di quanto affermi.", "Un gran numero di osservatori rende il caso interessante, ma non determina da solo che cosa fosse l’oggetto."],
        ["I racconti dell’avvistamento", "TESTIMONIANZE RIPORTATE", "Che cosa può apportare una testimonianza collettiva.", "La pubblicazione parla di numerosi testimoni. L’archivio non trascrive qui ogni singolo racconto e l’articolo non offre una raccolta di interviste che permetta di confrontare descrizioni, angoli di osservazione o orari.", "L’articolo di RIO54 riassume il caso; non riproduce tutte le testimonianze originali.", "Distinguere il riferimento generale ai testimoni dalle dichiarazioni complete che non sono incluse.", "Affermare che tutti abbiano visto esattamente la stessa cosa, anche se il testo non lo specifica.", "Bene. Non hai confuso l’esistenza dei racconti con l’accesso a ogni dichiarazione originale.", "L’archivio non consente di affermare che tutti abbiano descritto lo stesso oggetto con dettagli identici."],
        ["L’indagine successiva", "ATTRIBUZIONE DOCUMENTALE", "La spiegazione riportata da RIO54.", "RIO54 ricorda il contributo di Carlos Demaría al chiarimento del caso e afferma che, dopo le opportune verifiche, l’oggetto risultò essere un pallone sonda di origine francese.", "Articolo “Los blogs de Carlos Demaría”, RIO54, 27/12/2011.", "Annotare che questa è la spiegazione che la pubblicazione attribuisce alle indagini di Demaría.", "Attribuire all’articolo dettagli tecnici che non vi compaiono.", "Esatto. Hai mantenuto l’attribuzione alla fonte ed evitato di inventare dettagli sul pallone.", "Il testo fornisce un’identificazione generale, ma in quell’articolo non descrive tutti i dettagli tecnici dell’indagine."],
        ["Il limite della parola UFO", "CRITERIO", "Non identificato non significa extraterrestre.", "In un’indagine, “oggetto volante non identificato” descrive un’osservazione la cui identità è sconosciuta in quel momento. Non classifica la sua provenienza e non costituisce una prova di tecnologia non umana.", "Criterio metodologico integrato nell’esperienza di gioco; non è una citazione letterale del blog.", "Separare la descrizione iniziale dell’oggetto dalla spiegazione successiva riportata dalla fonte.", "Considerare la sigla UFO sinonimo di astronave extraterrestre.", "Questo è il passaggio centrale del fascicolo: un’etichetta di incertezza non è una conclusione sull’origine.", "La sigla indica che qualcosa non era stato identificato in quel momento; non prova una provenienza extraterrestre."]
      ],
      boardQ: "Quale relazione descrive meglio l’intero fascicolo?",
      board: [
        ["I racconti iniziali hanno dato avvio all’indagine; la pubblicazione successiva riporta un’identificazione come pallone sonda francese.", "La sintesi rispetta la sequenza degli eventi e l’attribuzione alla fonte."],
        ["Il gran numero di testimoni dimostra che si trattava di un’astronave extraterrestre.", "Il numero dei testimoni non stabilisce la natura dell’oggetto."],
        ["Poiché esiste una spiegazione successiva, le testimonianze originali devono essere state inventate.", "Un’identificazione successiva non dimostra che gli osservatori abbiano mentito."]
      ],
      verdictQ: "In base alle informazioni raccolte, quale conclusione occorre presentare?",
      verdict: [
        ["Secondo la ricostruzione pubblicata da RIO54, l’oggetto fu identificato in seguito come un pallone sonda di origine francese.", ""],
        ["L’episodio dimostra che un’astronave extraterrestre ha sorvolato Buenos Aires.", "Nel fascicolo non ci sono prove a sostegno di questa affermazione."],
        ["Non ci fu alcun avvistamento: l’intero caso è stato inventato.", "La fonte riferisce numerose osservazioni; ciò che cambia è la spiegazione dell’oggetto."]
      ]
    },
    c2: {
      top: [
        "Istituzioni e documenti", "La commissione sotto esame", "CEFAE · 2010–2015",
        "Una commissione ufficiale annuncia la propria missione, viene istituita formalmente e in seguito compare un primo rapporto citato dal blog.",
        "Questo fascicolo indaga come valutare un’istituzione pubblica attraverso annunci, risoluzioni, missioni dichiarate e documenti pubblicati. Richiede inoltre di distinguere il contenuto di una fonte dalle opinioni dei suoi autori.",
        "Il blog RIO54 raccoglie articoli del 2011 e del 2015 sulla Commissione per lo studio dei fenomeni aerospaziali (CEFAE). Le critiche editoriali del blog sono presentate come tali, non come fatti dimostrati dal gioco.",
        "Sul tavolo ci sono ritagli di giornale, una risoluzione citata in un articolo e una pagina che descrive la missione istituzionale. Anni dopo, il blog torna sull’argomento commentando la comparsa di un rapporto. Il tuo compito è distinguere cronologia, documenti e valutazioni.",
        "Qual è la lettura più rigorosa della cronologia?", "Che cosa dovrebbe dire il rapporto finale dell’investigatore?",
        "Una buona indagine separa fatti amministrativi, pubblicazioni e opinioni.",
        "La cronologia del blog distingue un annuncio nel 2010, l’istituzione formale della CEFAE nel 2011 e la pubblicazione di un rapporto nel 2015. Le obiezioni sulla forma del rapporto sono critiche degli autori del blog. Per una verifica completa occorrerebbe consultare la risoluzione e il rapporto originali dell’Aeronautica.",
      ],
      clues: [
        ["L’annuncio iniziale", "CRONOLOGIA", "La notizia appare nel dicembre 2010.", "Nell’articolo “Los misterios de la comisión oficial sobre ovnis”, RIO54 colloca il primo annuncio televisivo della futura commissione al 22 dicembre 2010, durante un’intervista al commodoro Guillermo Daniel Tealdi.", "“Los misterios de la comisión oficial sobre ovnis”, RIO54, 22/12/2011.", "Registrare la data come annuncio di una commissione ancora da istituire, non come data della sua creazione formale.", "Confondere il primo annuncio televisivo con la risoluzione amministrativa.", "Bene. Una notizia di annuncio e l’atto amministrativo che istituisce formalmente un organismo sono due cose diverse.", "L’annuncio avvenne prima della risoluzione formale citata nello stesso articolo."],
        ["Nome e missione", "DOCUMENTO ISTITUZIONALE", "CEFAE: studio dei fenomeni aerospaziali.", "L’articolo del giugno 2011 informa che l’ente fu denominato Commissione per lo studio dei fenomeni aerospaziali (CEFAE). Riporta una missione orientata a documentare, analizzare e studiare in modo ordinato e accurato i fenomeni non identificati dai sistemi di controllo convenzionali nello spazio aereo di giurisdizione nazionale.", "“La comisión de la Fuerza Aérea ya está en la web”, RIO54, 19/06/2011; l’articolo trascrive il testo ufficiale di presentazione.", "Distinguere il nome formale e la missione dichiarata da qualsiasi conclusione sui risultati delle indagini.", "Leggere la missione istituzionale come prova che sia stato confermato un caso straordinario.", "Corretto. Una missione definisce ciò che un ufficio dichiara di dover fare, non anticipa i risultati.", "Il mandato di studiare fenomeni non identificati non significa che l’istituzione abbia confermato un’ipotesi."],
        ["La risoluzione citata", "ATTO AMMINISTRATIVO RIFERITO", "La formalizzazione descritta dal blog.", "L’articolo del dicembre 2011 afferma che la risoluzione che ufficializzò la CEFAE fu firmata il 5 maggio 2011. Lo stesso articolo riporta lo scopo generale di fornire consulenza all’Aeronautica su questioni legate a fenomeni aerospaziali non identificati.", "“Los misterios de la comisión oficial sobre ovnis”, RIO54, 22/12/2011.", "Annotare la data e precisare che l’informazione proviene dal resoconto documentale del blog.", "Affermare di conoscere il testo completo della risoluzione senza aver consultato il documento originale.", "Buona pratica: hai conservato il dato e la provenienza dell’affermazione.", "L’articolo riassume e cita parti della risoluzione; non equivale a consultare qui il documento amministrativo completo."],
        ["Il rapporto del 2015", "PUBBLICAZIONE E CRITICA", "Il blog commenta il primo rapporto pubblicato.", "In un articolo del 18 dicembre 2015, RIO54 afferma che il primo rapporto della CEFAE fu pubblicato sul sito dell’Aeronautica all’inizio di quel mese, quattro anni e mezzo dopo la sua creazione. Gli autori criticano inoltre il formato del PDF e l’assenza di firme che, secondo la loro descrizione, lo caratterizzava.", "“Luego de cuatro años y medio, la comisión oficial sobre ovnis lanzó su primer informe”, RIO54, 18/12/2015. È la descrizione e valutazione degli autori del blog.", "Separare il fatto riferito dal blog — la pubblicazione del rapporto — dalle critiche degli autori alla sua presentazione.", "Concludere che il rapporto provi un insabbiamento o che non sia stato svolto alcun lavoro.", "Esattamente. Una critica documentale può essere rilevante senza dimostrare, da sola, un’intenzione di occultamento.", "Il ritardo e le obiezioni formali possono giustificare domande, ma non provano automaticamente un insabbiamento."]
      ],
      boardQ: "Qual è la lettura più rigorosa della cronologia?",
      board: [
        ["Ci fu un annuncio nel 2010, la formalizzazione nel 2011 e il blog riferì la pubblicazione di un primo rapporto nel 2015; le critiche al rapporto vanno attribuite ai loro autori.", "Corretto: hai separato la cronologia dalla valutazione editoriale."],
        ["L’esistenza della CEFAE dimostra che l’Aeronautica ha confermato visite extraterrestri.", "La missione istituzionale parla di studiare fenomeni non identificati, non di confermare la presenza di extraterrestri."],
        ["La comparsa tardiva di un rapporto dimostra necessariamente che l’intera commissione era fittizia.", "La fonte descrive una commissione, la sua formalizzazione e un rapporto; il ritardo non ne dimostra l’inesistenza."]
      ],
      verdictQ: "Che cosa dovrebbe dire il rapporto finale dell’investigatore?",
      verdict: [
        ["Secondo la cronologia riportata da RIO54, la CEFAE fu annunciata e formalizzata; il blog riferì un primo rapporto nel 2015 e ne criticò la presentazione. Queste critiche, da sole, non provano un insabbiamento.", ""],
        ["La CEFAE trovò astronavi extraterrestri e lo confermò segretamente.", "Nei documenti del fascicolo non ci sono prove a sostegno di questa affermazione."],
        ["La commissione non è mai esistita e tutti gli annunci erano falsi.", "La cronologia contenuta nell’archivio contraddice questa conclusione."]
      ]
    },
    c3: {
      top: [
        "Testimonianze e prudenza", "La notte di Monte Grande", "Monte Grande, provincia di Buenos Aires · 26 settembre 2011",
        "Un’esplosione, una vittima e i racconti di una luce nel cielo generano ipotesi da esaminare con attenzione.",
        "Questo fascicolo affronta un evento tragico menzionato nelle cronache del blog. Sarà trattato con rispetto: senza ricreare il danno, senza trasformare il dolore in spettacolo e senza presentare come fatto un’ipotesi sull’origine dell’esplosione.",
        "La pubblicazione di RIO54 riferisce che ci fu una vittima. Il gioco non rappresenta graficamente l’evento e non afferma di averne stabilito la causa.",
        "Nell’archivio c’è una breve notizia: un’esplosione distrusse abitazioni e un’attività commerciale. Alcuni residenti collegarono una luce intensa al momento dello scoppio. Il caso divenne argomento di discussione e circolarono spiegazioni molto diverse. La prima regola è non confondere la vicinanza temporale con una causalità dimostrata.",
        "Come va messo in relazione il racconto della luce con l’esplosione?", "Quale conclusione è responsabile alla luce del materiale disponibile?",
        "A volte la conclusione più solida è riconoscere ciò che non è stato possibile stabilire.",
        "La cronaca di RIO54 menziona un’esplosione con gravi conseguenze umane e riporta che alcuni residenti parlarono di una luce intensa. Elenca anche le ipotesi che circolarono. Le informazioni consultate non consentono di determinare la causa; per rispetto delle persone coinvolte, il gioco evita di trasformare una tragedia in uno spettacolo ufologico."
      ],
      clues: [
        ["L’evento", "FATTO RIFERITO", "Data e conseguenze umane.", "La cronaca di RIO54 colloca l’esplosione nelle prime ore di lunedì 26 settembre 2011. Riferisce che due abitazioni e un’attività commerciale furono completamente distrutte e che ci fu una vittima.", "“OVNIS: exitosa reunión RIO54 de octubre”, RIO54, 09/10/2011.", "Registrare l’evento e le sue conseguenze umane senza formulare ipotesi sulla causa.", "Trattare la tragedia come una scena di finzione o come prova di un’origine non umana.", "Grazie per aver mantenuto l’attenzione sull’evento e sulle persone coinvolte. L’indagine deve partire da qui.", "La tragedia merita rispetto. La sua gravità non determina da sola l’origine dell’esplosione."],
        ["Ciò che dissero i residenti", "TESTIMONIANZA RIFERITA", "Sarebbe stata vista una luce intensa.", "La cronaca riferisce che alcuni residenti affermarono che una luce intensa era arrivata dal cielo al momento dello scoppio. L’articolo consultato non pubblica dichiarazioni complete, registrazioni strumentali o perizie che permettano di valutare separatamente ogni racconto.", "La cronaca di RIO54 riassume le testimonianze dei residenti.", "Registrare la luce come un racconto attribuito ai residenti e cercare le dichiarazioni originali prima di valutarlo.", "Affermare che la luce abbia causato l’esplosione perché fu segnalata nello stesso momento.", "Bene. Una coincidenza temporale è una pista da indagare, non una dimostrazione causale.", "La simultaneità percepita non basta a dimostrare che la luce abbia causato l’esplosione."],
        ["Le ipotesi che circolarono", "IPOTESI PUBBLICHE", "Meteorite, detriti spaziali o astronave.", "L’articolo elenca ipotesi che circolarono rapidamente: caduta di un meteorite, detriti spaziali o perfino un velivolo di origine non terrestre. L’elenco documenta il dibattito pubblico, ma non conferma nessuna di queste possibilità.", "“OVNIS: exitosa reunión RIO54 de octubre”, RIO54, 09/10/2011.", "Classificare queste opzioni come ipotesi citate, ancora in attesa di prove indipendenti.", "Scegliere l’ipotesi più spettacolare perché si è diffusa rapidamente.", "Corretto. La presenza di un’ipotesi in una cronaca non equivale a una conclusione peritale.", "La rapidità della diffusione non rafforza un’ipotesi e non sostituisce le prove materiali."],
        ["Che cosa manca per risolvere il caso", "LIMITI DELL’ARCHIVIO", "La cronaca non fornisce perizie conclusive.", "Nei brani consultati il blog riassume il fatto, riporta il racconto dei residenti e menziona ipotesi. Questo materiale, da solo, non identifica l’origine dell’esplosione. Per proseguire servirebbero, tra le altre cose, perizie, fascicoli ufficiali, registrazioni tecniche e testimonianze originali verificabili.", "Valutazione della portata degli articoli di RIO54 consultati; non afferma che non esistano altri documenti.", "Concludere che le informazioni di questo fascicolo non sono sufficienti per attribuire una causa.", "Colmare la mancanza di dati con una certezza non supportata.", "È una conclusione valida: riconoscere un limite è anch’esso un risultato della ricerca.", "Quando mancano documenti, inventare una spiegazione non risolve il caso."]
      ],
      boardQ: "Come va messo in relazione il racconto della luce con l’esplosione?",
      board: [
        ["La testimonianza è rilevante e merita verifiche, ma la coincidenza temporale non dimostra che la luce abbia causato l’esplosione.", "Corretto. Hai distinto una pista da un rapporto causale accertato."],
        ["La luce era necessariamente un’astronave che provocò l’esplosione.", "La cronaca non fornisce prove che identifichino la luce o la colleghino causalmente all’esplosione."],
        ["Poiché c’è stata un’esplosione, i residenti non possono aver visto alcuna luce.", "L’esistenza di un evento tragico non invalida automaticamente le testimonianze; devono essere esaminate."]
      ],
      verdictQ: "Quale conclusione è responsabile alla luce del materiale disponibile?",
      verdict: [
        ["La cronaca registra una tragica esplosione e testimonianze su una luce, ma gli articoli consultati non bastano a determinare la causa dell’evento.", ""],
        ["È dimostrato che un’astronave extraterrestre è precipitata a Monte Grande.", "Il fascicolo non contiene perizie né prove che consentano di affermarlo."],
        ["È dimostrato che tutte le testimonianze sono state inventate.", "La mancanza di conferme sufficienti non dimostra che i testimoni abbiano mentito."]
      ]
    },
    c4: {
      top: [
        "Archivio antartico", "Echi dal continente bianco", "Antartide Argentina · 1965 / memoria documentale del 2016",
        "Un comunicato navale del 1965 e un incontro RIO54 del 2016 aiutano a ricostruire la memoria delle indagini ufficiali.",
        "L’ultimo fascicolo segue le tracce di un episodio antartico citato nell’archivio RIO54. La storia riappare decenni dopo in un ritaglio di giornale e durante un incontro commemorativo. Occorre distinguere l’annuncio storico, i ricordi e le interpretazioni successive.",
        "Il materiale di gioco si basa sull’articolo RIO54 del 26 luglio 2016. Per confrontare dettagli tecnici e testimonianze complete è necessario consultare le pubblicazioni e i documenti originali citati.",
        "Il freddo conserva i documenti, ma il tempo cambia anche il modo in cui li ricordiamo. In un incontro del luglio 2016, RIO54 è tornato su un comunicato navale pubblicato 51 anni prima e sulla storia di una commissione di studio. Il tuo compito è ricostruire ciò che afferma questa memoria documentale.",
        "Quale ricostruzione rispetta meglio la distanza tra i documenti?", "Qual è la conclusione meglio supportata?",
        "La memoria storica apre domande; i documenti originali aiutano a precisarle.",
        "L’articolo RIO54 del luglio 2016 ricorda un comunicato navale del 1965, riproduce un ritaglio di giornale e menziona la COPEFO. Include anche ricordi dei partecipanti e riferimenti bibliografici. È un punto di partenza per indagare gli archivi, non una prova sufficiente della natura dei fenomeni osservati."
      ],
      clues: [
        ["Il ritaglio del 1965", "DOCUMENTO STAMPA CITATO", "Articolo del quotidiano Crónica, 7 luglio.", "L’articolo RIO54 del luglio 2016 mostra un ritaglio del quotidiano Crónica datato 7 luglio 1965. Il testo lo collega al primo comunicato ufficiale della Marina sugli avvistamenti di UFO nell’Antartide Argentina.", "“En RIO54 se recordó a la comisión OVNI de la Armada Argentina”, RIO54, 26/07/2016.", "Registrare il ritaglio come riferimento giornalistico riprodotto in un articolo successivo.", "Affermare che il ritaglio, da solo, dimostri la natura del fenomeno osservato.", "Bene. Hai identificato il supporto documentale e la distanza temporale tra l’evento e l’articolo che lo ricorda.", "Un ritaglio può attestare l’esistenza di una comunicazione o notizia; non stabilisce automaticamente l’origine del fenomeno."],
        ["La commissione COPEFO", "CONTESTO ISTITUZIONALE", "Una commissione navale di studio negli anni Sessanta.", "L’articolo menziona la Commissione permanente per lo studio del fenomeno UFO (COPEFO), sotto il comando del capitano Omar Roque Pagani, e descrive il suo lavoro come un’indagine ufficiale condotta dalla Marina negli anni Sessanta.", "Articolo RIO54 del 26/07/2016, che riassume riferimenti del libro “Los ovnis de la Antártida”.", "Annotare l’esistenza della commissione menzionata dalla fonte e cercare i suoi documenti originali.", "Supporre che ogni commissione ufficiale sia necessariamente giunta a una conclusione extraterrestre.", "Corretto. Il contesto istituzionale arricchisce la storia dell’indagine, ma non è un verdetto sull’origine.", "L’esistenza di un organismo di studio non significa che abbia confermato una particolare ipotesi."],
        ["Il ricordo del 2016", "MEMORIA E RETROSPETTIVA", "RIO54 torna sull’episodio 51 anni dopo.", "Il 7 luglio 2016, nel 51º anniversario della comunicazione del 1965, RIO54 dedicò parte del suo incontro a ricordare l’argomento. L’articolo menziona il libro “Los ovnis de la Antártida” di Rubén Morales e il capitolo dedicato alle indagini antartiche.", "“En RIO54 se recordó a la comisión OVNI de la Armada Argentina”, 26/07/2016.", "Separare il ricordo del 2016 dal documento e dagli eventi del 1965 che intende ricordare.", "Trattare i ricordi del 2016 come se fossero testimonianze contemporanee di ogni avvistamento.", "Bene. La memoria successiva orienta la ricerca, ma non sostituisce le fonti contemporanee.", "I ricordi successivi sono preziosi, ma devono essere distinti dai documenti prodotti all’epoca."],
        ["Le voci dell’indagine", "TESTIMONIANZA E CONTESTO", "Esperienze ricordate e lavoro sul campo.", "La cronaca raccoglie i ricordi di Mario Coen su attività sul campo svolte nel 1964 e 1965 nella zona di Dique Los Molinos, Córdoba, dove — secondo il suo racconto — erano stati segnalati quasi venti casi. Ricorda anche conversazioni con ex ricercatori della Marina.", "L’articolo riproduce ricordi condivisi durante un incontro RIO54 del luglio 2016.", "Identificare questi passaggi come ricordi attribuiti ai partecipanti, non come rapporti tecnici completi.", "Trasformare aneddoti ricordati in prove definitive di un’origine non umana.", "Esatto. Una testimonianza retrospettiva può essere una pista, ma va confrontata con i documenti contemporanei.", "Un aneddoto merita ascolto e analisi, ma da solo non basta a stabilire un’origine straordinaria."]
      ],
      boardQ: "Quale ricostruzione rispetta meglio la distanza tra i documenti?",
      board: [
        ["Un ritaglio del 1965 è stato ripreso nel 2016; l’incontro ha ricordato anche la COPEFO e testimonianze storiche, da confrontare con le fonti originali.", "Corretto: hai distinto il documento, la memoria istituzionale e i ricordi personali."],
        ["L’incontro del 2016 dimostra che tutti gli avvistamenti antartici riguardavano astronavi extraterrestri.", "Il ricordo di un caso non stabilisce la natura di tutti gli avvistamenti."],
        ["Poiché il ritaglio è stato mostrato nel 2016, non può fornire alcuna informazione sul 1965.", "Una riproduzione successiva può orientare la ricerca del documento, anche se è preferibile reperire l’originale."]
      ],
      verdictQ: "Qual è la conclusione meglio supportata?",
      verdict: [
        ["RIO54 ricorda un comunicato navale del 1965 e una storia di indagini ufficiali; il materiale riassunto documenta questa memoria, ma non prova da solo un’origine extraterrestre.", ""],
        ["La Marina confermò ufficialmente che gli avvistamenti erano astronavi extraterrestri.", "L’articolo non afferma che il comunicato abbia confermato un’origine extraterrestre."],
        ["Non ci furono indagini ufficiali né documenti sull’argomento.", "La fonte menziona il comunicato, il ritaglio e la commissione COPEFO."]
      ]
    }
  },
  ja: {
    c1: {
      top: [
        "歴史的再構成", "9月の光", "ブエノスアイレスおよび周辺都市圏 · 1985年9月17日",
        "多くの人々が空中の物体を目撃した。数年後、RIO54のアーカイブには具体的な説明が記録された。",
        "この事件ファイルは、ブエノスアイレスと周辺地域で多数の人が目撃した出来事から始まる。何が公表され、その後アーカイブがどのような説明を記録したのか、そして情報からどこまで結論づけられるのかを再構成しよう。",
        "資料上の出発点：2011年12月27日付のRIO54の記事は、カルロス・デマリアの調査によって、この出来事はフランス製の観測気球だったと判明したと記している。",
        "街には不思議な光の記憶が残っている。新聞の切り抜き、日付、事件を再検討する記事が資料フォルダーに収められている。すべてを解決する魔法の写真はない。情報が伝わった経緯を自分で組み立てよう。",
        "事件全体を最もよく説明する関係はどれだろう？", "集めた情報に基づき、どの結論を提出すべきだろう？",
        "参照した資料の中に、この事件についての記録された説明が見つかった。",
        "RIO54の記事は、カルロス・デマリアの調査によって物体がフランス製の観測気球と特定されたと述べている。この結論は、その出来事と記事に記載された内容に限られる。他の事件を解決するものでも、別の証言を無効にするものでもない。"
      ],
      clues: [
        ["事件の日付", "時系列", "具体的な日付の記録。", "RIO54の記事は事件を1985年9月17日とし、ブエノスアイレス市内およびブエノスアイレス都市圏から物体が目撃されたと記している。", "記事「Los blogs de Carlos Demaría」RIO54、2011年12月27日。", "掲載内容どおりに日付、地域、範囲を記録する。", "目撃者の数を、異常な起源を示す自動的な証拠として扱う。", "正解。この資料で確認できる情報を、書かれている以上の意味を加えずに記録できた。", "目撃者が多いことは調査する価値を高めるが、それだけで物体の正体が決まるわけではない。"],
        ["目撃証言", "紹介された証言", "集団による証言から何が分かるか。", "記事は多数の目撃者に言及している。しかし、アーカイブには個々の証言がすべて掲載されておらず、この投稿にも、説明や観測角度、時刻を比較できる聞き取り資料は含まれていない。", "RIO54の記事は事件を要約しており、すべての原証言を再録しているわけではない。", "目撃者がいたという一般的な記述と、ここに含まれていない完全な証言を区別する。", "本文に詳細がないのに、全員がまったく同じものを見たと断言する。", "よくできた。証言が存在することと、各人の原文の証言を読めることを混同しなかった。", "この資料だけでは、全員が同じ物体を同一の細部まで説明したとは言えない。"],
        ["その後の調査", "資料に基づく帰属", "RIO54が記録した説明。", "RIO54は事件の解明におけるカルロス・デマリアの貢献を振り返り、必要な調査の結果、物体はフランス製の観測気球だったと述べている。", "記事「Los blogs de Carlos Demaría」RIO54、2011年12月27日。", "これはデマリアの調査結果として記事が紹介している説明だと記録する。", "記事にない技術的な詳細を、記事が述べたこととして付け加える。", "そのとおり。出典への帰属を保ち、気球についての詳細を創作しなかった。", "本文は大まかな特定を示しているが、その投稿では調査の技術的詳細すべてを説明していない。"],
        ["UFOという言葉の限界", "判断基準", "未確認は地球外を意味しない。", "調査において「未確認飛行物体」とは、その時点で正体が分かっていない目撃対象を指す。出所を分類する言葉ではなく、地球外の技術を証明するものでもない。", "ゲーム体験に組み込まれた方法論上の基準。ブログからの直接引用ではない。", "最初の物体の描写と、資料が記録している後日の説明を分けて考える。", "UFOという呼称を、地球外生命体の宇宙船と同じ意味で扱う。", "この事件ファイルの中心となる考え方だ。不確実性を示す呼称は、起源についての結論ではない。", "略語が示すのは、その時点で正体が確認されていなかったということだけであり、地球外起源を証明するものではない。"]
      ],
      boardQ: "事件全体を最もよく説明する関係はどれだろう？",
      board: [
        ["最初の目撃証言が調査のきっかけとなり、後の公表資料はフランス製の観測気球と特定されたことを記録している。", "要約は出来事の順序と出典への帰属を正しく保っている。"],
        ["目撃者が多かったことは、地球外の宇宙船だった証拠である。", "目撃者の数だけでは物体の性質は分からない。"],
        ["後から説明が出たのだから、最初の証言は必ず捏造だった。", "後日の特定によって、目撃者が嘘をついたと証明されるわけではない。"]
      ],
      verdictQ: "集めた情報に基づき、どの結論を提出すべきだろう？",
      verdict: [
        ["RIO54が公表した再構成によれば、物体は後にフランス製の観測気球と特定された。", ""],
        ["この出来事は地球外の宇宙船がブエノスアイレス上空を飛行した証拠である。", "この事件ファイルには、その主張を裏付ける証拠はない。"],
        ["目撃は一度もなく、事件全体が完全な作り話だった。", "資料は多数の目撃があったと記している。変わったのは物体の説明である。"]
      ]
    },
    c2: {
      top: [
        "機関と文書", "委員会を検証する", "CEFAE · 2010–2015年",
        "公的委員会が任務を発表し、正式に設立され、後年にはブログが引用する初の報告書が公開された。",
        "この事件ファイルでは、発表、決議、公式に掲げられた任務、公表文書をもとに公的機関をどう評価するかを調べる。また、資料の内容と執筆者の意見を区別する必要がある。",
        "RIO54のブログには、航空宇宙現象研究委員会（CEFAE）についての2011年と2015年の記事がまとめられている。ブログの編集上の批判は、ゲームが証明した事実ではなく、批判として示す。",
        "机の上には新聞の切り抜き、記事で言及された決議、機関の任務を説明するページがある。数年後、ブログは報告書の公開を取り上げ、再びこの話題に戻った。任務は時系列、文書、評価を分けることだ。",
        "時系列を最も厳密に読むと、どうなるだろう？", "調査者の最終報告には何を記すべきだろう？",
        "優れた調査は、行政上の事実、公表内容、意見を分ける。",
        "ブログの時系列は、2010年の発表、2011年のCEFAE正式設立、2015年の報告書公開を区別している。報告書の形式への異議はブログ執筆者による批判である。完全な監査には、空軍の決議と報告書の原本を確認する必要がある。"
      ],
      clues: [
        ["最初の発表", "時系列", "ニュースは2010年12月に報じられた。", "記事「Los misterios de la comisión oficial sobre ovnis」で、RIO54は将来設置される委員会について最初にテレビで発表された日を2010年12月22日とし、ギジェルモ・ダニエル・テアルディ准将へのインタビューであったと記している。", "「Los misterios de la comisión oficial sobre ovnis」RIO54、2011年12月22日。", "正式な設立日ではなく、設立予定の委員会についての発表日として記録する。", "最初のテレビ発表と行政上の決議を混同する。", "よくできた。報道発表と組織を正式に設立する行政行為は別のものだ。", "発表は、記事自体が言及している正式決議より前に行われた。"],
        ["名称と任務", "機関文書", "CEFAE：航空宇宙現象の研究。", "2011年6月の記事によれば、この組織は航空宇宙現象研究委員会（CEFAE）と名付けられた。国内管轄空域において通常の監視システムで特定できない現象を、体系的かつ正確に記録、分析、研究する任務が紹介されている。", "「La comisión de la Fuerza Aérea ya está en la web」RIO54、2011年6月19日。記事は公式紹介文を転載している。", "正式名称と公表された任務を、調査結果についての結論と区別する。", "機関の任務を、異常な事例が確認された証拠のように読む。", "正解。任務は組織が何を行うべきと定めているかを示すもので、結果を先取りするものではない。", "未確認現象を研究する権限があるからといって、機関が仮説を確認したことにはならない。"],
        ["言及された決議", "言及された行政行為", "ブログが説明する正式化。", "2011年12月の記事は、CEFAEを正式化する決議が2011年5月5日に署名されたと述べている。同じ記事は、未確認の航空宇宙現象に関する事項について空軍に助言するという一般的な目的も紹介している。", "「Los misterios de la comisión oficial sobre ovnis」RIO54、2011年12月22日。", "日付を記録し、この情報がブログの文書に関する説明に基づくことを明記する。", "原本を確認していないのに、決議の全文を知っていると主張する。", "適切な方法だ。情報と、その主張の出所をともに保っている。", "記事は決議の一部を要約し引用しているが、ここで行政文書の全文を確認したことにはならない。"],
        ["2015年の報告書", "公開と批判", "ブログは初めて公開された報告書について論評している。", "2015年12月18日の記事で、RIO54はCEFAE設立から4年半後の同月初めに、空軍のウェブサイトで初の報告書が公開されたと述べている。執筆者らは、PDFの形式や署名がなかった点についても批判している。", "「Luego de cuatro años y medio, la comisión oficial sobre ovnis lanzó su primer informe」RIO54、2015年12月18日。これはブログ執筆者による説明と評価である。", "ブログが報告した事実、すなわち報告書の公開と、執筆者による提示方法への批判を分ける。", "報告書は隠蔽を証明している、または何の調査も行われなかったと結論づける。", "そのとおり。文書への批判は重要な場合があるが、それだけで情報を隠す意図が証明されるわけではない。", "公開の遅れや形式上の問題は疑問を生むが、自動的に隠蔽を証明するものではない。"]
      ],
      boardQ: "時系列を最も厳密に読むと、どうなるだろう？",
      board: [
        ["2010年に発表があり、2011年に正式化され、2015年に初の報告書が公開されたとブログが伝えた。その報告書への批判は執筆者に帰属させるべきだ。", "正解。時系列と編集上の評価を区別できた。"],
        ["CEFAEの存在は、空軍が地球外生命体の訪問を確認した証拠である。", "機関の任務は未確認現象の研究であり、地球外生命体の確認ではない。"],
        ["報告書の公開が遅れたことは、委員会全体が架空だったことを必然的に証明する。", "資料は委員会、正式化、報告書について記している。遅延は存在しなかった証拠にはならない。"]
      ],
      verdictQ: "調査者の最終報告には何を記すべきだろう？",
      verdict: [
        ["RIO54が記録した時系列によれば、CEFAEは発表され、正式に設立された。ブログは2015年の初報告書公開を伝え、その提示方法を批判した。ただし、その批判だけで隠蔽が証明されるわけではない。", ""],
        ["CEFAEは地球外の宇宙船を発見し、それを秘密裏に確認した。", "この事件ファイルの文書には、その主張を裏付ける証拠はない。"],
        ["委員会は一度も存在せず、すべての発表が虚偽だった。", "アーカイブ内の時系列は、その結論と矛盾している。"]
      ]
    },
    c3: {
      top: [
        "証言と慎重さ", "モンテ・グランデの夜", "ブエノスアイレス州モンテ・グランデ · 2011年9月26日",
        "爆発と一人の犠牲者、空の光に関する証言から、慎重に検証すべき仮説が生まれた。",
        "この事件ファイルは、ブログの記事で言及された悲劇的な出来事を扱う。被害を再現せず、苦しみを見世物にせず、爆発の原因に関する仮説を事実として提示しないという敬意ある姿勢で扱う。",
        "RIO54の記事は一人の犠牲者が出たと報告している。ゲームは出来事を視覚的に再現せず、爆発の原因を特定したとも主張しない。",
        "アーカイブには短いニュース記事がある。爆発によって住宅と店舗が破壊された。住民は強い光と爆発の瞬間を結びつけた。この事件は話題となり、さまざまな説明が広まった。最初の原則は、時間的な近さと証明された因果関係を混同しないことだ。",
        "光の目撃証言と爆発は、どのように関連づけるべきだろう？", "利用できる資料から導ける責任ある結論は何だろう？",
        "時には、確定できなかったことを認めるのが最も確かな結論となる。",
        "RIO54の記事は深刻な人的被害を伴う爆発に触れ、住民が強い光を語ったことを記録している。また、流布した仮説も列挙している。確認した情報だけでは原因を特定できない。被害を受けた人々への敬意から、ゲームは悲劇をUFOの見世物に変えることを避けている。"
      ],
      clues: [
        ["出来事", "記録された事実", "日付と人的被害。", "RIO54の記事は爆発を2011年9月26日月曜日の未明としている。住宅2棟と店舗1軒が全壊し、一人が死亡したと記している。", "「OVNIS: exitosa reunión RIO54 de octubre」RIO54、2011年10月9日。", "原因を推測せず、出来事と人的被害を記録する。", "悲劇をフィクションの場面、または非人間的な起源の証拠として扱う。", "出来事と被害を受けた人々に焦点を当ててくれてありがとう。調査はそこから始めるべきだ。", "悲劇には敬意が必要だ。その深刻さだけでは爆発の原因は決まらない。"],
        ["住民の証言", "紹介された証言", "強い光が見えたという証言。", "記事によれば、現場近くの住民は爆発時に強い光が空から来たと話した。確認した記事には、個々の証言を別々に評価するための完全な発言記録、計測記録、鑑定結果は掲載されていない。", "RIO54の記事は住民の証言を要約している。", "光について、住民に帰属する証言として記録し、評価する前に原証言を探す。", "同時刻に報告されたという理由で、光が爆発を引き起こしたと断言する。", "よくできた。時間的な一致は調査の手掛かりであり、因果関係の証明ではない。", "同時に起きたように見えることだけでは、光が爆発を引き起こしたとは証明できない。"],
        ["広まった仮説", "公に語られた仮説", "隕石、宇宙ごみ、または宇宙船。", "記事は、隕石の落下、宇宙ごみ、さらには地球外起源の飛行物体など、急速に広まった仮説を列挙している。この一覧は世間の議論を記録するもので、いずれの説も確認していない。", "「OVNIS: exitosa reunión RIO54 de octubre」RIO54、2011年10月9日。", "これらを言及された仮説として分類し、独立した証拠が必要なものとして扱う。", "急速に広まったという理由で、最も刺激的な仮説を選ぶ。", "正解。記事に仮説が登場することと、専門家の鑑定結論とは同じではない。", "広まる速度は仮説の質を高めず、物的証拠の代わりにもならない。"],
        ["解決に必要なもの", "アーカイブの限界", "記事には決定的な鑑定結果がない。", "確認した箇所でブログは出来事を要約し、住民の証言を取り上げ、仮説を挙げている。しかし、それだけでは爆発の原因を特定できない。さらに調べるには、鑑定、公式記録、技術的な計測記録、照合可能な原証言などが必要となる。", "確認したRIO54の記事の範囲に関する評価であり、他の文書が存在しないという主張ではない。", "この事件ファイルの情報だけでは原因を特定するには不十分だと結論づける。", "裏付けのない確信で情報の不足を埋める。", "それは妥当な結論だ。限界を認めることも調査の成果である。", "文書が足りないとき、説明を作り上げても事件は解決しない。"]
      ],
      boardQ: "光の目撃証言と爆発は、どのように関連づけるべきだろう？",
      board: [
        ["証言は重要で検証に値するが、時間が一致しただけでは光が爆発を引き起こしたとは証明できない。", "正解。手掛かりと、確立された因果関係を区別できた。"],
        ["その光は必ず爆発を引き起こした宇宙船だった。", "記事には光の正体や爆発との因果関係を示す証拠がない。"],
        ["爆発が起きたのだから、住民が光を見ることはあり得なかった。", "悲劇が起きたからといって証言が自動的に無効になるわけではない。検証する必要がある。"]
      ],
      verdictQ: "利用できる資料から導ける責任ある結論は何だろう？",
      verdict: [
        ["記事は悲劇的な爆発と光に関する証言を記録しているが、確認した投稿だけでは出来事の原因を特定するには不十分である。", ""],
        ["地球外の宇宙船がモンテ・グランデに墜落したことが証明された。", "事件ファイルには、その主張を裏付ける鑑定や証拠がない。"],
        ["すべての証言が捏造だったことが証明された。", "十分な裏付けがないことは、証人が嘘をついた証明にはならない。"]
      ]
    },
    c4: {
      top: [
        "南極アーカイブ", "白い大陸からのこだま", "アルゼンチン領南極 · 1965年 / 2016年の記録上の回想",
        "1965年の海軍発表と2016年のRIO54会合を手掛かりに、公的調査の記憶を再構成する。",
        "最後の事件ファイルは、RIO54のアーカイブで引用された南極の出来事を追う。数十年後、新聞の切り抜きや記念会合で再び語られた物語である。歴史的な発表、後年の回想、その後の解釈を区別しよう。",
        "ゲームの資料は、2016年7月26日付のRIO54の記事に基づいている。技術的な詳細や完全な証言を照合するには、そこで言及された原資料や文書を確認する必要がある。",
        "寒さは文書を保存するが、時間は記憶の形も変える。2016年7月の会合で、RIO54は51年前に発表された海軍の声明と調査委員会の歴史を振り返った。この記録上の回想が何を述べているのかを再構成しよう。",
        "文書間の時間的な隔たりを最も適切に踏まえた再構成はどれだろう？", "最もよく裏付けられる結論はどれだろう？",
        "歴史の記憶は問いを開き、原資料はその問いを精密にする。",
        "2016年7月のRIO54の記事は、1965年の海軍発表を振り返り、新聞の切り抜きを再掲し、COPEFOに言及している。また、参加者の回想や書誌情報も含む。これはアーカイブ調査の出発点であり、目撃された現象の正体を十分に証明するものではない。"
      ],
      clues: [
        ["1965年の新聞記事", "紹介された報道資料", "新聞『Crónica』7月7日付の記事。", "2016年7月のRIO54の記事は、1965年7月7日付の新聞『Crónica』の切り抜きを掲載している。本文は、これをアルゼンチン領南極でのUFO目撃に関する海軍初の公式発表と関連づけている。", "「En RIO54 se recordó a la comisión OVNI de la Armada Argentina」RIO54、2016年7月26日。", "後年の記事に再掲された報道資料として記録する。", "切り抜きだけで目撃現象の正体が証明されたと主張する。", "よくできた。資料の形式と、出来事からそれを振り返る記事までの時間差を認識できた。", "新聞の切り抜きは発表や報道が存在したことを示せるが、現象の起源を自動的に確定するものではない。"],
        ["COPEFO委員会", "機関に関する背景", "1960年代の海軍による研究委員会。", "記事は、オマール・ロケ・パガニ大尉の指揮下にあったUFO現象研究常設委員会（COPEFO）に言及し、1960年代に海軍が行った公的調査としてその活動を説明している。", "2016年7月26日付のRIO54記事。書籍「Los ovnis de la Antártida」の参考情報を要約している。", "資料に登場する委員会の存在を記録し、原資料を探す。", "公的委員会は必ず地球外起源という結論に達したと考える。", "正解。機関の背景は調査の歴史を補うが、起源についての判決ではない。", "研究機関が存在したことは、特定の仮説を確認したことを意味しない。"],
        ["2016年の回想", "記憶と回顧", "RIO54は51年後にこの出来事を振り返った。", "2016年7月7日、1965年の発表から51年目に、RIO54は会合の一部をこの話題の振り返りに充てた。記事はルベン・モラレスの著書「Los ovnis de la Antártida」と、南極調査を扱う章に言及している。", "「En RIO54 se recordó a la comisión OVNI de la Armada Argentina」2016年7月26日。", "2016年の回想と、思い出そうとしている1965年の文書や出来事を分けて考える。", "2016年の回想を、各目撃当時に記録された証言として扱う。", "よくできた。後年の記憶は調査の手掛かりになるが、同時代の資料に取って代わるものではない。", "後年の記憶は価値があるが、当時作成された記録とは区別する必要がある。"],
        ["調査に携わった人々の声", "証言と背景", "回想された経験と現地調査。", "記事は、1964年と1965年にコルドバ州ディケ・ロス・モリノス地域で行われた現地調査について、マリオ・コエンの回想を紹介している。彼の話によれば、そこで約20件の事例が報告されていた。また、元海軍調査員との会話も振り返っている。", "2016年7月のRIO54会合で語られた回想を記事が再録している。", "これらを参加者に帰属する回想として捉え、完全な技術報告書とは区別する。", "回想された逸話を、非人間的起源の決定的証拠に変える。", "そのとおり。後年の証言は手掛かりになり得るが、当時の記録と照合すべきだ。", "逸話は耳を傾けて検討する価値があるが、それだけで異常な起源を確定することはできない。"]
      ],
      boardQ: "文書間の時間的な隔たりを最も適切に踏まえた再構成はどれだろう？",
      board: [
        ["1965年の切り抜きが2016年に再び取り上げられ、会合ではCOPEFOや歴史的な証言も振り返られた。これらは原資料と照合する必要がある。", "正解。文書、機関の記憶、個人の回想を区別できた。"],
        ["2016年の会合は、南極でのすべての目撃が地球外の宇宙船だった証拠である。", "一つの事件を回想しても、すべての目撃の正体が決まるわけではない。"],
        ["切り抜きが2016年に紹介されたのだから、1965年についての情報は一切含まない。", "後年の再掲は原資料を探す手掛かりになる。ただし原本を探すことが望ましい。"]
      ],
      verdictQ: "最もよく裏付けられる結論はどれだろう？",
      verdict: [
        ["RIO54は1965年の海軍発表と公的調査の歴史を振り返っている。要約された資料はその記憶を記録するが、それだけで地球外起源を証明するものではない。", ""],
        ["海軍は目撃されたものが地球外の宇宙船だったと公式に確認した。", "記事は、発表が地球外起源を確認したとは述べていない。"],
        ["この件に関する公的調査も文書も存在しなかった。", "資料は発表、新聞の切り抜き、COPEFO委員会に言及している。"]
      ]
    }
  },
  'zh-CN': {
    c1: {
      top: [
        "历史重建", "九月之光", "布宜诺斯艾利斯及其大都市区 · 1985年9月17日",
        "许多人目击了一个空中物体。多年后，RIO54档案记录了一种具体解释。",
        "本档案从一次发生在布宜诺斯艾利斯及周边地区、被许多人目击的事件开始。你的任务是重建当时发表了什么、档案后来记录了哪种解释，以及现有信息究竟能支持多远的结论。",
        "文献起点：RIO54于2011年12月27日发表的一篇文章，将此事件被解释为法国制造的探空气球，归功于卡洛斯·德马里亚的调查。",
        "这座城市记得一道奇异的光。档案文件夹里有报纸剪报、日期，以及一篇重新讨论此事的文章。你不会找到一张能解释一切的神奇照片：你必须重建信息传递的过程。",
        "哪种关系最能概括整个档案？", "根据收集到的信息，应当提交什么结论？",
        "在所查阅的资料中，这起事件找到了一种有文献记录的解释。",
        "RIO54的文章将物体被认定为法国探空气球，归因于卡洛斯·德马里亚的调查。这个结论仅适用于本次事件及该文章所述内容：它不能解决其他案件，也不能否定其他证词。"
      ],
      clues: [
        ["事件日期", "时间线", "一个明确的时间记录。", "RIO54的文章将事件日期定为1985年9月17日，并指出该物体从布宜诺斯艾利斯市区及周边大都市区都能被观察到。", "文章《Los blogs de Carlos Demaría》，RIO54，2011年12月27日。", "按照文章原文记录日期、区域和范围。", "把目击者数量直接当作异常来源的自动证据。", "正确。你记录了该来源中可核实的信息，没有超出原文含义。", "目击者众多让案件值得研究，但单凭人数无法确定物体是什么。"],
        ["目击叙述", "转述的证词", "集体证词能提供什么信息。", "文章提到许多目击者。档案在此并未逐一刊载个人叙述，这篇文章也没有提供可用于比较描述、观察角度或时间的访谈资料库。", "RIO54文章对事件作了摘要，并未刊载所有原始证词。", "区分文章笼统提到目击者与未被收录的完整证词。", "尽管文本没有说明，却断言所有人看到的都完全相同。", "很好。你没有把有人作证与能够查阅每一份原始陈述混为一谈。", "档案不足以证明所有人都以完全相同的细节描述了同一个物体。"],
        ["后续调查", "文献归属", "RIO54记录的解释。", "RIO54回顾了卡洛斯·德马里亚对澄清此案所作的贡献，并称经过相关调查后，该物体被认定为法国制造的探空气球。", "文章《Los blogs de Carlos Demaría》，RIO54，2011年12月27日。", "注明这是文章归因于德马里亚调查的解释。", "把文章中没有出现的技术细节归到文章名下。", "正是如此。你保留了来源归属，没有编造气球的细节。", "文章给出了一般性识别结果，但没有在该篇文章中说明调查的全部技术细节。"],
        ["UFO一词的边界", "判断标准", "未识别不等于外星。", "在调查中，“不明飞行物”描述的是当时身份尚不清楚的目击对象。它不是对来源的分类，也不能证明存在非人类技术。", "这是游戏采用的方法论标准，并非博客的直接引文。", "将最初对物体的描述与来源后来记录的解释区分开来。", "把UFO这个标签当成外星飞船的同义词。", "这是本档案的核心步骤：表示不确定性的标签，不是关于来源的结论。", "这个缩写只表示某物在当时尚未被识别，并不能证明其来自外星。"]
      ],
      boardQ: "哪种关系最能概括整个档案？",
      board: [
        ["最初的目击叙述引发了调查；后来的文章记录称该物体被识别为法国探空气球。", "这一概述尊重了事件顺序，也保留了来源归属。"],
        ["大量目击者证明那是一艘外星飞船。", "目击者数量不能决定物体的性质。"],
        ["既然后来出现了解释，最初的证词就一定是编造的。", "后来的识别结果不能证明目击者撒了谎。"]
      ],
      verdictQ: "根据收集到的信息，应当提交什么结论？",
      verdict: [
        ["根据RIO54发表的重建内容，该物体后来被识别为法国制造的探空气球。", ""],
        ["该事件证明一艘外星飞船曾飞越布宜诺斯艾利斯。", "本档案没有证据支持这一说法。"],
        ["从未发生过任何目击：整个案件都是捏造的。", "来源确实提到大量目击；发生变化的是对物体的解释。"]
      ]
    },
    c2: {
      top: [
        "机构与文件", "接受审视的委员会", "CEFAE · 2010–2015年",
        "一个官方委员会宣布其任务、随后正式成立，几年后博客引用的首份报告出现了。",
        "本档案调查如何通过公告、决议、声明的任务和公开文件来评估公共机构。同时也要求区分来源内容与作者的意见。",
        "RIO54博客收录了2011年和2015年关于航空航天现象研究委员会（CEFAE）的文章。博客的编辑性批评会明确作为批评呈现，而不是游戏已经证实的事实。",
        "桌上摆着剪报、一篇报道提及的决议，以及介绍机构任务的网页。几年后，博客评论一份报告的出现，再次讨论这个主题。你的工作是区分时间线、文件和评价。",
        "对这条时间线，哪种解读最严谨？", "调查者的最终报告应该怎么写？",
        "高质量调查会区分行政事实、公开出版物和个人意见。",
        "博客的时间线区分了2010年的公告、2011年CEFAE的正式成立，以及2015年报告的发布。对报告形式的异议属于博客作者的批评。若要进行完整审计，还需查阅空军的原始决议和报告。"
      ],
      clues: [
        ["最初的公告", "时间线", "消息出现在2010年12月。", "在文章《Los misterios de la comisión oficial sobre ovnis》中，RIO54将未来委员会首次在电视上公布的日期定为2010年12月22日，当时接受采访的是准将吉列尔莫·丹尼尔·特阿尔迪。", "《Los misterios de la comisión oficial sobre ovnis》，RIO54，2011年12月22日。", "将该日期记录为委员会拟成立的公告日期，而不是正式成立日期。", "把首次电视公告与行政决议混为一谈。", "很好。新闻公告与正式设立机构的行政行为是两件不同的事。", "公告发生在文章所提到的正式决议之前。"],
        ["名称与任务", "机构文件", "CEFAE：研究航空航天现象。", "2011年6月的文章说明，该机构名为航空航天现象研究委员会（CEFAE）。文章转述了其任务：以有序、准确的方式记录、分析和研究在国家管辖空域内无法由常规监控系统识别的现象。", "《La comisión de la Fuerza Aérea ya está en la web》，RIO54，2011年6月19日；文章转录了官方介绍文字。", "将正式名称和声明的任务，与对调查结果的任何结论区分开来。", "把机构任务读成已经确认某个异常案件的证据。", "正确。任务说明一个机构表示自己应该做什么，并不预先决定调查结果。", "研究未识别现象的职责，并不意味着该机构已经确认某种假设。"],
        ["被提及的决议", "被报道的行政行为", "博客所描述的正式化过程。", "2011年12月的文章称，正式设立CEFAE的决议于2011年5月5日签署。同一文章还转述了其总体宗旨，即就未识别航空航天现象相关事务向空军提供建议。", "《Los misterios de la comisión oficial sobre ovnis》，RIO54，2011年12月22日。", "记录日期，并注明信息来自博客的文献叙述。", "没有查阅原始文件，却声称知道决议全文。", "方法正确：你保留了信息，也保留了这项说法的来源。", "文章对决议作了摘要并引用部分内容；这不等于在此查阅了完整行政文件。"],
        ["2015年的报告", "发布与批评", "博客评论了首份已发布的报告。", "在2015年12月18日的一篇文章中，RIO54称CEFAE成立四年半后，首份报告于当月初发布在空军网站上。作者还质疑PDF的格式，以及他们所描述的文件缺少签名一事。", "《Luego de cuatro años y medio, la comisión oficial sobre ovnis lanzó su primer informe》，RIO54，2015年12月18日。这是博客作者的描述和评价。", "将博客报道的事实——报告发布——与作者对呈现形式的批评区分开来。", "断言报告证明存在掩盖，或委员会根本没有开展任何工作。", "正是如此。文件批评可能很重要，但单凭它本身不能证明存在隐瞒意图。", "延迟和形式上的问题可以引发疑问，但不会自动证明存在掩盖。"]
      ],
      boardQ: "对这条时间线，哪种解读最严谨？",
      board: [
        ["2010年有过公告，2011年正式成立，博客称2015年发布了首份报告；对报告的批评应归于其作者。", "正确：你区分了时间线与编辑性评价。"],
        ["CEFAE的存在证明空军确认了外星来访。", "机构任务是研究未识别现象，而不是确认外星人存在。"],
        ["报告迟迟出现必然证明整个委员会都是虚构的。", "来源描述了委员会、正式成立过程和一份报告；延迟不能证明它从未存在。"]
      ],
      verdictQ: "调查者的最终报告应该怎么写？",
      verdict: [
        ["根据RIO54记录的时间线，CEFAE经过公告后正式成立；博客称2015年发布了首份报告，并批评了其呈现方式。这些批评本身并不能证明存在掩盖。", ""],
        ["CEFAE发现了外星飞船，并秘密确认了这一点。", "本档案的文件中没有证据支持这一说法。"],
        ["委员会从未存在，所有公告都是假的。", "档案中的时间线与这一结论相矛盾。"]
      ]
    },
    c3: {
      top: [
        "证词与审慎", "蒙特格兰德之夜", "布宜诺斯艾利斯省蒙特格兰德 · 2011年9月26日",
        "一次爆炸、一名遇难者，以及关于天空中一道光的叙述，引发了需要谨慎审查的各种假设。",
        "本档案讨论博客报道中提到的一起悲剧事件。处理方式必须尊重当事人：不重现伤害，不把痛苦变成猎奇表演，也不把关于爆炸原因的假设当作事实。",
        "RIO54的文章报告称有一人遇难。游戏不会以图像重现事件，也不声称已经确定爆炸原因。",
        "档案里有一则简短新闻：一次爆炸摧毁了住宅和一家商店。当地居民把强光与爆炸发生的时刻联系起来。此事成为公众讨论的话题，流传着各种不同解释。首要原则是，不要把时间上的接近误认为已经证实的因果关系。",
        "应当如何看待关于光与爆炸之间关系的证词？", "根据现有材料，负责任的结论是什么？",
        "有时，最可靠的结论就是承认哪些事情尚无法确定。",
        "RIO54的报道提到一次造成严重人员后果的爆炸，并记录了居民关于一道强光的说法。文章还列出了流传的各种假设。查阅到的信息不足以确定原因；出于对受影响者的尊重，游戏避免把悲剧变成UFO猎奇表演。"
      ],
      clues: [
        ["事件本身", "报道中的事实", "日期与人员后果。", "RIO54的报道将爆炸时间定为2011年9月26日星期一凌晨。报道称，两栋房屋和一家商店被完全摧毁，并造成一人死亡。", "《OVNIS: exitosa reunión RIO54 de octubre》，RIO54，2011年10月9日。", "记录事件及其对人的影响，不要猜测原因。", "把悲剧当作虚构场景，或当作非人类来源的证据。", "感谢你把注意力放在事件和受影响的人身上。调查应从这里开始。", "悲剧值得尊重。事件的严重程度本身并不能确定爆炸的来源。"],
        ["居民的说法", "转述的证词", "据称有人看到了强光。", "报道指出，当地居民声称爆炸发生时有一道强光从天空出现。所查阅的文章没有提供完整陈述、仪器记录或鉴定报告，因此无法分别评估每一份叙述。", "RIO54的报道对居民证词作了摘要。", "将强光记录为居民所述的目击信息，并在评估前寻找原始陈述。", "因为强光与爆炸在同一时刻被报告，就断言强光导致了爆炸。", "很好。时间上的巧合是调查线索，不是因果关系的证明。", "感知到的同时发生，并不足以证明强光导致了爆炸。"],
        ["流传的假设", "公众假设", "陨石、太空碎片或飞船。", "文章列出了迅速流传的假设：陨石坠落、太空碎片，甚至来自地球之外的飞行器。这份清单记录了公众讨论，并未确认其中任何一种可能。", "《OVNIS: exitosa reunión RIO54 de octubre》，RIO54，2011年10月9日。", "将这些选项归类为曾被提及、仍需独立证据的假设。", "因为某种假设传播很快，就选择其中最具轰动性的说法。", "正确。新闻报道中出现一种假设，不等于专家鉴定结论。", "传播速度不会提高假设的可信度，也不能代替物证。"],
        ["要解决此事还缺少什么", "档案的局限", "报道没有提供决定性的鉴定结果。", "在所查阅的片段中，博客总结了事件、转述了居民的说法，并提及各种假设。这些材料本身无法识别爆炸的来源。若要继续调查，还需要鉴定报告、官方档案、技术记录，以及可以相互核对的原始证词等。", "这是对所查阅RIO54文章范围的评估，并非声称不存在其他文件。", "得出结论：本档案的信息不足以归因于某个原因。", "用没有依据的确定说法填补资料空缺。", "这是一个有效结论：承认局限也是调查成果。", "缺少文件时，编造解释并不能解决案件。"]
      ],
      boardQ: "应当如何看待关于光与爆炸之间关系的证词？",
      board: [
        ["这份证词值得重视和核实，但时间上的巧合并不能证明强光导致了爆炸。", "正确。你区分了调查线索与已确立的因果关系。"],
        ["那道光必然是一艘引发爆炸的飞船。", "报道没有证据识别那道光，也没有证据将它与爆炸建立因果联系。"],
        ["既然发生了爆炸，居民就不可能看到任何光。", "悲剧事件的发生不会自动使证词无效；证词仍应接受审查。"]
      ],
      verdictQ: "根据现有材料，负责任的结论是什么？",
      verdict: [
        ["报道记录了一次悲剧性爆炸以及关于一道光的证词，但所查阅的文章不足以确定事件原因。", ""],
        ["已经证明一艘外星飞船坠毁在蒙特格兰德。", "本档案没有鉴定报告或证据支持这一说法。"],
        ["已经证明所有证词都是编造的。", "缺乏充分佐证并不能证明证人撒谎。"]
      ]
    },
    c4: {
      top: [
        "南极档案", "来自白色大陆的回声", "阿根廷南极地区 · 1965年 / 2016年的文献回顾",
        "1965年的海军通报与2016年的RIO54聚会，有助于重建官方调查的历史记忆。",
        "最后一个档案追踪RIO54档案中提及的一起南极事件。数十年后，这段历史再次出现在报纸剪报和纪念聚会中。必须区分历史公告、后来的回忆以及事后的解释。",
        "游戏材料依据RIO54于2016年7月26日发表的文章。若要核对技术细节和完整证词，需要查阅文章提及的原始出版物和文件。",
        "寒冷能够保存文件，但时间也会改变我们记忆它们的方式。2016年7月的一次聚会中，RIO54重新讨论了51年前发布的海军通报，以及一个研究委员会的历史。你的任务是重建这份文献记忆所表达的内容。",
        "哪种重建最尊重不同文件之间的时间距离？", "哪项结论获得的支持最充分？",
        "历史记忆提出问题；原始文件帮助我们把问题弄清楚。",
        "RIO54在2016年7月的文章回顾了1965年的海军通报，转载了一份报纸剪报，并提及COPEFO。文章还包含参与者的回忆和书目参考。这是开展档案研究的起点，而不是足以证明目击现象性质的证据。"
      ],
      clues: [
        ["1965年的剪报", "转述的新闻文件", "《Crónica》报1965年7月7日的报道。", "RIO54在2016年7月的文章展示了一张《Crónica》报1965年7月7日的剪报。文章将它与阿根廷南极地区UFO目击事件的海军首次官方通报联系起来。", "《En RIO54 se recordó a la comisión OVNI de la Armada Argentina》，RIO54，2016年7月26日。", "将剪报记录为后来文章转载的一项新闻资料。", "声称仅凭剪报就能证明被观察现象的性质。", "很好。你识别了文献载体，也注意到事件与后来回顾它的文章之间存在时间差。", "剪报可以证明某项通报或新闻曾经存在，但不能自动确定现象的来源。"],
        ["COPEFO委员会", "机构背景", "1960年代的海军研究委员会。", "文章提到由奥马尔·罗克·帕加尼上尉指挥的UFO现象永久研究委员会（COPEFO），并将其工作描述为海军在1960年代开展的一项官方调查。", "RIO54于2016年7月26日发表的文章，概述了《Los ovnis de la Antártida》一书中的参考资料。", "记录来源提到的委员会存在，并寻找其原始文件。", "假设每个官方委员会最终都必然得出外星起源的结论。", "正确。机构背景补充了调查历史，但它不是对现象来源的判决。", "研究机构的存在并不意味着它确认了某个特定假设。"],
        ["2016年的回忆", "记忆与回顾", "RIO54在51年后重新讨论了这一事件。", "2016年7月7日，也就是1965年通报发布51周年之际，RIO54在聚会中安排了一部分时间回顾这个主题。文章提到鲁本·莫拉莱斯的《Los ovnis de la Antártida》一书，以及其中关于南极调查的章节。", "《En RIO54 se recordó a la comisión OVNI de la Armada Argentina》，2016年7月26日。", "将2016年的回忆与它试图回顾的1965年文件和事件区分开来。", "把2016年的回忆当成每次目击发生当时的同步证词。", "很好。后来的回忆可以指引调查，但不能取代同时期的资料。", "后来的记忆很有价值，但必须与当时形成的记录区分开来。"],
        ["参与调查者的声音", "证词与背景", "被回忆的经历和实地工作。", "报道转述了马里奥·科恩对1964年和1965年在科尔多瓦省迪克·洛斯·莫利诺斯地区进行实地工作的回忆。据他所述，当地曾报告近20起事件。文章也回顾了他与海军前调查人员的谈话。", "文章转载了参与者在2016年7月RIO54聚会中分享的回忆。", "将这些内容识别为参与者的回忆，而不是完整的技术报告。", "把回忆中的轶事变成非人类起源的决定性证据。", "正是如此。回顾性的证词可以成为线索，但应与同时期的记录进行核对。", "轶事值得倾听和分析，但仅凭它不足以确定某种异常来源。"]
      ],
      boardQ: "哪种重建最尊重不同文件之间的时间距离？",
      board: [
        ["1965年的剪报在2016年被重新讨论；聚会还回顾了COPEFO和历史证词，这些内容都需要与原始来源核对。", "正确：你区分了文件、机构记忆和个人回忆。"],
        ["2016年的聚会证明南极地区所有目击到的都是外星飞船。", "回忆一个案件并不能确定所有目击事件的性质。"],
        ["因为剪报是在2016年展示的，所以它无法提供任何关于1965年的信息。", "后来的转载可以帮助寻找原始文件，不过最好还是查到原件。"]
      ],
      verdictQ: "哪项结论获得的支持最充分？",
      verdict: [
        ["RIO54回顾了1965年的海军通报和官方调查的历史；摘要材料记录了这种记忆，但本身不能证明外星起源。", ""],
        ["海军正式确认目击到的是外星飞船。", "文章没有声称该通报确认了外星起源。"],
        ["从未进行过官方调查，也不存在相关文件。", "来源提到了通报、剪报以及COPEFO委员会。"]
      ]
    }
  }
};
