/* RIO54 WebGL scene renderer.
 * The adventure logic and accessible interface remain HTML/CSS/JavaScript;
 * this renderer draws the animated 2D scene through a real WebGL context.
 * No external libraries, network requests, or assets are required.
 */
(() => {
  'use strict';
  const canvas = document.getElementById('rio54WebglCanvas');
  const scene = document.getElementById('rio54HeroScene');
  if (!canvas || !scene) return;

  const gl = canvas.getContext('webgl', {
    alpha: false,
    antialias: false,
    depth: false,
    stencil: false,
    powerPreference: 'low-power',
    preserveDrawingBuffer: false
  });
  if (!gl) {
    document.documentElement.dataset.rio54Renderer = 'css-fallback';
    return; // Keep the CSS illustration as a graceful fallback.
  }

  const vertexSource = `
    attribute vec2 a_position;
    varying vec2 v_uv;
    void main(){
      v_uv = a_position * 0.5 + 0.5;
      gl_Position = vec4(a_position, 0.0, 1.0);
    }
  `;

  const fragmentSource = `
    precision mediump float;
    varying vec2 v_uv;
    uniform vec2 u_resolution;
    uniform float u_time;

    float hash(vec2 p){
      p = fract(p * vec2(123.34, 456.21));
      p += dot(p, p + 45.32);
      return fract(p.x * p.y);
    }
    float circle(vec2 p, vec2 c, vec2 r){
      vec2 q = (p - c) / r;
      return 1.0 - smoothstep(0.90, 1.03, length(q));
    }
    void main(){
      vec2 uv = v_uv;
      float aspect = u_resolution.x / max(1.0, u_resolution.y);
      vec3 col = mix(vec3(0.025,0.055,0.082), vec3(0.055,0.105,0.135), uv.y);
      col += vec3(0.025,0.060,0.070) * exp(-pow((uv.x-0.22)*3.4,2.0)) * (1.0-uv.y);

      // Star field with very subtle twinkle.
      vec2 cell = floor(uv * vec2(55.0, 32.0));
      vec2 local = fract(uv * vec2(55.0, 32.0));
      float rnd = hash(cell);
      float star = (1.0 - smoothstep(0.015, 0.055, length(local-vec2(hash(cell+2.1),hash(cell+7.7)))))
                   * step(0.978, rnd);
      float twinkle = 0.65 + 0.35 * sin(u_time * (0.7 + rnd*1.5) + rnd*30.0);
      col += vec3(0.50,0.72,0.78) * star * twinkle * 0.75;

      // Moon and atmospheric halo.
      vec2 moon = vec2(0.72, 0.73);
      float md = length((uv-moon)*vec2(aspect,1.0));
      col += vec3(0.19,0.34,0.34) * exp(-md*8.0) * 0.42;
      float m = circle(uv, moon, vec2(0.115/max(0.6,aspect),0.20));
      float shade = smoothstep(-0.20,0.15, (uv.x-moon.x)*aspect + (uv.y-moon.y)*0.55);
      vec3 moonCol = mix(vec3(0.28,0.48,0.48),vec3(0.78,0.84,0.76),shade);
      col = mix(col, moonCol, m*0.95);

      // Floating saucer, glow and slow scanning beam.
      float drift = sin(u_time*0.34)*0.012;
      vec2 ship = vec2(0.66+drift,0.49+sin(u_time*0.55)*0.008);
      float beamT = clamp((ship.y-uv.y)/(ship.y-0.08),0.0,1.0);
      float beamWidth = 0.012 + beamT*0.085;
      float beam = (1.0-smoothstep(beamWidth,beamWidth+0.025,abs(uv.x-ship.x))) * step(0.08,uv.y) * step(uv.y,ship.y-0.018);
      col += vec3(0.20,0.66,0.67) * beam * 0.12;
      float glow = exp(-length((uv-ship)*vec2(aspect,1.0))*15.0);
      col += vec3(0.12,0.48,0.52) * glow * 0.45;
      float hull = circle(uv, ship, vec2(0.17/max(0.6,aspect),0.042));
      float dome = circle(uv, ship+vec2(0.0,0.027), vec2(0.064/max(0.6,aspect),0.031));
      float rim = (1.0-smoothstep(0.0,0.012,abs(uv.y-(ship.y-0.002)))) * (1.0-smoothstep(0.13,0.18,abs(uv.x-ship.x)*aspect));
      col = mix(col, vec3(0.36,0.62,0.63), hull*0.92);
      col = mix(col, vec3(0.69,0.82,0.76), dome*0.95);
      col += vec3(0.95,0.70,0.38) * rim * 0.72;
      float blink = step(0.78, fract(u_time*0.34));
      for(int i=0;i<5;i++){
        float x = ship.x + (float(i)-2.0)*0.052;
        float lamp = circle(uv, vec2(x,ship.y-0.019), vec2(0.009/max(0.6,aspect),0.006));
        col += vec3(1.0,0.69,0.32) * lamp * (0.45 + 0.55*blink);
      }

      // Buenos Aires skyline silhouette and scattered warm windows.
      float bx = floor(uv.x*34.0);
      float bh = 0.13 + hash(vec2(bx, 9.0))*0.13;
      float building = step(uv.y, bh);
      col = mix(col, vec3(0.025,0.060,0.079), building*0.98);
      float wx = fract(uv.x*120.0);
      float wy = fract(uv.y*60.0);
      float windows = step(0.69,hash(vec2(floor(uv.x*120.0),floor(uv.y*60.0))))
                    * step(0.18,wx) * step(wx,0.78) * step(0.20,wy) * step(wy,0.72)
                    * building;
      col += vec3(0.78,0.48,0.22) * windows * 0.48;
      col += vec3(0.03,0.10,0.12) * exp(-pow((uv.y-0.20)*10.0,2.0));

      // Soft vignette and restrained film grain.
      float vig = (1.0-smoothstep(0.22,0.95,length((uv-0.5)*vec2(0.9,1.0))));
      col *= 0.78 + 0.22*vig;
      float grain = (hash(gl_FragCoord.xy+u_time)-0.5)*0.018;
      col += grain;
      gl_FragColor = vec4(clamp(col,0.0,1.0),1.0);
    }
  `;

  function compile(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const message = gl.getShaderInfoLog(shader) || 'Shader compilation failed';
      gl.deleteShader(shader);
      throw new Error(message);
    }
    return shader;
  }

  let program;
  try {
    const vs = compile(gl.VERTEX_SHADER, vertexSource);
    const fs = compile(gl.FRAGMENT_SHADER, fragmentSource);
    program = gl.createProgram();
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    gl.deleteShader(vs);
    gl.deleteShader(fs);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      throw new Error(gl.getProgramInfoLog(program) || 'Program link failed');
    }
  } catch (error) {
    console.warn('[RIO54 WebGL] Renderer unavailable; using CSS fallback.', error);
    document.documentElement.dataset.rio54Renderer = 'css-fallback';
    return;
  }

  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
  gl.useProgram(program);
  const position = gl.getAttribLocation(program, 'a_position');
  gl.enableVertexAttribArray(position);
  gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
  const resolution = gl.getUniformLocation(program, 'u_resolution');
  const time = gl.getUniformLocation(program, 'u_time');
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let start = performance.now();
  let raf = 0;
  let dpr = 1;

  function resize() {
    const rect = canvas.getBoundingClientRect();
    dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const w = Math.max(1, Math.round(rect.width*dpr));
    const h = Math.max(1, Math.round(rect.height*dpr));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
      gl.viewport(0,0,w,h);
    }
    gl.uniform2f(resolution, canvas.width, canvas.height);
  }

  function draw(now) {
    if (document.hidden) { raf = 0; return; }
    resize();
    gl.uniform1f(time, reduceMotion ? 0.0 : (now-start)/1000.0);
    gl.drawArrays(gl.TRIANGLES,0,3);
    raf = requestAnimationFrame(draw);
  }
  function startLoop() { if (!raf) raf = requestAnimationFrame(draw); }
  function stopLoop() { if (raf) cancelAnimationFrame(raf); raf = 0; }

  scene.classList.add('webgl-active');
  document.documentElement.dataset.rio54Renderer = 'webgl';
  startLoop();
  document.addEventListener('visibilitychange', () => document.hidden ? stopLoop() : startLoop());
  window.addEventListener('resize', resize, {passive:true});
  canvas.addEventListener('webglcontextlost', event => {
    event.preventDefault();
    stopLoop();
    scene.classList.remove('webgl-active');
    document.documentElement.dataset.rio54Renderer = 'css-fallback';
  }, false);
})();
