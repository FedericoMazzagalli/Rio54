# RIO54 — Archivo de lo inexplicado

Edición HTML5 multilingüe del videojuego narrativo de investigación inspirado en el archivo y las preguntas del blog [RIO54 OVNI](https://rio54ovni.blogspot.com/).

## Publicación web

Este repositorio está preparado para GitHub Pages. El archivo `index.html` está en la raíz y el workflow `.github/workflows/pages.yml` despliega el sitio automáticamente al hacer push a `main`.

Para activar la publicación: en GitHub, abrí **Settings → Pages** y seleccioná **GitHub Actions** como fuente. Luego revisá la pestaña **Actions** hasta que el trabajo `Deploy RIO54 to GitHub Pages` finalice correctamente.

## Contenido

- 4 expedientes narrativos y 16 indicios.
- 8 idiomas: español, inglés, portugués brasileño, francés, alemán, italiano, japonés y chino simplificado.
- Tablero de relaciones, registro de indicios, conclusiones y evaluación del método.
- Guardado local de progreso.
- PWA: manifiesto, iconos y service worker para caché offline después de la primera visita HTTPS.
- WebGL 1 nativo con alternativa CSS. Esta edición no es una compilación Unity WebGL ni incluye `.wasm`.

## Control de calidad

Ejecutá `python3 Tools/verify_release.py` para validar la estructura y los recursos. El informe `QA_REPORT.txt` detalla también las pruebas pendientes en navegadores/dispositivos reales.

## Criterio documental

El blog RIO54 es el punto de partida de esta adaptación, no una verificación independiente de todas sus afirmaciones. Se distinguen observaciones, testimonios, documentos, hipótesis y conclusiones. Proyecto independiente, sin afiliación oficial con el blog ni con organismos mencionados.
